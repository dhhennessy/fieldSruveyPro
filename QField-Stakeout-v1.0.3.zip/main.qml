import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    property var mainWindow: iface.mainWindow()
    property var navigation: iface.findItemByObjectName("navigation")
    property var dashBoard: iface.findItemByObjectName("dashBoard")
    property var featureForm: iface.findItemByObjectName("featureForm")
    property bool active: false
    property string targetName: ""
    property real arrivalThreshold: 0.5

    Component.onCompleted: iface.addItemToPluginsToolbar(stakeoutButton)

    /*
      v1.0.3: Do not depend on QgsVectorLayer.selectedFeatureIds().
      QField's feature-list selection exposes a focusedFeature/focusedLayer
      through the FeatureListModelSelection object. This is the selection
      produced by tapping a feature in QField's identify/feature UI.
    */
    function getSelectedTarget() {
        // Primary method for QField feature selection.
        try {
            if (featureForm && featureForm.selection) {
                var f = featureForm.selection.focusedFeature
                var l = featureForm.selection.focusedLayer
                if (f && f.isValid && f.isValid() && l) {
                    return { feature: f, layer: l }
                }
            }
        } catch (e1) {
            iface.logMessage("Stakeout focused selection: " + e1)
        }

        // Some QField builds expose the selection through the feature list model.
        try {
            if (featureForm && featureForm.model) {
                var n = Number(featureForm.model.selectedCount)
                if (n === 1) {
                    var fs = featureForm.model.selectedFeatures
                    var sl = featureForm.model.selectedLayer
                    if (fs && fs.length === 1 && sl)
                        return { feature: fs[0], layer: sl }
                }
            }
        } catch (e2) {
            iface.logMessage("Stakeout model selection: " + e2)
        }

        // Legacy fallback: QGIS layer selection.
        try {
            var ids = iface.mapCanvas().mapSettings.layers
            for (var i = 0; i < ids.length; i++) {
                var layer = qgisProject.mapLayer(ids[i])
                if (!layer) continue
                var selected = layer.selectedFeatureIds()
                if (selected && selected.length === 1) {
                    var feat = layer.getFeature(selected[0])
                    if (feat && feat.isValid())
                        return { feature: feat, layer: layer }
                }
            }
        } catch (e3) {
            iface.logMessage("Stakeout legacy selection: " + e3)
        }

        return null
    }

    function startStakeout() {
        var info = getSelectedTarget()

        if (!info) {
            mainWindow.displayToast("QField has no focused point selected")
            return
        }

        // Explicitly reject non-point geometries.
        try {
            if (Number(info.feature.geometry().type()) !== 0) {
                mainWindow.displayToast("Stakeout requires a point feature")
                return
            }
        } catch (e) {}

        try {
            navigation.setDestinationFeature(info.feature, info.layer)
            targetName = getTargetName(info.feature)
            active = true
            stakeoutPanel.visible = true
            mainWindow.displayToast("Stakeout: " + targetName)
        } catch (e4) {
            iface.logMessage("Stakeout navigation error: " + e4)
            mainWindow.displayToast("Could not start stakeout")
        }
    }

    function clearStakeout() {
        try { navigation.clear() } catch (e) {
            try { navigation.clearDestinationFeature() } catch (e2) {}
        }
        active = false
        targetName = ""
        stakeoutPanel.visible = false
        mainWindow.displayToast("Stakeout cleared")
    }

    function getTargetName(feature) {
        try {
            var n = feature.attribute("name")
            if (n !== null && n !== undefined && String(n) !== "")
                return String(n)
        } catch (e) {}
        try { return "Point " + feature.id() } catch (e2) {}
        return "Target"
    }

    function distanceText() {
        if (!navigation || !navigation.isActive) return "--"
        var d = Number(navigation.distance)
        if (!isFinite(d)) return "--"
        if (d < 1) return d.toFixed(2) + " m"
        if (d < 1000) return d.toFixed(1) + " m"
        return (d / 1000).toFixed(3) + " km"
    }

    function bearingText() {
        if (!navigation || !navigation.isActive) return "--"
        var b = Number(navigation.bearing)
        if (!isFinite(b)) return "--"
        if (b < 0) b += 360
        return b.toFixed(1) + "°"
    }

    function accuracyText() {
        try {
            var p = iface.positioning()
            var pi = p.positionInformation
            if (pi && pi.haccValid) return Number(pi.hacc).toFixed(2) + " m"
        } catch (e) {}
        return "--"
    }

    function fixText() {
        try {
            var p = iface.positioning()
            var pi = p.positionInformation
            if (pi && pi.fixStatusDescription) return String(pi.fixStatusDescription)
        } catch (e) {}
        return "--"
    }

    QfToolButton {
        id: stakeoutButton
        bgcolor: "#b71c1c"
        iconSource: "stakeout.svg"
        iconColor: "white"
        round: true
        width: 56
        height: 56

        onClicked: {
            if (active) clearStakeout()
            else startStakeout()
        }

        Text {
            anchors.centerIn: parent
            text: "STAKE"
            color: "white"
            font.bold: true
            font.pixelSize: 10
        }
    }

    Timer {
        interval: 500
        running: active
        repeat: true
        onTriggered: stakeoutPanel.visible = true
    }

    Rectangle {
        id: stakeoutPanel
        parent: mainWindow.contentItem
        visible: false
        z: 10000
        width: Math.min(mainWindow.width * 0.90, 430)
        height: 300
        x: (mainWindow.width - width) / 2
        y: 75
        radius: 14
        color: "#202124"
        border.color: "#777777"
        border.width: 1

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 16
            spacing: 8

            Label {
                Layout.fillWidth: true
                text: "STAKEOUT"
                color: "white"
                font.pixelSize: 22
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
            }

            Label {
                Layout.fillWidth: true
                text: targetName
                color: "#dddddd"
                font.pixelSize: 17
                horizontalAlignment: Text.AlignHCenter
                elide: Text.ElideMiddle
            }

            Rectangle {
                Layout.fillWidth: true
                height: 105
                radius: 10
                color: "#111111"

                Column {
                    anchors.centerIn: parent
                    spacing: 4

                    Label {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: distanceText()
                        color: "white"
                        font.pixelSize: 38
                        font.bold: true
                    }

                    Label {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: "BEARING  " + bearingText()
                        color: "#dddddd"
                        font.pixelSize: 18
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true

                Label {
                    Layout.fillWidth: true
                    text: "GNSS ± " + accuracyText()
                    color: "#cccccc"
                    font.pixelSize: 14
                }

                Label {
                    Layout.fillWidth: true
                    text: "Fix: " + fixText()
                    color: "#cccccc"
                    font.pixelSize: 14
                    horizontalAlignment: Text.AlignRight
                }
            }

            Label {
                Layout.fillWidth: true
                text: (navigation && navigation.isActive &&
                       Number(navigation.distance) <= arrivalThreshold)
                      ? "✓ ARRIVED — within " + arrivalThreshold.toFixed(1) + " m"
                      : "Walk toward the target"
                color: (navigation && navigation.isActive &&
                        Number(navigation.distance) <= arrivalThreshold)
                       ? "#7CFC00" : "#eeeeee"
                font.pixelSize: 15
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                Button {
                    Layout.fillWidth: true
                    text: "Clear"
                    onClicked: clearStakeout()
                }

                Button {
                    Layout.fillWidth: true
                    text: "Close"
                    onClicked: stakeoutPanel.visible = false
                }
            }
        }
    }
}
