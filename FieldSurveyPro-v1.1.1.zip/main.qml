import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    objectName: "fieldSurveyPro"

    property var pointLayer: null
    property var lineLayer: null
    property var polygonLayer: null
    property int nextPointNumber: 1

    function findLayer(name) {
        if (!qgisProject)
            return null
        var layers = qgisProject.mapLayersByName(name)
        if (layers && layers.length > 0)
            return layers[0]
        return null
    }

    function prepareLayer(layer, label) {
        if (!layer) {
            iface.mainWindow().displayToast(label + " layer not found")
            return false
        }
        try {
            if (!layer.isEditable())
                layer.startEditing()
        } catch (e) {
            iface.mainWindow().displayToast("Could not make " + label + " editable")
            return false
        }
        return true
    }

    function setup() {
        pointLayer = findLayer("FieldSurveyPro_Points")
        lineLayer = findLayer("FieldSurveyPro_Lines")
        polygonLayer = findLayer("FieldSurveyPro_Polygons")

        var ok = true
        ok = prepareLayer(pointLayer, "Point") && ok
        ok = prepareLayer(lineLayer, "Line") && ok
        ok = prepareLayer(polygonLayer, "Polygon") && ok

        if (ok)
            iface.mainWindow().displayToast("FieldSurvey Pro layers ready")
        return ok
    }

    function collectPoint(pointName) {
        if (!pointLayer) {
            iface.mainWindow().displayToast("Point layer is not available")
            return
        }

        var positioning = iface.positioning()
        if (!positioning || !positioning.valid) {
            iface.mainWindow().displayToast("GNSS position is not valid")
            return
        }

        var p = positioning.projectedPosition
        if (!p || !isFinite(p.x) || !isFinite(p.y)) {
            iface.mainWindow().displayToast("No valid projected GNSS position")
            return
        }

        var geometry = GeometryUtils.createGeometryFromWkt(
            "POINT (" + p.x + " " + p.y + ")"
        )

        var feature = FeatureUtils.createFeature(pointLayer, geometry)

        try {
            feature.setAttribute("feature_id", "PT-" + ("000000" + nextPointNumber).slice(-6))
        } catch (e) {}

        try {
            feature.setAttribute(
                "name",
                pointName.length > 0 ? pointName : "PT-" + ("000000" + nextPointNumber).slice(-6)
            )
        } catch (e) {}

        try {
            var info = positioning.positionInformation
            try { feature.setAttribute("accuracy_h", info.hacc) } catch (e) {}
            try { feature.setAttribute("accuracy_v", info.vacc) } catch (e) {}
            try { feature.setAttribute("pdop", info.pdop) } catch (e) {}
            try { feature.setAttribute("satellites", info.satellitesUsed) } catch (e) {}
            try { feature.setAttribute("timestamp", info.utcDateTime) } catch (e) {}
        } catch (e) {}

        var added = false
        try {
            added = LayerUtils.addFeature(pointLayer, feature)
        } catch (e) {
            added = false
        }

        if (added) {
            nextPointNumber++
            try {
                pointLayer.triggerRepaint()
                iface.mapCanvas().refresh()
            } catch (e) {}
            iface.mainWindow().displayToast("Point saved")
            pointDialog.close()
        } else {
            iface.mainWindow().displayToast("Point could not be saved")
        }
    }

    QfToolButton {
        id: collectPointButton
        objectName: "fieldSurveyProCollectPoint"
        bgcolor: Theme.darkGray
        iconSource: Theme.getThemeVectorIcon("ic_add_location_white_24dp")
        iconColor: Theme.toolButtonColor
        round: true
        onClicked: {
            pointNameInput.text = ""
            pointDialog.open()
            pointNameInput.forceActiveFocus()
        }
    }

    Dialog {
        id: pointDialog
        parent: iface.mainWindow().contentItem
        title: "FieldSurvey Pro — Collect Point"
        modal: true
        anchors.centerIn: parent
        width: Math.min(parent.width - 40, 520)

        Column {
            width: parent.width
            spacing: 12

            Label {
                text: "Point name"
            }

            TextField {
                id: pointNameInput
                width: parent.width
                placeholderText: "Optional name"
                selectByMouse: true
            }

            Row {
                spacing: 10

                Button {
                    text: "Cancel"
                    onClicked: pointDialog.close()
                }

                Button {
                    text: "Collect Point"
                    onClicked: collectPoint(pointNameInput.text.trim())
                }
            }
        }
    }

    Component.onCompleted: {
        if (setup())
            iface.addItemToPluginsToolbar(collectPointButton)
        else
            iface.addItemToPluginsToolbar(collectPointButton)

        iface.mainWindow().displayToast("FieldSurvey Pro point collector ready")
    }
}
