import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    property var mainWindow: iface.mainWindow()
    property var navigation: iface.findItemByObjectName("navigation")
    property var pointHandler: iface.findItemByObjectName("pointHandler")
    property bool picking: false
    property bool active: false
    property string targetName: ""
    property real arrivalThreshold: 0.5

    Component.onCompleted: iface.addItemToPluginsToolbar(stakeoutButton)

    // Uses QField's documented point-handler + LayerUtils feature iterator.
    // This avoids feature selection/focus entirely.
    function beginPick() {
        if (!pointHandler) {
            mainWindow.displayToast("QField point handler is unavailable")
            return
        }

        try {
            pointHandler.unregisterHandler("FieldSurveyProStakeout")
        } catch (e0) {}

        picking = true
        active = false
        stakeoutPanel.visible = true
        statusText.text = "TAP THE TARGET POINT"

        pointHandler.registerHandler("FieldSurveyProStakeout",
            function(point, type, interactionType) {
                if (!picking || interactionType !== "clicked")
                    return false

                var canvas = iface.mapCanvas()
                var tl = canvas.mapSettings.screenToCoordinate(
                    Qt.point(point.x - 8, point.y - 8))
                var br = canvas.mapSettings.screenToCoordinate(
                    Qt.point(point.x + 8, point.y + 8))

                var rectangle
                try {
                    rectangle = GeometryUtils.createRectangleFromPoints(tl, br)
                } catch (e1) {
                    iface.logMessage("Stakeout rectangle error: " + e1)
                    mainWindow.displayToast("Could not read map location")
                    return true
                }

                var layerIds = canvas.mapSettings.layers
                var found = false

                for (var i = 0; i < layerIds.length && !found; i++) {
                    var layer = qgisProject.mapLayer(layerIds[i])
                    if (!layer) continue

                    // Only point geometry layers.
                    try {
                        if (Number(layer.geometryType) !== 0)
                            continue
                    } catch (e2) {
                        continue
                    }

                    try {
                        var iterator =
                            LayerUtils.createFeatureIteratorFromRectangle(
                                layer, rectangle)

                        if (iterator && iterator.hasNext()) {
                            var feature = iterator.next()
                            if (feature && feature.isValid()) {
                                setTarget(layer, feature)
                                found = true
                            }
                        }
                    } catch (e3) {
                        iface.logMessage("Stakeout layer search error: " + e3)
                    }
                }

                if (!found)
                    mainWindow.displayToast("No point found at that location")

                // We took over the tap.
                return true
            })
    }

    function setTarget(layer, feature) {
        try {
            navigation.setDestinationFeature(feature, layer)
            targetName = getTargetName(feature)
            active = true
            picking = false
            statusText.text = "WALK TO TARGET"
            mainWindow.displayToast("Stakeout: " + targetName)
        } catch (e) {
            iface.logMessage("Stakeout navigation error: " + e)
            mainWindow.displayToast("Could not start navigation")
        }
    }

    function clearStakeout() {
        try { navigation.clear() } catch (e) {
            try { navigation.clearDestinationFeature() } catch (e2) {}
        }
        try { pointHandler.unregisterHandler("FieldSurveyProStakeout") } catch (e3) {}
        picking = false
        active = false
        targetName = ""
        stakeoutPanel.visible = false
    }

    function getTargetName(feature) {
        try {
            var n = feature.attribute("name")
            if (n !== null && n !== undefined && String(n) !== "")
                return String(n)
        } catch (e) {}
        try { return "Point " + feature.id() } catch (e2) {}
        return "Target"
    }

    function distanceText() {
        if (!navigation || !navigation.isActive) return "--"
        var d = Number(navigation.distance)
        if (!isFinite(d)) return "--"
        if (d < 1) return d.toFixed(2) + " m"
        if (d < 1000) return d.toFixed(1) + " m"
        return (d / 1000).toFixed(3) + " km"
    }

    function accuracyText() {
        try {
            var p = iface.positioning()
            var pi = p.positionInformation
            if (pi && pi.haccValid) return Number(pi.hacc).toFixed(2) + " m"
        } catch (e) {}
        return "--"
    }

    function fixText() {
        try {
            var p = iface.positioning()
            var pi = p.positionInformation
            if (pi && pi.fixStatusDescription) return String(pi.fixStatusDescription)
        } catch (e) {}
        return "--"
    }

    QfToolButton {
        id: stakeoutButton
        bgcolor: "#b71c1c"
        iconSource: "stakeout.svg"
        iconColor: "white"
        round: true
        width: 56
        height: 56

        onClicked: {
            if (active) clearStakeout()
            else beginPick()
        }

        Text {
            anchors.centerIn: parent
            text: "STAKE"
            color: "white"
            font.bold: true
            font.pixelSize: 10
        }
    }

    Timer {
        interval: 500
        running: active
        repeat: true
        onTriggered: stakeoutPanel.visible = true
    }

    Rectangle {
        id: stakeoutPanel
        parent: mainWindow.contentItem
        visible: false
        z: 10000
        width: Math.min(mainWindow.width * 0.90, 430)
        height: 300
        x: (mainWindow.width - width) / 2
        y: 75
        radius: 14
        color: "#202124"
        border.color: "#777777"
        border.width: 1

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 16
            spacing: 8

            Label {
                id: statusText
                Layout.fillWidth: true
                text: "TAP THE TARGET POINT"
                color: "#7CFC00"
                font.pixelSize: 20
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
            }

            Label {
                Layout.fillWidth: true
                text: targetName
                color: "#dddddd"
                font.pixelSize: 17
                horizontalAlignment: Text.AlignHCenter
                elide: Text.ElideMiddle
            }

            Rectangle {
                Layout.fillWidth: true
                height: 145
                radius: 10
                color: "#111111"

                Column {
                    anchors.centerIn: parent
                    spacing: 2

                    Label {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: distanceText()
                        color: "white"
                        font.pixelSize: 38
                        font.bold: true
                    }

                    Item {
                        width: 100
                        height: 70
                        anchors.horizontalCenter: parent.horizontalCenter

                        Text {
                            id: directionArrow
                            anchors.centerIn: parent
                            text: "↑"
                            color: "#7CFC00"
                            font.pixelSize: 68
                            font.bold: true
                            renderType: Text.NativeRendering

                            // QField navigation bearing is degrees clockwise
                            // from north. Rotate the arrow to point toward
                            // the destination relative to the current
                            // device/map orientation supplied by navigation.
                            rotation: Number(navigation && navigation.bearing) || 0
                        }
                    }

                    Label {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: "DIRECTION TO TARGET"
                        color: "#dddddd"
                        font.pixelSize: 14
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true

                Label {
                    Layout.fillWidth: true
                    text: "GNSS ± " + accuracyText()
                    color: "#cccccc"
                    font.pixelSize: 14
                }

                Label {
                    Layout.fillWidth: true
                    text: "Fix: " + fixText()
                    color: "#cccccc"
                    font.pixelSize: 14
                    horizontalAlignment: Text.AlignRight
                }
            }

            Label {
                Layout.fillWidth: true
                text: (navigation && navigation.isActive &&
                       Number(navigation.distance) <= arrivalThreshold)
                      ? "✓ ARRIVED — within " + arrivalThreshold.toFixed(1) + " m"
                      : ""
                color: "#7CFC00"
                font.pixelSize: 15
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                Button {
                    Layout.fillWidth: true
                    text: "Pick Another"
                    onClicked: beginPick()
                }

                Button {
                    Layout.fillWidth: true
                    text: "Clear"
                    onClicked: clearStakeout()
                }

                Button {
                    Layout.fillWidth: true
                    text: "Close"
                    onClicked: stakeoutPanel.visible = false
                }
            }
        }
    }
}
