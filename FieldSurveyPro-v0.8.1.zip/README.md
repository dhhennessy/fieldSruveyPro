# FieldSurvey Pro 0.8.1

Compatibility repair of 0.8.0.

This version intentionally uses the same QField import/module pattern as the working 0.7 build and the current official plugin examples. It implements a conservative point-collection workflow only.

Install through QField -> Settings -> Plugins -> Install plugin from URL using a direct ZIP URL.

The active QField layer must be an editable point layer.
