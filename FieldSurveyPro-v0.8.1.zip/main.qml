import QtQuick
import QtQuick.Controls
import QtCore
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    objectName: "fieldSurveyPro"

    property var dashBoard: iface.findItemByObjectName("dashBoard")
    property var overlayFeatureFormDrawer: iface.findItemByObjectName("overlayFeatureFormDrawer")
    property var positioning: iface.positioning()
    property var mainWindow: iface.mainWindow()

    Settings {
        id: settings
        category: "FieldSurveyPro"
        property int pointCounter: 1
        property string pointPrefix: "PT-"
    }

    function pointId() {
        return settings.pointPrefix + ("000000" + settings.pointCounter).slice(-6)
    }

    function addPoint() {
        try {
            dashBoard.ensureEditableLayerSelected()
        } catch (e) {}

        if (!dashBoard || !dashBoard.activeLayer) {
            mainWindow.displayToast("Select an editable point layer first")
            return
        }

        var p = positioning ? positioning.projectedPosition : null
        if (!p) {
            mainWindow.displayToast("No valid GNSS position")
            return
        }

        var wkt = "POINT(" + p.x + " " + p.y + ")"
        var geometry = GeometryUtils.createGeometryFromWkt(wkt)
        var feature = FeatureUtils.createFeature(dashBoard.activeLayer, geometry)
        var id = pointId()

        try {
            var fields = feature.fields()
            var i = fields.indexOf("name")
            if (i >= 0) feature.setAttribute("name", id)
            i = fields.indexOf("id")
            if (i >= 0) feature.setAttribute("id", id)
            i = fields.indexOf("feature_id")
            if (i >= 0) feature.setAttribute("feature_id", id)
        } catch (e) {}

        settings.pointCounter++

        if (!overlayFeatureFormDrawer) {
            mainWindow.displayToast(id + " created")
            return
        }

        overlayFeatureFormDrawer.featureModel.feature = feature
        overlayFeatureFormDrawer.state = "Add"
        overlayFeatureFormDrawer.open()
    }

    QfToolButton {
        id: surveyButton
        objectName: "fieldSurveyProButton"
        bgcolor: Theme.darkGray
        iconSource: "icon.svg"
        iconColor: Theme.mainColor
        round: true
        onClicked: panel.open()
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(surveyButton)
        mainWindow.displayToast("FieldSurvey Pro 0.8.1 loaded")
    }

    Dialog {
        id: panel
        parent: mainWindow.contentItem
        title: "FieldSurvey Pro"
        modal: true
        width: Math.min(mainWindow.width - 32, 420)
        x: (mainWindow.width - width) / 2
        y: (mainWindow.height - height) / 2

        Column {
            width: parent.width
            spacing: 10

            Label {
                width: parent.width
                text: "Point collection"
                font.bold: true
            }

            Label {
                width: parent.width
                text: "Next point: " + pointId()
            }

            Button {
                width: parent.width
                text: "COLLECT POINT  " + pointId()
                onClicked: {
                    addPoint()
                    panel.close()
                }
            }

            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                text: "Select an editable point layer before collecting. The current QField GNSS/projected position is used."
            }

            Button {
                width: parent.width
                text: "CLOSE"
                onClicked: panel.close()
            }
        }
    }

    function configure() {
        panel.open()
    }
}
