import QtQuick
import QtQuick.Controls
import org.qfield
import Theme

Item {
    id: plugin
    objectName: "fieldSurveyPro"

    property var pointLayer: null

    function findPointLayer() {
        if (!qgisProject)
            return null

        var layers = qgisProject.mapLayersByName("FieldSurveyPro_Points")
        if (layers && layers.length > 0)
            return layers[0]

        return null
    }

    function preparePointLayer() {
        pointLayer = findPointLayer()

        if (!pointLayer) {
            iface.mainWindow().displayToast(
                "FieldSurveyPro_Points is not in this project. Add an editable point layer named FieldSurveyPro_Points first."
            )
            return false
        }

        try {
            if (!pointLayer.isEditable())
                pointLayer.startEditing()
        } catch (e) {
            iface.mainWindow().displayToast("Could not make point layer editable")
            return false
        }

        iface.mainWindow().displayToast("FieldSurveyPro_Points is ready for collection")
        return true
    }

    Rectangle {
        id: button
        width: 1
        height: 1
        visible: false
    }

    Component.onCompleted: {
        preparePointLayer()
        iface.mainWindow().displayToast("FieldSurvey Pro loaded")
    }
}
