# FieldSurvey Pro 0.10.5

GNSS data-field compatibility fix.

## Fix
The previous build was using property names that are not the current
QField QfGnssPositionInformation API names. That caused the UI to show
NaN accuracy values and undefined satellite counts.

This build uses:
- `hacc` for horizontal accuracy
- `vacc` for vertical accuracy
- `pdop` for PDOP
- `satellitesUsed` for satellites used
- `utcDateTime` for the GNSS timestamp

The point collector now also treats missing GNSS quality measurements as
not meeting a quality lock instead of accidentally treating NaN as valid.

A 500 ms UI refresh keeps the displayed GNSS information current while
the FieldSurvey Pro panel is open.

All existing point naming, GNSS quality controls, 5-ft distance-based
line collection, and automatic per-line layer behavior are retained.
