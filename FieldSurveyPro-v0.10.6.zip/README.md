# FieldSurvey Pro 0.10.6

Fixes the GNSS quality-lock toggle.

The quality lock now uses an explicit live plugin property. Toggling the
checkbox immediately changes the collection rule and the interface reports
QUALITY LOCK ON/OFF.

OFF:
- Any valid GNSS position can be collected.

ON:
- Horizontal accuracy must be within the configured limit.
- Vertical accuracy must be within the configured limit.
- PDOP must be within the configured limit.
- Minimum satellite count must be met.
- If RTK-only is enabled, the reported quality must contain RTK.
- Missing/invalid accuracy values do not pass.

The persistent Settings value is still updated so the selected state
survives plugin reloads.
