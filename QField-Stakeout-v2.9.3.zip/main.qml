import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    property var mainWindow: iface.mainWindow()
    property var pointHandler: null
    property bool picking: false
    property var targetLayer: null
    property var targetFeature: null

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(stakeButton)
    }

    function startPicking() {
        pointHandler = iface.findItemByObjectName("pointHandler")
        if (!pointHandler) {
            mainWindow.displayToast("STAKEOUT: pointHandler NOT FOUND")
            return
        }

        try { pointHandler.deregisterHandler("FieldSurveyProStakeout293") } catch (e) {}
        picking = true
        targetLayer = null
        targetFeature = null
        mainWindow.displayToast("STAKEOUT: TAP A POINT")

        pointHandler.registerHandler(
            "FieldSurveyProStakeout293",
            function(point, type, interactionType) {
                if (!picking || interactionType !== "clicked")
                    return false

                var layers = qgisProject.mapLayersByName("FieldSurveyPro_Points")
                if (!layers || layers.length === 0) {
                    mainWindow.displayToast("LAYER NOT FOUND")
                    return true
                }

                var layer = layers[0]
                targetLayer = layer

                // Use the QField expression iterator rather than featureCount()
                // or the generic iterator. QField documents this API explicitly.
                var it = null
                try {
                    it = LayerUtils.createFeatureIteratorFromExpression(layer, "1=1")
                } catch (e1) {
                    mainWindow.displayToast("EXPR ITERATOR ERROR: " + e1)
                    return true
                }

                if (!it) {
                    mainWindow.displayToast("EXPR ITERATOR IS NULL")
                    return true
                }

                if (!it.hasNext()) {
                    mainWindow.displayToast("EXPR ITERATOR: NO FEATURES")
                    return true
                }

                var f = it.next()
                if (!f) {
                    mainWindow.displayToast("EXPR ITERATOR: EMPTY FEATURE")
                    return true
                }

                targetFeature = f

                var fid = "?"
                try { fid = String(f.id) } catch (e2) {}

                var name = ""
                try { name = String(f.attribute("name")) } catch (e3) {}

                var geomText = ""
                try {
                    var g = f.geometry
                    geomText = g ? String(g.asWkt()) : "NO GEOMETRY"
                } catch (e4) {
                    geomText = "GEOMETRY ERROR"
                }

                mainWindow.displayToast(
                    "TARGET: id=" + fid + " name=" + name)
                console.log("STAKEOUT 2.9.3 target: " + geomText)

                picking = false
                return true
            },
            100
        )
    }

    QfToolButton {
        id: stakeButton
        width: 56
        height: 56
        iconSource: Theme.getThemeVectorIcon("ic_navigation_white_24dp")
        iconColor: Theme.toolButtonColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true
        onClicked: startPicking()

        Text {
            anchors.centerIn: parent
            text: "STAKE"
            color: "white"
            font.bold: true
            font.pixelSize: 10
        }
    }
}
