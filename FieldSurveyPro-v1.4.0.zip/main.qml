import QtQuick 2.12
import QtQuick.Controls 2.12
import org.qfield 1.0

Item {
    id: root

    function toast(msg) {
        try {
            iface.mainWindow().displayToast(msg)
        } catch (e) {}
    }

    // This intentionally keeps the plugin minimal. QField already provides
    // dataset export through its file/project UI; this plugin adds a simple
    // project-level reminder/action rather than attempting unsupported
    // provider-level Shapefile writing from QML.
    Component.onCompleted: {
        toast("FieldSurvey Pro: use QField's Export dataset action to create a Shapefile.")
    }
}
