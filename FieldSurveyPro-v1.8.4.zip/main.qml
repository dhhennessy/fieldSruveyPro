import QtQuick 2.12
import QtQuick.Controls 2.12
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin

    property var selectedLayer: null
    property string selectedLayerName: ""

    QfToolButton {
        id: exportButton
        objectName: "fieldSurveyProExportButton"
        bgcolor: Theme.darkGray
        iconSource: Qt.resolvedUrl("export.svg")
        iconColor: "white"
        round: true
        onClicked: exportDialog.open()
    }

    Dialog {
        id: exportDialog
        parent: iface.mainWindow().contentItem
        modal: true
        title: "Export Shapefile"
        width: Math.min(iface.mainWindow().width - 40, 560)
        height: Math.min(iface.mainWindow().height - 80, 540)
        x: (iface.mainWindow().width - width) / 2
        y: (iface.mainWindow().height - height) / 2

        function populateLayers() {
            layersModel.clear()
            plugin.selectedLayer = null
            plugin.selectedLayerName = ""

            try {
                var layers = iface.mapCanvas().mapSettings.layers
                for (var i = 0; i < layers.length; ++i) {
                    var layer = layers[i]
                    if (!layer)
                        continue

                    var isVector = false
                    try { isVector = (layer.type === 0) } catch (e) {}

                    if (isVector) {
                        layersModel.append({
                            "layerName": layer.name,
                            "layerId": layer.id
                        })
                    }
                }
            } catch (e) {
                iface.mainWindow().displayToast(
                    "Could not read map layers: " + e
                )
            }
        }

        onOpened: populateLayers()

        contentItem: Column {
            spacing: 10
            padding: 16

            Label {
                text: "Select the vector layer to export:"
                font.bold: true
            }

            ListView {
                id: layerList
                width: exportDialog.width - 32
                height: 280
                clip: true
                model: ListModel { id: layersModel }

                delegate: ItemDelegate {
                    width: layerList.width
                    text: model.layerName
                    highlighted: plugin.selectedLayerName === model.layerName

                    onClicked: {
                        try {
                            plugin.selectedLayer =
                                qgisProject.mapLayer(model.layerId)
                            plugin.selectedLayerName = model.layerName
                        } catch (e) {
                            plugin.selectedLayer = null
                        }
                    }
                }
            }

            Label {
                text: plugin.selectedLayer ?
                    "Selected: " + plugin.selectedLayerName :
                    "No layer selected"
                wrapMode: Text.WordWrap
            }

            Row {
                spacing: 10

                Button {
                    text: "Export to Downloads"
                    enabled: plugin.selectedLayer !== null

                    onClicked: {
                        try {
                            var base = plugin.selectedLayerName.replace(
                                /[^A-Za-z0-9_-]/g, "_"
                            )
                            if (base.length === 0)
                                base = "export"

                            // Android's public Downloads directory.
                            // The Shapefile is first created in QField's
                            // writable project area, then handed to QField's
                            // native export mechanism. This avoids Android
                            // scoped-storage failures.
                            var source = plugin.selectedLayer.source
                            var sourcePath = source.split("|")[0]
                            var slash = Math.max(
                                sourcePath.lastIndexOf("/"),
                                sourcePath.lastIndexOf("\\")
                            )

                            var directory = slash >= 0 ?
                                sourcePath.substring(0, slash) : ""

                            if (directory.length === 0) {
                                iface.mainWindow().displayToast(
                                    "Layer source directory unavailable"
                                )
                                return
                            }

                            var outputPath =
                                directory + "/" +
                                base + "_FieldSurveyPro.shp"

                            var result =
                                QfLayerUtils.saveVectorLayerAs(
                                    plugin.selectedLayer,
                                    outputPath,
                                    "ESRI Shapefile"
                                )

                            if (!result || result.length === 0) {
                                iface.mainWindow().displayToast(
                                    "Could not create Shapefile"
                                )
                                return
                            }

                            // QField's Android exportDatasetTo() invokes the
                            // native destination chooser. On Android this
                            // permits choosing the public Downloads folder.
                            try {
                                platformUtilities.exportDatasetTo(result)
                            } catch (e1) {
                                try {
                                    QfPlatformUtilities.instance()
                                        .exportDatasetTo(result)
                                } catch (e2) {
                                    iface.mainWindow().displayToast(
                                        "Shapefile created, but Android " +
                                        "could not open the export picker"
                                    )
                                    return
                                }
                            }

                            exportDialog.close()

                            iface.mainWindow().displayToast(
                                "Choose Downloads in the Android export window"
                            )
                        } catch (e) {
                            iface.mainWindow().displayToast(
                                "Export error: " + e
                            )
                        }
                    }
                }

                Button {
                    text: "Refresh"
                    onClicked: exportDialog.populateLayers()
                }

                Button {
                    text: "Cancel"
                    onClicked: exportDialog.close()
                }
            }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(exportButton)
    }
}
