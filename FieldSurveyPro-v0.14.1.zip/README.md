# FieldSurvey Pro 0.14.1

Fixes point collection behavior when GNSS quality limits are disabled.

## Point collection
QUALITY LOCK OFF:
- Does not require horizontal accuracy.
- Does not require vertical accuracy.
- Does not require PDOP.
- Does not require a satellite count.
- Uses QField's current projected GNSS position to create the point.
- If QField cannot provide finite projected coordinates, it reports that
  explicitly.

QUALITY LOCK ON:
- Requires valid GNSS position and all configured quality limits.

The point button is enabled when the quality lock is OFF so that the plugin
does not incorrectly block collection merely because GNSS quality metadata
is unavailable.

The GNSS display now uses QField's fixStatusDescription and falls back to
satellitesInView when satellitesUsed is zero but satellite information is
available.

All existing point naming, line collection, and automatic line-layer
functionality remains unchanged.
