# FieldSurvey Pro 0.10.0

Adds distance-based GNSS line collection to the working 0.9.1 point collector.

## Line collection
- Enter any line name.
- Select an editable line layer.
- Start Line records the current GNSS position as the first vertex.
- Additional vertices are committed every 5 ft (1.524 m) of movement.
- Finish Line creates one line feature.
- Internal line IDs are LN-000001, LN-000002, etc.
- The user-entered name is stored in `name`.
- Vertex count and accumulated distance are stored when matching fields exist.
- GNSS QA fields are stored when matching fields exist.

The timer used internally only samples the current GNSS position so the plugin can detect movement. It does not create vertices on a time interval. Vertex creation is distance-based.

Recommended line-layer fields:
name, id, feature_id, vertex_count, length_m, gnss_status,
h_accuracy, v_accuracy, pdop, satellites, gnss_source

The point collector and GNSS quality controls from 0.9.1 remain unchanged.
