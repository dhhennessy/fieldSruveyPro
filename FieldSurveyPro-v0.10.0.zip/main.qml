import QtQuick
import QtQuick.Controls
import QtCore
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    objectName: "fieldSurveyPro"

    property var dashBoard: iface.findItemByObjectName("dashBoard")
    property var overlayFeatureFormDrawer: iface.findItemByObjectName("overlayFeatureFormDrawer")
    property var positioning: iface.positioning()
    property var mainWindow: iface.mainWindow()

    Settings {
        id: settings
        category: "FieldSurveyPro"
        property int pointCounter: 1
        property string pointPrefix: "PT-"
        property string lastPointName: ""
        property int lineCounter: 1
        property string linePrefix: "LN-"
        property bool qualityLock: false
        property real maxHorizontalAccuracy: 0.10
        property real maxVerticalAccuracy: 0.20
        property real maxPdop: 3.0
        property int minSatellites: 8
        property bool rtkOnly: false
    }

    function pointId() {
        return settings.pointPrefix + ("000000" + settings.pointCounter).slice(-6)
    }

    function fieldIndex(layer, fieldName) {
        if (!layer || !layer.fields)
            return -1
        return layer.fields.indexOf(fieldName)
    }

    function setIfPresent(feature, layer, fieldName, value) {
        if (fieldIndex(layer, fieldName) >= 0)
            feature.setAttribute(fieldName, value)
    }

    function gnssInfo() {
        if (!positioning || !positioning.active)
            return null
        return positioning.positionInformation
    }

    function hasValidPosition(info) {
        return info &&
               info.longitudeValid &&
               info.latitudeValid
    }

    function qualityPasses(info) {
        if (!settings.qualityLock)
            return true
        if (!hasValidPosition(info))
            return false

        if (Number(info.horizontalAccuracy) > settings.maxHorizontalAccuracy)
            return false
        if (Number(info.verticalAccuracy) > settings.maxVerticalAccuracy)
            return false
        if (Number(info.pdop) > settings.maxPdop)
            return false
        if (Number(info.numberOfUsedSatellites) < settings.minSatellites)
            return false

        if (settings.rtkOnly &&
            String(info.qualityDescription).toLowerCase().indexOf("rtk") < 0)
            return false

        return true
    }

    function qualityReason(info) {
        if (!info)
            return "GNSS positioning is inactive"
        if (!hasValidPosition(info))
            return "No valid GNSS position"
        if (Number(info.horizontalAccuracy) > settings.maxHorizontalAccuracy)
            return "Horizontal accuracy is above limit"
        if (Number(info.verticalAccuracy) > settings.maxVerticalAccuracy)
            return "Vertical accuracy is above limit"
        if (Number(info.pdop) > settings.maxPdop)
            return "PDOP is above limit"
        if (Number(info.numberOfUsedSatellites) < settings.minSatellites)
            return "Too few satellites"
        if (settings.rtkOnly &&
            String(info.qualityDescription).toLowerCase().indexOf("rtk") < 0)
            return "RTK-only requirement not met"
        return "Quality requirements met"
    }


    property bool lineRecording: false
    property var lineVertices: []
    property real lineDistance: 0.0
    property var lastLinePosition: null
    property string currentLineName: ""

    readonly property real lineVertexSpacingMeters: 1.524

    function lineId() {
        return settings.linePrefix + ("000000" + settings.lineCounter).slice(-6)
    }

    function distanceBetween(a, b) {
        if (!a || !b)
            return 0.0
        const dx = Number(a.x) - Number(b.x)
        const dy = Number(a.y) - Number(b.y)
        return Math.sqrt(dx * dx + dy * dy)
    }

    function lineInfoText() {
        if (!lineRecording)
            return "Line: not recording"
        return "Line: " + currentLineName +
               "\nVertices: " + lineVertices.length +
               "\nDistance: " + lineDistance.toFixed(2) + " m" +
               "\nVertex interval: 5 ft (1.524 m)"
    }

    function startLine() {
        dashBoard.ensureEditableLayerSelected()

        if (!dashBoard.activeLayer) {
            mainWindow.displayToast("Select an editable line layer first")
            return
        }

        const layer = dashBoard.activeLayer
        const geometryType = layer.geometryType
        if (geometryType !== 1) {
            mainWindow.displayToast("Select an editable line layer")
            return
        }

        const requestedName = lineNameField.text.trim()
        if (requestedName.length === 0) {
            mainWindow.displayToast("Enter a line name")
            return
        }

        const info = gnssInfo()
        if (!hasValidPosition(info)) {
            mainWindow.displayToast("No valid GNSS position")
            return
        }
        if (!qualityPasses(info)) {
            mainWindow.displayToast(qualityReason(info))
            return
        }

        const p = positioning.projectedPosition
        lineVertices = [ { x: Number(p.x), y: Number(p.y) } ]
        lastLinePosition = { x: Number(p.x), y: Number(p.y) }
        lineDistance = 0.0
        currentLineName = requestedName
        lineRecording = true

        mainWindow.displayToast("Line started")
    }

    function sampleLinePosition() {
        if (!lineRecording)
            return

        const info = gnssInfo()
        if (!hasValidPosition(info))
            return
        if (!qualityPasses(info))
            return

        const p = positioning.projectedPosition
        const current = { x: Number(p.x), y: Number(p.y) }
        const d = distanceBetween(lastLinePosition, current)

        // Vertices are distance-driven, not time-driven. The timer only
        // checks for movement; a vertex is committed only after 5 ft.
        if (d < lineVertexSpacingMeters)
            return

        // If a GNSS update jumps more than one interval, place vertices
        // at 5-ft increments along the traveled segment.
        const ux = (current.x - lastLinePosition.x) / d
        const uy = (current.y - lastLinePosition.y) / d
        let remaining = d
        let anchor = { x: lastLinePosition.x, y: lastLinePosition.y }

        while (remaining >= lineVertexSpacingMeters) {
            anchor = {
                x: anchor.x + ux * lineVertexSpacingMeters,
                y: anchor.y + uy * lineVertexSpacingMeters
            }
            lineVertices.push({ x: anchor.x, y: anchor.y })
            lineDistance += lineVertexSpacingMeters
            remaining -= lineVertexSpacingMeters
        }

        lastLinePosition = current
    }

    function finishLine() {
        if (!lineRecording)
            return

        if (lineVertices.length < 2) {
            lineRecording = false
            mainWindow.displayToast("Move at least 5 ft before finishing")
            return
        }

        const layer = dashBoard.activeLayer
        const coords = []
        for (let i = 0; i < lineVertices.length; i++)
            coords.push(lineVertices[i].x + " " + lineVertices[i].y)

        const wkt = "LINESTRING(" + coords.join(",") + ")"
        const geometry = GeometryUtils.createGeometryFromWkt(wkt)
        const feature = FeatureUtils.createFeature(layer, geometry)
        const id = lineId()
        const info = gnssInfo()

        setIfPresent(feature, layer, "name", currentLineName)
        setIfPresent(feature, layer, "id", id)
        setIfPresent(feature, layer, "feature_id", id)
        setIfPresent(feature, layer, "vertex_count", lineVertices.length)
        setIfPresent(feature, layer, "length_m", lineDistance)
        if (info) {
            setIfPresent(feature, layer, "gnss_status", info.qualityDescription)
            setIfPresent(feature, layer, "h_accuracy", info.horizontalAccuracy)
            setIfPresent(feature, layer, "v_accuracy", info.verticalAccuracy)
            setIfPresent(feature, layer, "pdop", info.pdop)
            setIfPresent(feature, layer, "satellites", info.numberOfUsedSatellites)
            setIfPresent(feature, layer, "gnss_source", info.sourceName)
        }

        settings.lineCounter = settings.lineCounter + 1

        lineRecording = false
        lineVertices = []
        lastLinePosition = null
        lineDistance = 0.0
        currentLineName = ""

        mainWindow.displayToast("Line saved: " + id)
    }

    Timer {
        id: lineSampler
        interval: 250
        repeat: true
        running: lineRecording
        onTriggered: sampleLinePosition()
    }

    function collectPoint() {
        const requestedName = pointNameField.text.trim()
        if (requestedName.length === 0) {
            mainWindow.displayToast("Enter a point name")
            return
        }
        dashBoard.ensureEditableLayerSelected()

        if (!dashBoard.activeLayer) {
            mainWindow.displayToast("Select an editable point layer first")
            return
        }

        const layer = dashBoard.activeLayer
        const info = gnssInfo()

        if (!hasValidPosition(info)) {
            mainWindow.displayToast("No valid GNSS position")
            return
        }

        if (!qualityPasses(info)) {
            mainWindow.displayToast(qualityReason(info))
            return
        }

        const projectedPosition = positioning.projectedPosition
        const wkt = "POINT(" + projectedPosition.x + " " + projectedPosition.y + ")"
        const geometry = GeometryUtils.createGeometryFromWkt(wkt)
        const feature = FeatureUtils.createFeature(layer, geometry)
        const id = pointId()

        setIfPresent(feature, layer, "name", requestedName)
        setIfPresent(feature, layer, "id", id)
        setIfPresent(feature, layer, "feature_id", id)

        setIfPresent(feature, layer, "gnss_status", info.qualityDescription)
        setIfPresent(feature, layer, "h_accuracy", info.horizontalAccuracy)
        setIfPresent(feature, layer, "v_accuracy", info.verticalAccuracy)
        setIfPresent(feature, layer, "pdop", info.pdop)
        setIfPresent(feature, layer, "satellites", info.numberOfUsedSatellites)
        setIfPresent(feature, layer, "gnss_source", info.sourceName)
        setIfPresent(feature, layer, "gnss_timestamp", info.timestamp)
        setIfPresent(feature, layer, "averaged_count", info.averagedCount)

        setIfPresent(feature, layer, "horizontal_accuracy", info.horizontalAccuracy)
        setIfPresent(feature, layer, "vertical_accuracy", info.verticalAccuracy)
        setIfPresent(feature, layer, "gnss_pdop", info.pdop)
        setIfPresent(feature, layer, "gnss_satellites", info.numberOfUsedSatellites)
        setIfPresent(feature, layer, "gnss_quality", info.qualityDescription)

        settings.pointCounter = settings.pointCounter + 1
        settings.lastPointName = requestedName

        overlayFeatureFormDrawer.featureModel.feature = feature
        overlayFeatureFormDrawer.state = "Add"
        overlayFeatureFormDrawer.open()
    }

    function statusText() {
        const info = gnssInfo()
        if (!info)
            return "GNSS: inactive"

        if (!hasValidPosition(info))
            return "GNSS: no valid fix"

        return "GNSS: " + info.qualityDescription +
               "\nH: " + Number(info.horizontalAccuracy).toFixed(3) + " m" +
               "   V: " + Number(info.verticalAccuracy).toFixed(3) + " m" +
               "\nPDOP: " + Number(info.pdop).toFixed(2) +
               "   Satellites: " + info.numberOfUsedSatellites +
               "\nQuality: " + qualityReason(info)
    }

    QfToolButton {
        id: surveyButton
        objectName: "fieldSurveyProButton"
        bgcolor: Theme.darkGray
        iconSource: "icon.svg"
        iconColor: Theme.mainColor
        round: true
        onClicked: panel.open()
    }

    Dialog {
        id: panel
        title: "FieldSurvey Pro"
        modal: true
        parent: mainWindow.contentItem
        width: Math.min(mainWindow.width - 40, 440)
        x: (mainWindow.width - width) / 2
        y: (mainWindow.height - height) / 2

        Column {
            width: parent.width
            spacing: 10

            Label {
                width: parent.width
                text: "GNSS Point Collection"
                font.bold: true
                font.pixelSize: 20
            }

            Label {
                width: parent.width
                text: "Next point ID: " + pointId()
            }

            Label {
                width: parent.width
                text: "Point name"
                font.bold: true
            }

            TextField {
                id: pointNameField
                width: parent.width
                text: settings.lastPointName.length > 0 ? "" : pointId()
                placeholderText: "Enter any name"
                selectByMouse: true
            }

            Label {
                width: parent.width
                text: statusText()
                wrapMode: Text.WordWrap
            }

            Button {
                width: parent.width
                text: "COLLECT POINT"
                enabled: qualityPasses(gnssInfo())
                onClicked: {
                    panel.close()
                    collectPoint()
                }
            }

            CheckBox {
                id: qualityLockBox
                text: "Require GNSS quality limits"
                checked: settings.qualityLock
                onCheckedChanged: settings.qualityLock = checked
            }

            CheckBox {
                id: rtkBox
                text: "Require RTK"
                checked: settings.rtkOnly
                onCheckedChanged: settings.rtkOnly = checked
                enabled: settings.qualityLock
            }

            Label {
                width: parent.width
                text: "Limits: H ≤ " + settings.maxHorizontalAccuracy.toFixed(2) +
                      " m, V ≤ " + settings.maxVerticalAccuracy.toFixed(2) +
                      " m, PDOP ≤ " + settings.maxPdop.toFixed(1) +
                      ", satellites ≥ " + settings.minSatellites
                wrapMode: Text.WordWrap
                enabled: settings.qualityLock
            }

            Label {
                width: parent.width
                text: "Line Collection"
                font.bold: true
                font.pixelSize: 18
            }

            TextField {
                id: lineNameField
                width: parent.width
                placeholderText: "Line name"
                text: ""
                enabled: !lineRecording
            }

            Label {
                width: parent.width
                text: lineInfoText()
                wrapMode: Text.WordWrap
            }

            Button {
                width: parent.width
                text: lineRecording ? "FINISH LINE" : "START LINE"
                onClicked: {
                    if (lineRecording)
                        finishLine()
                    else
                        startLine()
                }
            }

            Label {
                width: parent.width
                text: "Vertices are collected every 5 ft (1.524 m) of movement. The timer only checks the GNSS position; it does not determine vertex spacing."
                wrapMode: Text.WordWrap
            }

            Button {
                width: parent.width
                text: "Close"
                enabled: !lineRecording
                onClicked: panel.close()
            }
        }
    }

    function configure() {
        panel.open()
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(surveyButton)
        mainWindow.displayToast("FieldSurvey Pro 0.9.0 loaded")
    }
}
