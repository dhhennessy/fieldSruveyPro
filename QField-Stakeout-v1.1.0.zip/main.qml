import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin

    property var mainWindow: iface.mainWindow()
    property var navigation: iface.findItemByObjectName("navigation")
    property var pointHandler: iface.findItemByObjectName("pointHandler")
    property bool picking: false
    property bool active: false
    property string targetName: ""
    property real arrivalThreshold: 0.5

    Component.onCompleted: iface.addItemToPluginsToolbar(stakeoutButton)

    function beginPick() {
        if (!pointHandler) {
            mainWindow.displayToast("This QField version has no map point handler")
            return
        }

        picking = true
        active = false
        stakeoutPanel.visible = true
        statusText.text = "TAP A POINT ON THE MAP"
        try {
            pointHandler.registerHandler("fieldsurvey_stakeout", function(point, type, interactionType) {
                if (!picking || interactionType !== "clicked")
                    return

                var canvas = iface.mapCanvas()
                var mapPoint
                try {
                    mapPoint = canvas.mapSettings.screenToCoordinate(
                        Qt.point(point.x, point.y)
                    )
                } catch (e0) {
                    mainWindow.displayToast("Could not read map position")
                    return
                }

                var target = findPointAt(mapPoint)
                if (target) {
                    setTarget(target.layer, target.feature)
                    picking = false
                } else {
                    mainWindow.displayToast("No point feature at that location")
                }
            })
        } catch (e) {
            iface.logMessage("Stakeout point handler error: " + e)
            mainWindow.displayToast("Could not activate map picking")
        }
    }

    function findPointAt(point) {
        try {
            var ids = iface.mapCanvas().mapSettings.layers
            for (var i = 0; i < ids.length; i++) {
                var layer = qgisProject.mapLayer(ids[i])
                if (!layer) continue

                // Only inspect point layers.
                try {
                    if (Number(layer.geometryType) !== 0)
                        continue
                } catch (e0) {}

                try {
                    var box = point.buffer(0.75, 8).boundingBox()
                    var it = layer.getFeatures(box)
                    if (it) {
                        var f
                        while ((f = it.nextFeature())) {
                            if (f && f.isValid() && f.geometry() &&
                                f.geometry().distance(point) <= 1.0) {
                                return { layer: layer, feature: f }
                            }
                        }
                    }
                } catch (e1) {
                    // Older QField builds may not expose the iterator API.
                }
            }
        } catch (e2) {
            iface.logMessage("Stakeout point search error: " + e2)
        }
        return null
    }

    function setTarget(layer, feature) {
        try {
            navigation.setDestinationFeature(feature, layer)
            targetName = getTargetName(feature)
            active = true
            stakeoutPanel.visible = true
            statusText.text = "WALK TO TARGET"
            mainWindow.displayToast("Stakeout: " + targetName)
        } catch (e) {
            iface.logMessage("Stakeout navigation error: " + e)
            mainWindow.displayToast("Could not start navigation")
        }
    }

    function clearStakeout() {
        try { navigation.clear() } catch (e) {
            try { navigation.clearDestinationFeature() } catch (e2) {}
        }
        try { pointHandler.unregisterHandler("fieldsurvey_stakeout") } catch (e3) {}
        picking = false
        active = false
        targetName = ""
        stakeoutPanel.visible = false
    }

    function getTargetName(feature) {
        try {
            var n = feature.attribute("name")
            if (n !== null && n !== undefined && String(n) !== "")
                return String(n)
        } catch (e) {}
        try { return "Point " + feature.id() } catch (e2) {}
        return "Target"
    }

    function distanceText() {
        if (!navigation || !navigation.isActive) return "--"
        var d = Number(navigation.distance)
        if (!isFinite(d)) return "--"
        if (d < 1) return d.toFixed(2) + " m"
        if (d < 1000) return d.toFixed(1) + " m"
        return (d / 1000).toFixed(3) + " km"
    }

    function bearingText() {
        if (!navigation || !navigation.isActive) return "--"
        var b = Number(navigation.bearing)
        if (!isFinite(b)) return "--"
        if (b < 0) b += 360
        return b.toFixed(1) + "°"
    }

    function accuracyText() {
        try {
            var p = iface.positioning()
            var pi = p.positionInformation
            if (pi && pi.haccValid) return Number(pi.hacc).toFixed(2) + " m"
        } catch (e) {}
        return "--"
    }

    function fixText() {
        try {
            var p = iface.positioning()
            var pi = p.positionInformation
            if (pi && pi.fixStatusDescription) return String(pi.fixStatusDescription)
        } catch (e) {}
        return "--"
    }

    QfToolButton {
        id: stakeoutButton
        bgcolor: "#b71c1c"
        iconSource: "stakeout.svg"
        iconColor: "white"
        round: true
        width: 56
        height: 56

        onClicked: {
            if (active) clearStakeout()
            else beginPick()
        }

        Text {
            anchors.centerIn: parent
            text: "STAKE"
            color: "white"
            font.bold: true
            font.pixelSize: 10
        }
    }

    Timer {
        interval: 500
        running: active
        repeat: true
        onTriggered: stakeoutPanel.visible = true
    }

    Rectangle {
        id: stakeoutPanel
        parent: mainWindow.contentItem
        visible: false
        z: 10000
        width: Math.min(mainWindow.width * 0.90, 430)
        height: 300
        x: (mainWindow.width - width) / 2
        y: 75
        radius: 14
        color: "#202124"
        border.color: "#777777"
        border.width: 1

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 16
            spacing: 8

            Label {
                id: statusText
                Layout.fillWidth: true
                text: "TAP A POINT ON THE MAP"
                color: "#7CFC00"
                font.pixelSize: 20
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
            }

            Label {
                Layout.fillWidth: true
                text: targetName
                color: "#dddddd"
                font.pixelSize: 17
                horizontalAlignment: Text.AlignHCenter
                elide: Text.ElideMiddle
            }

            Rectangle {
                Layout.fillWidth: true
                height: 105
                radius: 10
                color: "#111111"

                Column {
                    anchors.centerIn: parent
                    spacing: 4

                    Label {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: distanceText()
                        color: "white"
                        font.pixelSize: 38
                        font.bold: true
                    }

                    Label {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: "BEARING  " + bearingText()
                        color: "#dddddd"
                        font.pixelSize: 18
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true

                Label {
                    Layout.fillWidth: true
                    text: "GNSS ± " + accuracyText()
                    color: "#cccccc"
                    font.pixelSize: 14
                }

                Label {
                    Layout.fillWidth: true
                    text: "Fix: " + fixText()
                    color: "#cccccc"
                    font.pixelSize: 14
                    horizontalAlignment: Text.AlignRight
                }
            }

            Label {
                Layout.fillWidth: true
                text: (navigation && navigation.isActive &&
                       Number(navigation.distance) <= arrivalThreshold)
                      ? "✓ ARRIVED — within " + arrivalThreshold.toFixed(1) + " m"
                      : ""
                color: "#7CFC00"
                font.pixelSize: 15
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                Button {
                    Layout.fillWidth: true
                    text: "Pick Another"
                    onClicked: beginPick()
                }

                Button {
                    Layout.fillWidth: true
                    text: "Clear"
                    onClicked: clearStakeout()
                }

                Button {
                    Layout.fillWidth: true
                    text: "Close"
                    onClicked: stakeoutPanel.visible = false
                }
            }
        }
    }
}
