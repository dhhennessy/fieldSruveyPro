import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    property var mainWindow: iface.mainWindow()

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(stakeButton)
    }

    QfToolButton {
        id: stakeButton
        width: 56
        height: 56
        iconSource: Theme.getThemeVectorIcon("ic_navigation_white_24dp")
        iconColor: Theme.toolButtonColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true

        onClicked: {
            mainWindow.displayToast("STAKEOUT READY")
        }

        Text {
            anchors.centerIn: parent
            text: "STAKE"
            color: "white"
            font.bold: true
            font.pixelSize: 10
        }
    }
}
