import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis

Item {
    id: plugin
    objectName: "fieldSurveyPro"

    property var exportButton: null
    property var currentVectorLayer: null

    function showToast(message) {
        try { iface.mainWindow().displayToast(message) } catch (e) {}
    }

    function getCurrentLayer() {
        try {
            var layer = iface.mapCanvas().currentLayer()
            if (layer && layer.type && layer.type() === 0)
                return layer
        } catch (e) {}
        return null
    }

    function exportCurrentLayer() {
        var layer = getCurrentLayer()
        if (!layer) {
            showToast("Select a vector layer first")
            exportDialog.open()
            return
        }

        currentVectorLayer = layer
        layerNameField.text = layer.name()
        exportDialog.open()
    }

    function doExport() {
        var layer = currentVectorLayer
        if (!layer) {
            showToast("No vector layer selected")
            return
        }

        var baseName = layerNameField.text.trim()
        if (baseName === "")
            baseName = layer.name()
        baseName = baseName.replace(/[^A-Za-z0-9_-]/g, "_")

        // Write the shapefile into the current QField project directory first.
        // QField's native platform export then opens its folder picker so the
        // user can choose where the finished dataset should be copied.
        var home = ""
        try { home = qgisProject.homePath() } catch (e) {}

        if (home === "") {
            showToast("Project folder is not available")
            return
        }

        var stamp = Date.now()
        var output = home + "/" + baseName + "_" + stamp + ".shp"
        var saved = ""

        try {
            if (typeof LayerUtils !== "undefined" &&
                    LayerUtils.saveVectorLayerAs) {
                saved = LayerUtils.saveVectorLayerAs(
                    layer, output, "ESRI Shapefile", "")
            } else if (typeof QfLayerUtils !== "undefined" &&
                       QfLayerUtils.saveVectorLayerAs) {
                saved = QfLayerUtils.saveVectorLayerAs(
                    layer, output, "ESRI Shapefile", "")
            }
        } catch (e) {
            saved = ""
        }

        if (!saved || saved === "") {
            showToast("Shapefile creation failed")
            return
        }

        try {
            if (typeof QfPlatformUtilities !== "undefined") {
                QfPlatformUtilities.instance().exportDatasetTo(saved)
                showToast("Choose a destination for the Shapefile")
                exportDialog.close()
                return
            }
        } catch (e) {}

        // Fallback for QField builds exposing platformUtilities as a global.
        try {
            if (typeof platformUtilities !== "undefined") {
                platformUtilities.exportDatasetTo(saved)
                showToast("Choose a destination for the Shapefile")
                exportDialog.close()
                return
            }
        } catch (e) {}

        // If the installed QField lacks the native export API, leave the
        // completed dataset in the project folder and tell the user where it is.
        showToast("Shapefile created in the QField project folder")
        exportDialog.close()
    }

    Button {
        id: toolbarButton
        objectName: "fieldSurveyProExportButton"
        text: "EXPORT\nSHP"
        width: 72
        height: 64
        font.pixelSize: 12

        background: Rectangle {
            radius: 8
            color: toolbarButton.pressed ? "#8b0000" : "#c62828"
            border.width: 1
            border.color: "#ffffff"
        }

        contentItem: Text {
            text: toolbarButton.text
            color: "white"
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
            font: toolbarButton.font
        }

        onClicked: plugin.exportCurrentLayer()
    }

    Dialog {
        id: exportDialog
        parent: iface.mainWindow().contentItem
        modal: true
        title: "Export Layer as Shapefile"
        width: Math.min(420, iface.mainWindow().width - 30)
        height: 230
        x: (iface.mainWindow().width - width) / 2
        y: (iface.mainWindow().height - height) / 2

        Column {
            anchors.fill: parent
            spacing: 12

            Label {
                width: parent.width
                text: currentVectorLayer
                      ? "Layer: " + currentVectorLayer.name()
                      : "Select a vector layer, then export."
                wrapMode: Text.WordWrap
            }

            Label {
                text: "Output filename:"
            }

            TextField {
                id: layerNameField
                width: parent.width
                placeholderText: "Shapefile name"
            }

            Row {
                width: parent.width
                spacing: 10

                Button {
                    text: "Export Shapefile"
                    onClicked: plugin.doExport()
                }

                Button {
                    text: "Cancel"
                    onClicked: exportDialog.close()
                }
            }
        }
    }

    Component.onCompleted: {
        // Add one visible, text-labelled action. No icon resources are used.
        try {
            iface.addItemToPluginsToolbar(toolbarButton)
        } catch (e) {
            showToast("FieldSurvey Pro loaded")
        }
    }
}
