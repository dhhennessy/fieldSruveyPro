import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin

    property var mainWindow: iface.mainWindow()
    property var navigation: iface.findItemByObjectName("navigation")
    property var pointHandler: iface.findItemByObjectName("pointHandler")

    property bool picking: false
    property bool active: false
    property string targetName: ""
    property real arrivalTolerance: 0.30
    property real switchToGridDistance: 3.0
    property real arrowRotation: 0
    property real forwardDelta: 0
    property real rightDelta: 0

    Component.onCompleted: iface.addItemToPluginsToolbar(stakeoutButton)

    function beginPick() {
        if (!pointHandler) {
            mainWindow.displayToast("QField point handler is unavailable")
            return
        }

        try { pointHandler.unregisterHandler("FieldSurveyProStakeout") } catch (e0) {}

        picking = true
        active = false
        stakeoutPanel.visible = true
        statusText.text = "SELECT STAKE POINT"

        pointHandler.registerHandler("FieldSurveyProStakeout",
            function(point, type, interactionType) {
                if (!picking || interactionType !== "clicked")
                    return false

                var canvas = iface.mapCanvas()
                var tl = canvas.mapSettings.screenToCoordinate(
                    Qt.point(point.x - 12, point.y - 12))
                var br = canvas.mapSettings.screenToCoordinate(
                    Qt.point(point.x + 12, point.y + 12))

                var rectangle
                try {
                    rectangle = GeometryUtils.createRectangleFromPoints(tl, br)
                } catch (e1) {
                    mainWindow.displayToast("Could not read map location")
                    return true
                }

                var layerIds = canvas.mapSettings.layers
                var found = false

                for (var i = 0; i < layerIds.length && !found; i++) {
                    var layer = qgisProject.mapLayer(layerIds[i])
                    if (!layer) continue

                    try {
                        if (Number(layer.geometryType) !== 0)
                            continue
                    } catch (e2) {
                        continue
                    }

                    try {
                        var iterator =
                            LayerUtils.createFeatureIteratorFromRectangle(
                                layer, rectangle)

                        if (iterator && iterator.hasNext()) {
                            var feature = iterator.next()
                            if (feature && feature.isValid()) {
                                setTarget(layer, feature)
                                found = true
                            }
                        }
                    } catch (e3) {
                        iface.logMessage("Stakeout search: " + e3)
                    }
                }

                if (!found)
                    mainWindow.displayToast("No point found there")

                return true
            })
    }

    function setTarget(layer, feature) {
        try {
            navigation.setMapSettings(iface.mapCanvas().mapSettings)
            navigation.setDestinationFeature(feature, layer)

            targetName = getTargetName(feature)
            active = true
            picking = false
            statusText.text = "STAKEOUT"
            mainWindow.displayToast("Stakeout: " + targetName)
        } catch (e) {
            iface.logMessage("Stakeout navigation: " + e)
            mainWindow.displayToast("Could not start stakeout")
        }
    }

    function clearStakeout() {
        try { navigation.clear() } catch (e) {
            try { navigation.clearDestinationFeature() } catch (e2) {}
        }
        try { pointHandler.unregisterHandler("FieldSurveyProStakeout") } catch (e3) {}

        picking = false
        active = false
        targetName = ""
        stakeoutPanel.visible = false
    }

    function getTargetName(feature) {
        try {
            var n = feature.attribute("name")
            if (n !== null && n !== undefined && String(n) !== "")
                return String(n)
        } catch (e) {}
        try { return "Point " + feature.id() } catch (e2) {}
        return "Target"
    }

    function distanceMeters() {
        if (!navigation || !navigation.isActive)
            return NaN

        var d = Number(navigation.distance)
        if (!isFinite(d) || d < 0)
            return NaN
        return d
    }

    function distanceText() {
        var d = distanceMeters()
        if (!isFinite(d)) return "--"
        if (d < 1) return d.toFixed(2) + " m"
        if (d < 1000) return d.toFixed(1) + " m"
        return (d / 1000).toFixed(3) + " km"
    }

    function travelDirection() {
        try {
            var pi = iface.positioning().positionInformation
            if (pi && pi.directionValid && Number(pi.speed) > 0.15) {
                var d = Number(pi.direction)
                if (isFinite(d)) return d
            }
        } catch (e) {}
        return NaN
    }

    function updateDeltas() {
        var d = distanceMeters()
        if (!isFinite(d)) {
            arrowRotation = 0
            forwardDelta = 0
            rightDelta = 0
            return
        }

        var targetBearing = Number(navigation.bearing)
        var travel = travelDirection()

        if (!isFinite(targetBearing) || !isFinite(travel)) {
            arrowRotation = 0
            forwardDelta = d
            rightDelta = 0
            return
        }

        var relative = targetBearing - travel
        while (relative > 180) relative -= 360
        while (relative < -180) relative += 360

        arrowRotation = relative

        var radians = relative * Math.PI / 180
        forwardDelta = d * Math.cos(radians)
        rightDelta = d * Math.sin(radians)
    }

    function accuracyText() {
        try {
            var pi = iface.positioning().positionInformation
            if (pi && pi.haccValid)
                return Number(pi.hacc).toFixed(2) + " m"
        } catch (e) {}
        return "--"
    }

    function fixText() {
        try {
            var pi = iface.positioning().positionInformation
            if (pi && pi.fixStatusDescription)
                return String(pi.fixStatusDescription)
        } catch (e) {}
        return "--"
    }

    QfToolButton {
        id: stakeoutButton
        bgcolor: "#b71c1c"
        iconSource: "stakeout.svg"
        iconColor: "white"
        round: true
        width: 56
        height: 56

        onClicked: {
            if (active || picking)
                clearStakeout()
            else
                beginPick()
        }

        Text {
            anchors.centerIn: parent
            text: "STAKE"
            color: "white"
            font.bold: true
            font.pixelSize: 10
        }
    }

    Timer {
        interval: 200
        running: active
        repeat: true
        onTriggered: updateDeltas()
    }

    Rectangle {
        id: stakeoutPanel
        parent: mainWindow.contentItem
        visible: false
        z: 10000
        width: Math.min(mainWindow.width * 0.94, 460)
        height: Math.min(mainWindow.height * 0.82, 590)
        x: (mainWindow.width - width) / 2
        y: Math.max(55, (mainWindow.height - height) / 2)
        radius: 14
        color: "#202124"
        border.color: "#666666"
        border.width: 1

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 14
            spacing: 8

            Label {
                id: statusText
                Layout.fillWidth: true
                text: "SELECT STAKE POINT"
                color: "#ffffff"
                font.pixelSize: 20
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
            }

            Label {
                Layout.fillWidth: true
                text: targetName
                color: "#dddddd"
                font.pixelSize: 18
                horizontalAlignment: Text.AlignHCenter
                elide: Text.ElideMiddle
            }

            // Trimble-style: large direction arrow when farther away.
            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 250
                radius: 12
                color: "#101010"
                visible: !active || distanceMeters() > switchToGridDistance

                Column {
                    anchors.centerIn: parent
                    spacing: 2

                    Text {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: "↑"
                        color: "#7CFC00"
                        font.pixelSize: 150
                        font.bold: true
                        rotation: arrowRotation
                    }

                    Label {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: distanceText()
                        color: "white"
                        font.pixelSize: 40
                        font.bold: true
                    }
                }
            }

            // Trimble-style close-in grid: forward/back and left/right.
            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 250
                radius: 12
                color: "#101010"
                visible: active && distanceMeters() <= switchToGridDistance

                Item {
                    anchors.fill: parent
                    anchors.margins: 18

                    Rectangle {
                        anchors.centerIn: parent
                        width: 150
                        height: 150
                        color: "transparent"
                        border.color: "#555555"
                        border.width: 1

                        Rectangle {
                            anchors.centerIn: parent
                            width: 10
                            height: 10
                            radius: 5
                            color: "#7CFC00"
                        }
                    }

                    Text {
                        anchors.centerIn: parent
                        text: "●"
                        color: "#ff3333"
                        font.pixelSize: 28
                        x: parent.width / 2 - width / 2 + rightDelta * 8
                        y: parent.height / 2 - height / 2 - forwardDelta * 8
                    }

                    Label {
                        anchors.horizontalCenter: parent.horizontalCenter
                        anchors.bottom: parent.bottom
                        text: "Forward " + Math.abs(forwardDelta).toFixed(2) + " m"
                        color: "#dddddd"
                        font.pixelSize: 15
                    }

                    Label {
                        anchors.left: parent.left
                        anchors.verticalCenter: parent.verticalCenter
                        text: rightDelta >= 0
                              ? "Right " + Math.abs(rightDelta).toFixed(2) + " m"
                              : "Left " + Math.abs(rightDelta).toFixed(2) + " m"
                        color: "#dddddd"
                        font.pixelSize: 15
                    }
                }
            }

            Label {
                Layout.fillWidth: true
                text: "Distance: " + distanceText()
                color: "white"
                font.pixelSize: 22
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
            }

            RowLayout {
                Layout.fillWidth: true

                Label {
                    Layout.fillWidth: true
                    text: "GNSS ± " + accuracyText()
                    color: "#cccccc"
                    font.pixelSize: 14
                }

                Label {
                    Layout.fillWidth: true
                    text: "Fix: " + fixText()
                    color: "#cccccc"
                    font.pixelSize: 14
                    horizontalAlignment: Text.AlignRight
                }
            }

            Rectangle {
                Layout.fillWidth: true
                height: 44
                radius: 8
                color: active && isFinite(distanceMeters()) &&
                       distanceMeters() <= arrivalTolerance
                       ? "#245c24" : "#303030"

                Label {
                    anchors.centerIn: parent
                    text: active && isFinite(distanceMeters()) &&
                          distanceMeters() <= arrivalTolerance
                          ? "✓ WITHIN TOLERANCE"
                          : "Tolerance: " + arrivalTolerance.toFixed(2) + " m"
                    color: active && isFinite(distanceMeters()) &&
                           distanceMeters() <= arrivalTolerance
                           ? "#7CFC00" : "#dddddd"
                    font.pixelSize: 16
                    font.bold: true
                }
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                Button {
                    Layout.fillWidth: true
                    text: "Next Point"
                    onClicked: beginPick()
                }

                Button {
                    Layout.fillWidth: true
                    text: "Clear"
                    onClicked: clearStakeout()
                }

                Button {
                    Layout.fillWidth: true
                    text: "Close"
                    onClicked: stakeoutPanel.visible = false
                }
            }
        }
    }
}
