import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    objectName: "fieldSurveyPro"

    property var pointLayer: null
    property var lineLayer: null
    property var polygonLayer: null
    property var featureFormDrawer: null

    property var linePoints: []
    property bool lineCollecting: false
    property real lineSpacing: 1.524
    property var lastAcceptedPoint: null

    property real hAcc: NaN
    property real vAcc: NaN
    property real pdop: NaN
    property int satellites: 0
    property string fixDescription: "Unknown"

    function findLayer(name) {
        if (!qgisProject) return null
        var layers = qgisProject.mapLayersByName(name)
        return layers && layers.length > 0 ? layers[0] : null
    }

    function prepareLayer(layer, label) {
        if (!layer) {
            iface.mainWindow().displayToast(label + " layer not found")
            return false
        }
        try {
            if (!layer.isEditable()) layer.startEditing()
        } catch (e) {
            iface.mainWindow().displayToast("Could not make " + label + " editable")
            return false
        }
        return true
    }

    function setup() {
        pointLayer = findLayer("FieldSurveyPro_Points")
        lineLayer = findLayer("FieldSurveyPro_Lines")
        polygonLayer = findLayer("FieldSurveyPro_Polygons")
        featureFormDrawer = iface.findItemByObjectName("overlayFeatureFormDrawer")

        var ok = true
        ok = prepareLayer(pointLayer, "Point") && ok
        ok = prepareLayer(lineLayer, "Line") && ok
        ok = prepareLayer(polygonLayer, "Polygon") && ok
        return ok
    }

    function refreshAccuracy() {
        var positioning = iface.positioning()
        if (!positioning || !positioning.positionInformation) {
            hAcc = NaN
            vAcc = NaN
            pdop = NaN
            satellites = 0
            fixDescription = "No GNSS"
            return
        }

        var info = positioning.positionInformation
        hAcc = Number(info.hacc)
        vAcc = Number(info.vacc)
        pdop = Number(info.pdop)
        satellites = Number(info.satellitesUsed)
        fixDescription = info.fixStatusDescription || info.qualityDescription || "Unknown"
    }

    function accuracyText() {
        var h = isFinite(hAcc) ? hAcc.toFixed(3) + " m" : "—"
        var v = isFinite(vAcc) ? vAcc.toFixed(3) + " m" : "—"
        var p = isFinite(pdop) ? pdop.toFixed(2) : "—"
        var s = satellites > 0 ? satellites : "—"
        return "Estimated accuracy  H: " + h + "   V: " + v +
               "\nPDOP: " + p + "   Satellites: " + s +
               "\nFix: " + fixDescription
    }

    function currentProjectedPoint() {
        var positioning = iface.positioning()
        if (!positioning || !positioning.valid) return null

        var p = positioning.sourcePosition
        if (!p || !isFinite(p.x) || !isFinite(p.y)) return null

        return QfGeometryUtils.reprojectPoint(
            p,
            CoordinateReferenceSystemUtils.wgs84Crs(),
            lineLayer.crs
        )
    }

    function distance(a, b) {
        var dx = b.x - a.x
        var dy = b.y - a.y
        return Math.sqrt(dx * dx + dy * dy)
    }

    function interpolate(a, b, fraction) {
        return {
            x: a.x + (b.x - a.x) * fraction,
            y: a.y + (b.y - a.y) * fraction
        }
    }

    function addPointAtFiveFootIntervals(currentPoint) {
        if (!currentPoint) return

        if (linePoints.length === 0) {
            linePoints.push(currentPoint)
            lastAcceptedPoint = currentPoint
            vertexCount.text = "Vertices: 1"
            return
        }

        var previous = lastAcceptedPoint
        var remaining = distance(previous, currentPoint)

        if (remaining < lineSpacing)
            return

        while (remaining >= lineSpacing) {
            var fraction = lineSpacing / remaining
            var nextPoint = interpolate(previous, currentPoint, fraction)

            linePoints.push(nextPoint)
            previous = nextPoint
            remaining = distance(previous, currentPoint)
        }

        lastAcceptedPoint = previous
        vertexCount.text = "Vertices: " + linePoints.length
    }

    function startLine() {
        refreshAccuracy()

        if (!lineLayer) {
            iface.mainWindow().displayToast("FieldSurveyPro_Lines not found")
            return
        }

        linePoints = []
        lastAcceptedPoint = null
        lineCollecting = true
        lineNameInput.text = ""
        vertexCount.text = "Vertices: 0"
        lineAccuracy.text = accuracyText()
        lineDialog.open()

        iface.mainWindow().displayToast("Line recording started — vertices every 5 ft")
    }

    function updateLine() {
        if (!lineCollecting)
            return

        refreshAccuracy()

        var p = currentProjectedPoint()
        if (p)
            addPointAtFiveFootIntervals(p)

        lineAccuracy.text = accuracyText()
    }

    function endLine() {
        if (!lineCollecting)
            return

        // Capture the current position. If it is more than 5 ft from
        // the previous accepted vertex, fill the remaining 5-ft intervals.
        var finalPoint = currentProjectedPoint()
        if (finalPoint)
            addPointAtFiveFootIntervals(finalPoint)

        if (linePoints.length < 2) {
            iface.mainWindow().displayToast("Move at least 5 ft to create a line")
            return
        }

        var wkt = "LINESTRING ("
        for (var i = 0; i < linePoints.length; i++) {
            if (i > 0) wkt += ", "
            wkt += linePoints[i].x + " " + linePoints[i].y
        }
        wkt += ")"

        var feature = FeatureUtils.createFeature(
            lineLayer,
            QfGeometryUtils.createGeometryFromWkt(wkt)
        )

        try { feature.setAttribute("name", lineNameInput.text.trim()) } catch (e) {}
        try { feature.setAttribute("notes", "Vertex spacing: 5 ft") } catch (e) {}

        try {
            featureFormDrawer.featureModel.feature = feature
            featureFormDrawer.state = "Add"

            if (featureFormDrawer.featureModel.create(true)) {
                linePoints = []
                lastAcceptedPoint = null
                lineCollecting = false
                lineDialog.close()

                try {
                    lineLayer.triggerRepaint()
                    iface.mapCanvas().refresh()
                } catch (e) {}

                iface.mainWindow().displayToast("Line saved")
                return
            }
        } catch (e) {}

        iface.mainWindow().displayToast("Line could not be saved")
    }

    // Custom toolbar buttons are drawn entirely in QML. This avoids the
    // iconSource/resource handling differences in older QField plugin APIs.
    Item {
        id: pointButton
        objectName: "fieldSurveyProPointButton"
        width: 52
        height: 52

        Rectangle {
            anchors.fill: parent
            radius: width / 2
            color: "#d32f2f"
            border.color: "white"
            border.width: 2

            Rectangle {
                anchors.centerIn: parent
                width: 18
                height: 18
                radius: 9
                color: "white"
            }
            Rectangle {
                anchors.centerIn: parent
                width: 5
                height: 5
                radius: 2.5
                color: "#d32f2f"
            }
            Rectangle {
                anchors.centerIn: parent
                width: 34
                height: 3
                radius: 1.5
                color: "white"
            }
            Rectangle {
                anchors.centerIn: parent
                width: 3
                height: 34
                radius: 1.5
                color: "white"
            }
        }

        MouseArea {
            anchors.fill: parent
            onClicked: pointDialog.open()
        }
    }

    Item {
        id: lineButton
        objectName: "fieldSurveyProLineButton"
        width: 52
        height: 52

        Rectangle {
            anchors.fill: parent
            radius: width / 2
            color: "#1976d2"
            border.color: "white"
            border.width: 2

            // Three connected vertices make the line tool visually distinct.
            Rectangle {
                x: 12; y: 29
                width: 29; height: 4
                radius: 2
                color: "white"
                rotation: -28
                transformOrigin: Item.Left
            }
            Rectangle {
                x: 27; y: 18
                width: 17; height: 4
                radius: 2
                color: "white"
                rotation: 32
                transformOrigin: Item.Left
            }
            Rectangle { x: 8;  y: 28; width: 10; height: 10; radius: 5; color: "white" }
            Rectangle { x: 24; y: 18; width: 10; height: 10; radius: 5; color: "white" }
            Rectangle { x: 39; y: 10; width: 10; height: 10; radius: 5; color: "white" }
        }

        MouseArea {
            anchors.fill: parent
            onClicked: startLine()
        }
    }

    Dialog {
        id: pointDialog
        parent: iface.mainWindow().contentItem
        title: "FieldSurvey Pro — Collect Point"
        modal: true
        anchors.centerIn: parent
        width: Math.min(parent.width - 40, 500)

        Column {
            width: parent.width
            spacing: 12

            TextField {
                id: pointNameInput
                width: parent.width
                placeholderText: "Point name (optional)"
            }

            Row {
                spacing: 10
                Button { text: "Cancel"; onClicked: pointDialog.close() }
                Button {
                    text: "Collect Point"
                    onClicked: {
                        pointDialog.close()
                        iface.mainWindow().displayToast("Point collection ready")
                    }
                }
            }
        }
    }

    Dialog {
        id: lineDialog
        parent: iface.mainWindow().contentItem
        title: "FieldSurvey Pro — Collect Line"
        modal: true
        anchors.centerIn: parent
        width: Math.min(parent.width - 40, 560)

        Column {
            width: parent.width
            spacing: 10

            TextField {
                id: lineNameInput
                width: parent.width
                placeholderText: "Line name (optional)"
            }

            Rectangle {
                width: parent.width
                height: 74
                radius: 6
                color: Theme.darkGray

                Label {
                    id: lineAccuracy
                    anchors.fill: parent
                    anchors.margins: 10
                    color: "white"
                    text: "Estimated accuracy"
                    wrapMode: Text.WordWrap
                    verticalAlignment: Text.AlignVCenter
                }
            }

            Label {
                id: vertexCount
                text: "Vertices: 0"
            }

            Label {
                text: "Automatic vertex spacing: 5 ft (1.524 m)"
                font.pixelSize: 13
            }

            Row {
                spacing: 8

                Button {
                    text: "End Feature"
                    enabled: lineCollecting
                    onClicked: endLine()
                }

                Button {
                    text: "Cancel"
                    onClicked: {
                        linePoints = []
                        lastAcceptedPoint = null
                        lineCollecting = false
                        lineDialog.close()
                    }
                }
            }
        }
    }

    Timer {
        id: lineTimer
        interval: 250
        repeat: true
        running: lineCollecting
        onTriggered: updateLine()
    }

    Component.onCompleted: {
        if (setup()) {
            iface.addItemToPluginsToolbar(pointButton)
            iface.addItemToPluginsToolbar(lineButton)
            iface.mainWindow().displayToast("Point and line collection ready")
        }
    }
}
