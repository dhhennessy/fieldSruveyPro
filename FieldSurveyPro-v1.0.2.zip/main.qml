import QtQuick
import org.qfield.org
import Theme

Item {
    id: plugin
    objectName: "fieldSurveyPro"

    QfToolButton {
        id: testButton
        objectName: "fieldSurveyProTestButton"
        bgcolor: Theme.darkGray
        iconSource: Theme.getThemeVectorIcon("ic_info_white_24dp")
        iconColor: Theme.toolButtonColor
        round: true

        onClicked: {
            iface.mainWindow().displayToast("FieldSurvey Pro is running")
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(testButton)
    }
}
