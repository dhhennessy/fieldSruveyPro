import QtQuick 2.12
import QtQuick.Controls 2.12
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    property var selectedLayer: null
    property string selectedLayerName: ""

    QfToolButton {
        id: exportButton
        objectName: "fieldSurveyProExportButton"
        bgcolor: "#D32F2F"
        iconSource: Qt.resolvedUrl("export.svg")
        iconColor: "white"
        round: true

        Text {
            anchors.centerIn: parent
            text: "QField Export"
            color: "white"
            font.bold: true
            font.pixelSize: 11
            z: 10
        }

        onClicked: {
            exportDialog.open()
        }
    }

    Dialog {
        id: exportDialog
        parent: iface.mainWindow().contentItem
        modal: true
        title: "Export Shapefile"
        width: Math.min(iface.mainWindow().width - 40, 560)
        height: Math.min(iface.mainWindow().height - 80, 540)
        x: (iface.mainWindow().width - width) / 2
        y: (iface.mainWindow().height - height) / 2

        function populateLayers() {
            layersModel.clear()
            plugin.selectedLayer = null
            plugin.selectedLayerName = ""

            try {
                var layers = iface.mapCanvas().mapSettings.layers
                for (var i = 0; i < layers.length; ++i) {
                    var layer = layers[i]
                    if (!layer)
                        continue

                    var isVector = false
                    try { isVector = (layer.type === 0) } catch (e) {}

                    if (isVector) {
                        layersModel.append({
                            "layerName": layer.name,
                            "layerId": layer.id
                        })
                    }
                }
            } catch (e) {
                iface.mainWindow().displayToast(
                    "Could not read map layers: " + e
                )
            }
        }

        onOpened: populateLayers()

        contentItem: Column {
            spacing: 10
            padding: 16

            Label {
                text: "Select the vector layer to export:"
                font.bold: true
            }

            ListView {
                id: layerList
                width: exportDialog.width - 32
                height: 280
                clip: true
                model: ListModel { id: layersModel }

                delegate: ItemDelegate {
                    width: layerList.width
                    text: model.layerName
                    highlighted: plugin.selectedLayerName === model.layerName

                    onClicked: {
                        try {
                            plugin.selectedLayer =
                                qgisProject.mapLayer(model.layerId)
                            plugin.selectedLayerName = model.layerName
                        } catch (e) {
                            plugin.selectedLayer = null
                        }
                    }
                }
            }

            Label {
                text: plugin.selectedLayer ?
                    "Selected: " + plugin.selectedLayerName :
                    "No layer selected"
                wrapMode: Text.WordWrap
            }

            Row {
                spacing: 10

                Button {
                    text: "Export to QField Datasets"
                    enabled: plugin.selectedLayer !== null

                    onClicked: {
                        try {
                            var base = plugin.selectedLayerName.replace(
                                /[^A-Za-z0-9_-]/g, "_"
                            )
                            if (base.length === 0)
                                base = "export"

                            // Do not use layer.source or qgisProject.absolutePath:
                            // both are unavailable in the user's QField build.
                            // applicationDirectory() is QField's writable app
                            // directory and is exposed by the platform utility.
                            var appDir = ""
                            try {
                                appDir =
                                    QfPlatformUtilities.instance()
                                    .applicationDirectory()
                            } catch (e1) {
                                try {
                                    appDir =
                                        platformUtilities.applicationDirectory()
                                } catch (e2) {}
                            }

                            if (!appDir || appDir.length === 0) {
                                iface.mainWindow().displayToast(
                                    "QField application directory unavailable"
                                )
                                return
                            }

                            // QField's Imported Datasets folder is the
                            // application-managed dataset directory.
                            var datasetsDir = appDir + "/Imported Datasets"

                            try {
                                QfPlatformUtilities.instance().createDir(
                                    appDir, "Imported Datasets"
                                )
                            } catch (e3) {
                                try {
                                    platformUtilities.createDir(
                                        appDir, "Imported Datasets"
                                    )
                                } catch (e4) {}
                            }

                            var outputPath =
                                datasetsDir + "/" +
                                base + "_FieldSurveyPro.shp"

                            iface.mainWindow().displayToast(
                                "Creating Shapefile..."
                            )

                            var result =
                                QfLayerUtils.saveVectorLayerAs(
                                    plugin.selectedLayer,
                                    outputPath,
                                    "ESRI Shapefile"
                                )

                            if (!result || result.length === 0) {
                                iface.mainWindow().displayToast(
                                    "Could not create Shapefile"
                                )
                                return
                            }

                            exportDialog.close()
                        } catch (e) {
                            iface.mainWindow().displayToast(
                                "Export error: " + e
                            )
                        }
                    }
                }

                Button {
                    text: "Refresh"
                    onClicked: exportDialog.populateLayers()
                }

                Button {
                    text: "Cancel"
                    onClicked: exportDialog.close()
                }
            }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(exportButton)
    }
}
