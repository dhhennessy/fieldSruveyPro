import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin

    // Use the QField-native toolbar button. This is the button type used
    // by QField's plugin examples and is compatible with the older API
    // that this installation has already loaded successfully.
    QfToolButton {
        id: exportButton
        objectName: "fieldSurveyProExportButton"
        bgcolor: Theme.darkGray
        iconSource: "icon.svg"
        iconColor: Theme.mainColor
        round: true

        onClicked: {
            exportDialog.open()
        }
    }

    Dialog {
        id: exportDialog
        parent: iface.mainWindow().contentItem
        modal: true
        title: "Export Shapefile"
        width: Math.min(parent.width - 40, 520)
        height: Math.min(parent.height - 80, 500)
        anchors.centerIn: parent

        contentItem: Column {
            spacing: 12
            padding: 16

            Label {
                text: "Select a vector layer to export:"
                font.bold: true
            }

            ListView {
                id: layerList
                width: exportDialog.width - 32
                height: 300
                clip: true

                model: ListModel { id: vectorLayers }

                delegate: ItemDelegate {
                    width: layerList.width
                    text: model.layerName
                    onClicked: {
                        selectedLayerName.text = model.layerName
                        exportDialog.close()
                        try {
                            iface.mainWindow().displayToast(
                                "Selected layer: " + model.layerName
                            )
                        } catch (e) {}
                    }
                }
            }

            Label {
                id: selectedLayerName
                text: "No layer selected"
                wrapMode: Text.WordWrap
            }

            Button {
                text: "Close"
                onClicked: exportDialog.close()
            }
        }

        function populateLayers() {
            vectorLayers.clear()

            // qgisProject is exposed by QField in the plugin environment.
            // mapLayers() returns the project's layers as a QVariantMap.
            try {
                var layers = qgisProject.mapLayers()
                for (var id in layers) {
                    var layer = layers[id]
                    if (layer && layer.geometryType !== undefined) {
                        vectorLayers.append({
                            "layerName": layer.name,
                            "layerId": id
                        })
                    }
                }
            } catch (e) {
                // Keep the dialog functional even if this older API cannot
                // enumerate layers from QML.
                try {
                    iface.mainWindow().displayToast(
                        "Layer list API unavailable on this QField version"
                    )
                } catch (x) {}
            }
        }

        onOpened: populateLayers()
    }

    Component.onCompleted: {
        // This is the documented QField plugin toolbar registration method.
        iface.addItemToPluginsToolbar(exportButton)
    }
}
