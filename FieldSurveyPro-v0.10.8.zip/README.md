# FieldSurvey Pro 0.10.8

Point-collection repair based on the known-working 0.8.x feature-creation
path.

## Important change
The point geometry creation path is reverted to the simple:
projectedPosition -> WKT -> GeometryUtils -> FeatureUtils -> feature form
sequence used by the working 0.8.x collector.

The plugin no longer blocks the point button merely because GNSS quality
metadata reports zero or unavailable values when the quality lock is OFF.

When the quality lock is ON, the configured quality checks are enforced.

The GNSS display now includes:
- QField fix status
- source name
- H/V accuracy
- PDOP
- satellites used
- QField positioning.valid
- quality-lock state

This diagnostic information is intended to distinguish a plugin issue from
an Arrow/QField positioning-connection issue.
