import QtQuick
import QtQuick.Controls
import QtCore
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    objectName: "fieldSurveyPro"

    property var dashBoard: iface.findItemByObjectName("dashBoard")
    property var overlayFeatureFormDrawer: iface.findItemByObjectName("overlayFeatureFormDrawer")
    property var positioning: iface.positioning()
    property var mainWindow: iface.mainWindow()

    Settings {
        id: settings
        category: "FieldSurveyPro"
        property int pointCounter: 1
        property string pointPrefix: "PT-"
        property string lastPointName: ""
        property int lineCounter: 1
        property string linePrefix: "LN-"
        property bool qualityLock: false
        property real maxHorizontalAccuracy: 0.10
        property real maxVerticalAccuracy: 0.20
        property real maxPdop: 3.0
        property int minSatellites: 8
        property bool rtkOnly: false
    }

    function pointId() {
        return settings.pointPrefix + ("000000" + settings.pointCounter).slice(-6)
    }

    function fieldIndex(layer, fieldName) {
        if (!layer || !layer.fields)
            return -1
        return layer.fields.indexOf(fieldName)
    }

    function setIfPresent(feature, layer, fieldName, value) {
        if (fieldIndex(layer, fieldName) >= 0)
            feature.setAttribute(fieldName, value)
    }

    function gnssInfo() {
        void gnssStatusVersion
        if (!positioning || !positioning.active)
            return null
        return positioning.positionInformation
    }

    function hasValidPosition(info) {
        return info &&
               info.longitudeValid &&
               info.latitudeValid
    }

    function qualityPasses(info) {
        if (!qualityLockEnabled)
            return hasValidPosition(info)

        if (!hasValidPosition(info))
            return false

        const h = Number(info.hacc)
        const v = Number(info.vacc)
        const p = Number(info.pdop)
        const s = Number(info.satellitesUsed)

        if (!info.haccValid || !info.vaccValid || !isFinite(h) || !isFinite(v) || !isFinite(p) || !isFinite(s))
            return false

        if (h > settings.maxHorizontalAccuracy)
            return false
        if (v > settings.maxVerticalAccuracy)
            return false
        if (p > settings.maxPdop)
            return false
        if (s < settings.minSatellites)
            return false

        if (settings.rtkOnly &&
            String(info.qualityDescription).toLowerCase().indexOf("rtk") < 0)
            return false

        return true
    }

    function qualityReason(info) {
        if (!qualityLockEnabled)
            return "Quality lock OFF"

        if (!info || !positioning || !positioning.valid)
            return "Waiting for valid GNSS position"

        const h = Number(info.hacc)
        const v = Number(info.vacc)
        const p = Number(info.pdop)
        const s = Number(info.satellitesUsed)

        if (!info.haccValid || !info.vaccValid ||
            !isFinite(h) || !isFinite(v) || !isFinite(p) || !isFinite(s))
            return "Waiting for GNSS quality data"

        if (h > settings.maxHorizontalAccuracy)
            return "Horizontal accuracy is above limit"
        if (v > settings.maxVerticalAccuracy)
            return "Vertical accuracy is above limit"
        if (p > settings.maxPdop)
            return "PDOP is above limit"
        if (s < settings.minSatellites)
            return "Too few satellites"
        if (settings.rtkOnly &&
            String(info.qualityDescription).toLowerCase().indexOf("rtk") < 0)
            return "RTK-only requirement not met"

        return "Quality requirements met"
    }

    function collectPoint() {
        const requestedName = pointNameField.text.trim()
        if (requestedName.length === 0) {
            mainWindow.displayToast("Enter a point name")
            return
        }

        if (qualityLockEnabled && !qualityPasses(gnssInfo())) {
            mainWindow.displayToast(qualityReason(gnssInfo()))
            return
        }

        dashBoard.ensureEditableLayerSelected()

        if (!dashBoard.activeLayer) {
            mainWindow.displayToast("Select an editable point layer first")
            return
        }

        const layer = dashBoard.activeLayer
        const info = gnssInfo()
        const projectedPosition = positioning.projectedPosition

        // This is deliberately the same simple projectedPosition -> WKT
        // path used by the known-working 0.8.x point collector.
        const wkt = "POINT(" + projectedPosition.x + " " + projectedPosition.y + ")"
        const geometry = GeometryUtils.createGeometryFromWkt(wkt)
        const feature = FeatureUtils.createFeature(layer, geometry)
        const id = pointId()

        setIfPresent(feature, layer, "name", requestedName)
        setIfPresent(feature, layer, "id", id)
        setIfPresent(feature, layer, "feature_id", id)

        if (info) {
            setIfPresent(feature, layer, "gnss_status", info.qualityDescription)
            setIfPresent(feature, layer, "h_accuracy", info.hacc)
            setIfPresent(feature, layer, "v_accuracy", info.vacc)
            setIfPresent(feature, layer, "pdop", info.pdop)
            setIfPresent(feature, layer, "satellites", info.satellitesUsed)
            setIfPresent(feature, layer, "gnss_source", info.sourceName)
            setIfPresent(feature, layer, "gnss_timestamp", info.utcDateTime)
            setIfPresent(feature, layer, "averaged_count", info.averagedCount)
            setIfPresent(feature, layer, "horizontal_accuracy", info.hacc)
            setIfPresent(feature, layer, "vertical_accuracy", info.vacc)
            setIfPresent(feature, layer, "gnss_pdop", info.pdop)
            setIfPresent(feature, layer, "gnss_satellites", info.satellitesUsed)
            setIfPresent(feature, layer, "gnss_quality", info.qualityDescription)
        }

        settings.pointCounter = settings.pointCounter + 1
        settings.lastPointName = requestedName

        overlayFeatureFormDrawer.featureModel.feature = feature
        overlayFeatureFormDrawer.state = "Add"
        overlayFeatureFormDrawer.open()
    }

    function statusText() {
        const info = gnssInfo()
        if (!info)
            return "GNSS: no position information object"

        const h = Number(info.hacc)
        const v = Number(info.vacc)
        const p = Number(info.pdop)
        const s = Number(info.satellitesUsed)
        const fix = info.fixStatusDescription
                    ? info.fixStatusDescription
                    : info.qualityDescription

        return "GNSS: " + fix +
               "\nSource: " + info.sourceName +
               "\nH: " + (isFinite(h) ? h.toFixed(3) + " m" : "N/A") +
               "   V: " + (isFinite(v) ? v.toFixed(3) + " m" : "N/A") +
               "\nPDOP: " + (isFinite(p) ? p.toFixed(2) : "N/A") +
               "   Satellites: " + (isFinite(s) ? s : "N/A") +
               "\nPositioning valid: " + positioning.valid +
               "\nQuality: " + qualityReason(info)
    }

    QfToolButton {
        id: surveyButton
        objectName: "fieldSurveyProButton"
        bgcolor: Theme.darkGray
        iconSource: "icon.svg"
        iconColor: Theme.mainColor
        round: true
        onClicked: panel.open()
    }

    Dialog {
        id: panel
        title: "FieldSurvey Pro"
        modal: true
        parent: mainWindow.contentItem
        width: Math.min(mainWindow.width - 40, 440)
        x: (mainWindow.width - width) / 2
        y: (mainWindow.height - height) / 2

        Column {
            width: parent.width
            spacing: 10

            Label {
                width: parent.width
                text: "GNSS Point Collection"
                font.bold: true
                font.pixelSize: 20
            }

            Label {
                width: parent.width
                text: "Next point ID: " + pointId()
            }

            Label {
                width: parent.width
                text: "Point name"
                font.bold: true
            }

            TextField {
                id: pointNameField
                width: parent.width
                text: settings.lastPointName.length > 0 ? "" : pointId()
                placeholderText: "Enter any name"
                selectByMouse: true
            }

            Label {
                width: parent.width
                text: statusText()
                wrapMode: Text.WordWrap
            }

            Button {
                width: parent.width
                text: "COLLECT POINT"
                enabled: true
                onClicked: {
                    panel.close()
                    collectPoint()
                }
            }

            CheckBox {
                id: qualityLockBox
                text: qualityLockEnabled
                      ? "Require GNSS quality limits: ON"
                      : "Require GNSS quality limits: OFF"
                checked: qualityLockEnabled
                onClicked: {
                    qualityLockEnabled = checked
                    settings.qualityLock = checked
                }
            }

            CheckBox {
                id: rtkBox
                text: "Require RTK"
                checked: settings.rtkOnly
                onClicked: settings.rtkOnly = checked
                enabled: qualityLockEnabled
            }

            Label {
                width: parent.width
                text: "Limits: H ≤ " + settings.maxHorizontalAccuracy.toFixed(2) +
                      " m, V ≤ " + settings.maxVerticalAccuracy.toFixed(2) +
                      " m, PDOP ≤ " + settings.maxPdop.toFixed(1) +
                      ", satellites ≥ " + settings.minSatellites
                wrapMode: Text.WordWrap
                enabled: qualityLockEnabled
            }

            Label {
                width: parent.width
                text: qualityLockEnabled
                      ? "QUALITY LOCK: ON — point collection is blocked until all limits pass."
                      : "QUALITY LOCK: OFF — point collection does not require accuracy, PDOP, or satellite limits."
                wrapMode: Text.WordWrap
                font.bold: true
            }

            Label {
                width: parent.width
                text: "Line Collection"
                font.bold: true
                font.pixelSize: 18
            }

            TextField {
                id: lineNameField
                width: parent.width
                placeholderText: "Line name"
                text: ""
                enabled: !lineRecording
            }

            Label {
                width: parent.width
                text: lineInfoText()
                wrapMode: Text.WordWrap
            }

            Button {
                width: parent.width
                text: lineRecording ? "FINISH LINE" : "START LINE"
                onClicked: {
                    if (lineRecording)
                        finishLine()
                    else
                        startLine()
                }
            }

            Label {
                width: parent.width
                text: "Vertices are collected every 5 ft (1.524 m) of movement. The timer only checks the GNSS position; it does not determine vertex spacing."
                wrapMode: Text.WordWrap
            }

            Button {
                width: parent.width
                text: "Close"
                enabled: !lineRecording
                onClicked: panel.close()
            }
        }
    }

    function configure() {
        panel.open()
    }

    Component.onCompleted: {
        qualityLockEnabled = settings.qualityLock
        iface.addItemToPluginsToolbar(surveyButton)
        mainWindow.displayToast("FieldSurvey Pro 0.9.0 loaded")
    }
}
