import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    property var mainWindow: iface.mainWindow()
    property var pointHandler: null
    property bool picking: false
    property var targetLayer: null
    property var targetFeature: null
    property bool targetActive: false
    property real distanceM: -1
    property real targetBearing: 0
    property real travelBearing: 0
    property real horizontalAccuracy: -1
    property real derivedTravelBearing: -1
    property real previousLat: NaN
    property real previousLon: NaN
    property string targetName: ""
    property var targetMapPoint: null

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(stakeButton)
    }

    function deg2rad(v) { return v * Math.PI / 180.0 }
    function rad2deg(v) { return v * 180.0 / Math.PI }
    function normalizeBearing(v) { v = v % 360; if (v < 0) v += 360; return v }

    function haversine(lat1, lon1, lat2, lon2) {
        var R = 6371008.8
        var p1 = deg2rad(lat1), p2 = deg2rad(lat2)
        var dp = deg2rad(lat2-lat1), dl = deg2rad(lon2-lon1)
        var a = Math.sin(dp/2)*Math.sin(dp/2) + Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2)
        return 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(Math.max(0,1-a)))
    }

    function bearingBetween(lat1, lon1, lat2, lon2) {
        var p1 = deg2rad(lat1), p2 = deg2rad(lat2), dl = deg2rad(lon2-lon1)
        var y = Math.sin(dl) * Math.cos(p2)
        var x = Math.cos(p1)*Math.sin(p2) - Math.sin(p1)*Math.cos(p2)*Math.cos(dl)
        return normalizeBearing(rad2deg(Math.atan2(y,x)))
    }

    function currentLatLon() {
        var pos = iface.positioning()
        if (!pos || !pos.valid)
            return null
        var p = pos.sourcePosition
        return { lat: p.y, lon: p.x }
    }

    function targetLatLon() {
        if (!targetFeature || !targetLayer) return null
        try {
            // Use the actual selected feature geometry, not the screen tap location.
            var geom = targetFeature.geometry
            if (!geom) throw "Feature has no geometry"
            var pt = geom.asPoint
            var wgs = QfGeometryUtils.reprojectPoint(
                pt,
                targetLayer.crs,
                CoordinateReferenceSystemUtils.wgs84Crs()
            )
            return { lat: Number(wgs.y), lon: Number(wgs.x) }
        } catch (e) {
            mainWindow.displayToast("TARGET POSITION ERROR: " + e)
            return null
        }
    }

    function updateNavigation() {
        if (!targetActive) return

        var pos = iface.positioning()
        if (!pos || !pos.active) {
            distanceM = -1
            horizontalAccuracy = -1
            return
        }

        var info = pos.positionInformation
        if (!info || !info.latitudeValid || !info.longitudeValid) {
            distanceM = -1
            horizontalAccuracy = -1
            return
        }

        var lat = Number(info.latitude)
        var lon = Number(info.longitude)
        if (!isFinite(lat) || !isFinite(lon)) return

        var target = targetLatLon()
        if (!target) return

        distanceM = haversine(lat, lon, target.lat, target.lon)
        targetBearing = bearingBetween(lat, lon, target.lat, target.lon)

        var hacc = Number(info.hacc)
        if (info.haccValid && isFinite(hacc) && hacc >= 0)
            horizontalAccuracy = hacc
        else
            horizontalAccuracy = -1

        // Prefer QField's GNSS course-over-ground when it is valid.
        // If it is unavailable, derive travel direction from successive GNSS fixes.
        var course = Number(info.direction)
        if (info.directionValid && isFinite(course)) {
            travelBearing = normalizeBearing(course)
        } else if (isFinite(previousLat) && isFinite(previousLon)) {
            var moved = haversine(previousLat, previousLon, lat, lon)
            if (moved >= 0.5) {
                derivedTravelBearing = bearingBetween(previousLat, previousLon, lat, lon)
                travelBearing = derivedTravelBearing
            }
        }

        previousLat = lat
        previousLon = lon

        // Arrow graphic points straight up at 0 degrees.
        // QField direction/bearing is clockwise from true north.
        // Therefore target minus travel heading gives the required
        // left/right turn relative to the user's current direction.
        navArrow.rotation = normalizeBearing(targetBearing - travelBearing)
    }

    function selectNearestFeature(screenPoint) {
        var layers = qgisProject.mapLayersByName("FieldSurveyPro_Points")
        if (!layers || layers.length === 0) {
            mainWindow.displayToast("LAYER NOT FOUND")
            return false
        }

        var layer = layers[0]
        targetLayer = layer

        var ms = iface.mapCanvas().mapSettings
        var tl = ms.screenToCoordinate(Qt.point(screenPoint.x - 20, screenPoint.y - 20))
        var br = ms.screenToCoordinate(Qt.point(screenPoint.x + 20, screenPoint.y + 20))
        var rectangle = GeometryUtils.createRectangleFromPoints(tl, br)

        var it = LayerUtils.createFeatureIteratorFromRectangle(layer, rectangle)
        if (!it || !it.hasNext()) {
            mainWindow.displayToast("NO POINT AT TAP")
            return false
        }

        var feature = it.next()
        if (!feature) {
            mainWindow.displayToast("NO POINT FEATURE")
            return false
        }

        // Convert the tap to project coordinates exactly once.
        targetMapPoint = ms.screenToCoordinate(
            Qt.point(screenPoint.x, screenPoint.y)
        )
        targetFeature = feature

        targetName = ""
        try { targetName = String(feature.attribute("name")) } catch (e2) {}
        if (!targetName || targetName === "undefined" || targetName === "null")
            targetName = "Point " + String(feature.id)

        targetActive = true
        previousLat = NaN
        previousLon = NaN
        derivedTravelBearing = -1
        picking = false
        updateNavigation()
        mainWindow.displayToast("TARGET: " + targetName)
        return true
    }

    function startPicking() {
        pointHandler = iface.findItemByObjectName("pointHandler")
        if (!pointHandler) {
            mainWindow.displayToast("STAKEOUT: pointHandler NOT FOUND")
            return
        }
        try { pointHandler.deregisterHandler("FieldSurveyProStakeout294") } catch (e) {}
        picking = true
        targetActive = false
        mainWindow.displayToast("STAKEOUT: TAP A POINT")
        pointHandler.registerHandler("FieldSurveyProStakeout294", function(point, type, interactionType) {
            if (!picking || interactionType !== "clicked") return false
            try {
                return selectNearestFeature(point)
            } catch (e) {
                mainWindow.displayToast("TAP ERROR: " + e)
                return true
            }
        }, 100)
    }

    function clearTarget() {
        targetActive = false
        targetFeature = null
        targetLayer = null
        targetMapPoint = null
        targetName = ""
        previousLat = NaN
        previousLon = NaN
        derivedTravelBearing = -1
        distanceM = -1
        mainWindow.displayToast("STAKEOUT: TARGET CLEARED")
    }

    Timer {
        interval: 250
        repeat: true
        running: targetActive
        onTriggered: updateNavigation()
    }

    QfToolButton {
        id: stakeButton
        width: 56
        height: 56
        iconSource: Theme.getThemeVectorIcon("ic_navigation_white_24dp")
        iconColor: Theme.toolButtonColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true
        onClicked: startPicking()
        Text { anchors.centerIn: parent; text: "STAKE"; color: "white"; font.bold: true; font.pixelSize: 10 }
    }

    Rectangle {
        id: panel
        parent: mainWindow.contentItem
        visible: targetActive
        anchors.top: parent.top
        anchors.topMargin: 80
        anchors.horizontalCenter: parent.horizontalCenter
        width: 310
        height: 210
        radius: 12
        color: "#DD202020"
        border.color: "white"
        border.width: 1
        z: 100000

        Text { x: 15; y: 10; text: targetName; color: "white"; font.bold: true; font.pixelSize: 18; width: 280; elide: Text.ElideRight }
        Text { x: 15; y: 42; text: distanceM >= 0 ? (distanceM < 1000 ? distanceM.toFixed(2) + " m" : (distanceM/1000).toFixed(3) + " km") : "--"; color: "white"; font.bold: true; font.pixelSize: 30 }

        Item {
            x: 218; y: 35; width: 70; height: 70
            Text { anchors.centerIn: parent; text: "↑"; color: "white"; font.pixelSize: 62; rotation: navArrow.rotation }
            id: navArrow
        }

        Text { x: 15; y: 86; text: "Go bearing: " + (targetBearing || 0).toFixed(1) + "°"; color: "#DDDDDD"; font.pixelSize: 13 }
        Text { x: 15; y: 108; text: "Heading: " + (isFinite(travelBearing) ? travelBearing.toFixed(1) + "°" : "--") + "   Acc: " + (isFinite(horizontalAccuracy) && horizontalAccuracy >= 0 ? horizontalAccuracy.toFixed(2) + " m" : "--"); color: "#DDDDDD"; font.pixelSize: 13 }

        Rectangle {
            x: 15; y: 140; width: 130; height: 45; radius: 8; color: "#444444"
            Text { anchors.centerIn: parent; text: "NEW TARGET"; color: "white"; font.bold: true; font.pixelSize: 12 }
            MouseArea { anchors.fill: parent; onClicked: startPicking() }
        }
        Rectangle {
            x: 165; y: 140; width: 130; height: 45; radius: 8; color: "#444444"
            Text { anchors.centerIn: parent; text: "CLEAR"; color: "white"; font.bold: true; font.pixelSize: 12 }
            MouseArea { anchors.fill: parent; onClicked: clearTarget() }
        }
    }
}
