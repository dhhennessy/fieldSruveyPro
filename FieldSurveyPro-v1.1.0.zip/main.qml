import QtQuick
import QtQuick.Controls
import org.qfield
import Theme

Item {
    id: plugin
    objectName: "fieldSurveyPro"

    property var pointLayer: null
    property var lineLayer: null
    property var polygonLayer: null

    function findLayer(name) {
        if (!qgisProject)
            return null
        var layers = qgisProject.mapLayersByName(name)
        if (layers && layers.length > 0)
            return layers[0]
        return null
    }

    function prepareLayer(layer, label) {
        if (!layer) {
            iface.mainWindow().displayToast(label + " layer not found")
            return false
        }

        try {
            if (!layer.isEditable())
                layer.startEditing()
        } catch (e) {
            iface.mainWindow().displayToast("Could not make " + label + " editable")
            return false
        }

        return true
    }

    function setup() {
        pointLayer = findLayer("FieldSurveyPro_Points")
        lineLayer = findLayer("FieldSurveyPro_Lines")
        polygonLayer = findLayer("FieldSurveyPro_Polygons")

        var ok = true
        ok = prepareLayer(pointLayer, "Point") && ok
        ok = prepareLayer(lineLayer, "Line") && ok
        ok = prepareLayer(polygonLayer, "Polygon") && ok

        if (ok)
            iface.mainWindow().displayToast("FieldSurvey Pro layers ready")
        else
            iface.mainWindow().displayToast("FieldSurvey Pro: check project layers")

        return ok
    }

    Rectangle {
        id: pointButton
        objectName: "fieldSurveyProPointButton"
        width: 1
        height: 1
        visible: false
    }

    Component.onCompleted: {
        iface.mainWindow().displayToast("FieldSurvey Pro loaded")
        setup()
    }
}
