import QtQuick
import QtQuick.Controls
import QtCore
import org.qfield.org
import org.qfield.gui

Item {
    id: plugin
    objectName: "fieldSurveyPro"

    property var positioning: iface.positioning()
    property var mainWindow: iface.mainWindow()
    property var mapCanvas: iface.mapCanvas()
    property var dashBoard: iface.findItemByObjectName("dashBoard")

    Settings {
        id: settings
        category: "FieldSurveyPro"
        property int pointCounter: 1
        property string pointPrefix: "PT-"
        property bool requireFix: false
        property real maxHorizontalAccuracy: 0.05
        property real maxVerticalAccuracy: 0.10
        property real maxPdop: 4.0
        property int minSatellites: 8
    }

    function pointId() {
        return settings.pointPrefix + ("000000" + settings.pointCounter).slice(-6)
    }

    function gnss() {
        if (!positioning || !positioning.active)
            return null
        var info = positioning.positionInformation
        if (!info || !info.latitudeValid || !info.longitudeValid)
            return null
        return info
    }

    function gnssStatus() {
        var info = gnss()
        if (!info) return "GNSS: waiting"
        return "GNSS: " + Number(info.latitude).toFixed(7) +
               ", " + Number(info.longitude).toFixed(7)
    }

    function projectedPoint() {
        if (!positioning || !positioning.active)
            return null
        return positioning.projectedPosition
    }

    function qualityOK(info) {
        if (!info) return false

        // Different QField versions/receivers expose different subsets.
        // Only enforce a value when it is actually present.
        if (settings.requireFix && info.fixStatus !== undefined) {
            var s = String(info.fixStatus).toLowerCase()
            if (s.indexOf("fix") < 0 || s.indexOf("float") >= 0)
                return false
        }

        if (info.horizontalAccuracyValid &&
            Number(info.horizontalAccuracy) > settings.maxHorizontalAccuracy)
            return false

        if (info.verticalAccuracyValid &&
            Number(info.verticalAccuracy) > settings.maxVerticalAccuracy)
            return false

        if (info.pdopValid && Number(info.pdop) > settings.maxPdop)
            return false

        if (info.satellitesValid && Number(info.satellites) < settings.minSatellites)
            return false

        return true
    }

    function setIfPresent(feature, field, value) {
        try {
            var fields = feature.fields()
            var index = fields.indexOf(field)
            if (index >= 0) feature.setAttribute(field, value)
        } catch (e) {}
    }

    function activePointLayer() {
        try {
            dashBoard.ensureEditableLayerSelected()
        } catch (e) {}

        if (!dashBoard) return null
        var layer = dashBoard.activeLayer
        if (!layer) return null

        try {
            if (layer.geometryType !== undefined && layer.geometryType !== 0)
                return null
        } catch (e) {}
        return layer
    }

    function collectPoint() {
        var info = gnss()
        if (!info) {
            mainWindow.displayToast("No valid GNSS position")
            return
        }

        if (!qualityOK(info)) {
            qualityDialog.open()
            return
        }

        var layer = activePointLayer()
        if (!layer) {
            mainWindow.displayToast("Select an editable POINT layer")
            return
        }

        var p = projectedPoint()
        if (!p) {
            mainWindow.displayToast("Projected GNSS position unavailable")
            return
        }

        var wkt = "POINT(" + p.x + " " + p.y + ")"
        var geometry = QfGeometryUtils.createGeometryFromWkt(wkt)
        var feature = QfFeatureUtils.createFeature(layer, geometry)
        var id = pointId()

        setIfPresent(feature, "name", id)
        setIfPresent(feature, "id", id)
        setIfPresent(feature, "feature_id", id)
        setIfPresent(feature, "description", "FieldSurvey Pro point")

        if (info.latitudeValid) setIfPresent(feature, "latitude", info.latitude)
        if (info.longitudeValid) setIfPresent(feature, "longitude", info.longitude)
        if (info.horizontalAccuracyValid)
            setIfPresent(feature, "horizontal_accuracy", info.horizontalAccuracy)
        if (info.verticalAccuracyValid)
            setIfPresent(feature, "vertical_accuracy", info.verticalAccuracy)
        if (info.pdopValid)
            setIfPresent(feature, "pdop", info.pdop)
        if (info.satellitesValid)
            setIfPresent(feature, "satellites", info.satellites)

        settings.pointCounter++
        mainWindow.displayToast(id + " collected")
    }

    function configure() {
        settingsDialog.open()
    }

    QfToolButton {
        id: surveyButton
        objectName: "fieldSurveyProButton"
        iconSource: Theme.getThemeVectorIcon("ic_geotag_white_24dp")
        iconColor: Theme.toolButtonColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true
        onClicked: panel.open()
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(surveyButton)
        mainWindow.displayToast("FieldSurvey Pro 0.8 loaded")
    }

    QfDialog {
        id: panel
        parent: mainWindow.contentItem
        width: Math.min(mainWindow.width - 32, 440)
        height: Math.min(mainWindow.height - 48, 520)
        x: (mainWindow.width - width) / 2
        y: (mainWindow.height - height) / 2
        title: "FieldSurvey Pro"

        Column {
            width: parent.width
            spacing: 10

            Label {
                width: parent.width
                text: gnssStatus()
                wrapMode: Text.WordWrap
            }

            Button {
                width: parent.width
                text: "COLLECT POINT  " + pointId()
                onClicked: {
                    collectPoint()
                    panel.close()
                }
            }

            Button {
                width: parent.width
                text: "POINT SETTINGS"
                onClicked: settingsDialog.open()
            }

            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                text: "Point collection uses the active editable point layer. The Arrow Gold+ should be connected to QField as the external GNSS receiver."
            }

            Button {
                width: parent.width
                text: "CLOSE"
                onClicked: panel.close()
            }
        }
    }

    QfDialog {
        id: qualityDialog
        parent: mainWindow.contentItem
        width: Math.min(mainWindow.width - 32, 420)
        height: 240
        title: "GNSS Quality"

        Column {
            width: parent.width
            spacing: 10
            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                text: "The current GNSS position does not meet the configured quality requirements."
            }
            Button {
                width: parent.width
                text: "COLLECT ANYWAY"
                onClicked: {
                    settings.requireFix = false
                    qualityDialog.close()
                    collectPoint()
                }
            }
            Button {
                width: parent.width
                text: "CANCEL"
                onClicked: qualityDialog.close()
            }
        }
    }

    QfDialog {
        id: settingsDialog
        parent: mainWindow.contentItem
        width: Math.min(mainWindow.width - 32, 440)
        height: 440
        x: (mainWindow.width - width) / 2
        y: (mainWindow.height - height) / 2
        title: "Point Settings"

        Column {
            width: parent.width
            spacing: 8

            Label { text: "Point prefix" }
            TextField {
                width: parent.width
                text: settings.pointPrefix
                onEditingFinished: settings.pointPrefix = text
            }

            CheckBox {
                text: "Require RTK FIX when status is available"
                checked: settings.requireFix
                onCheckedChanged: settings.requireFix = checked
            }

            Label { text: "Maximum horizontal accuracy (m)" }
            SpinBox {
                width: parent.width
                from: 1
                to: 1000
                value: Math.round(settings.maxHorizontalAccuracy * 1000)
                onValueModified: settings.maxHorizontalAccuracy = value / 1000
            }

            Label { text: "Maximum vertical accuracy (m)" }
            SpinBox {
                width: parent.width
                from: 1
                to: 2000
                value: Math.round(settings.maxVerticalAccuracy * 1000)
                onValueModified: settings.maxVerticalAccuracy = value / 1000
            }

            Label { text: "Maximum PDOP" }
            SpinBox {
                width: parent.width
                from: 10
                to: 100
                value: Math.round(settings.maxPdop * 10)
                onValueModified: settings.maxPdop = value / 10
            }

            Label { text: "Minimum satellites" }
            SpinBox {
                width: parent.width
                from: 1
                to: 50
                value: settings.minSatellites
                onValueModified: settings.minSatellites = value
            }

            Button {
                width: parent.width
                text: "CLOSE"
                onClicked: settingsDialog.close()
            }
        }
    }
}
