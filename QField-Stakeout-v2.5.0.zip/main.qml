import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    property var mainWindow: iface.mainWindow()
    property var pointHandler: null
    property bool picking: false

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(stakeButton)
    }

    function startPicking() {
        pointHandler = iface.findItemByObjectName("pointHandler")

        if (!pointHandler) {
            mainWindow.displayToast("STAKEOUT: point handler unavailable")
            return
        }

        try {
            pointHandler.deregisterHandler("FieldSurveyProStakeoutCRS")
        } catch (e) {}

        picking = true
        mainWindow.displayToast("STAKEOUT: TAP A POINT")

        pointHandler.registerHandler(
            "FieldSurveyProStakeoutCRS",
            function(point, type, interactionType) {
                if (!picking || interactionType !== "clicked")
                    return false

                var canvas = iface.mapCanvas()

                // Convert the screen tap to a project/map coordinate.
                var tl = canvas.mapSettings.screenToCoordinate(
                    Qt.point(point.x - 20, point.y - 20))
                var br = canvas.mapSettings.screenToCoordinate(
                    Qt.point(point.x + 20, point.y + 20))

                var projectRectangle =
                    GeometryUtils.createRectangleFromPoints(tl, br)

                var layerIds = canvas.mapSettings.layers

                for (var i = 0; i < layerIds.length; i++) {
                    var layer = qgisProject.mapLayer(layerIds[i])
                    if (!layer)
                        continue

                    var layerRectangle = projectRectangle

                    // The iterator expects the rectangle in the layer CRS.
                    // This was missing from v2.4.0.
                    try {
                        layerRectangle = GeometryUtils.reprojectRectangle(
                            projectRectangle,
                            canvas.mapSettings.destinationCrs,
                            layer.crs)
                    } catch (crsError) {
                        // If the layer is already in the project CRS,
                        // the original rectangle is still usable.
                        layerRectangle = projectRectangle
                    }

                    var it = null

                    try {
                        it = LayerUtils.createFeatureIteratorFromRectangle(
                            layer, layerRectangle)
                    } catch (iteratorError) {
                        continue
                    }

                    if (!it)
                        continue

                    while (it.hasNext()) {
                        var feature = it.next()
                        if (!feature || !feature.isValid())
                            continue

                        var geometry = null
                        try {
                            geometry = feature.geometry()
                        } catch (geometryError) {
                            continue
                        }

                        if (!geometry || geometry.isNull())
                            continue

                        // Only accept actual point geometries.
                        var candidatePoint = null
                        try {
                            candidatePoint = geometry.asPoint()
                        } catch (pointError) {
                            continue
                        }

                        if (!candidatePoint)
                            continue

                        var name = ""
                        try {
                            name = String(feature.attribute("name"))
                        } catch (nameError) {}

                        if (name === "" ||
                            name === "undefined" ||
                            name === "null") {
                            try {
                                name = "Feature " + feature.id()
                            } catch (idError) {
                                name = "Point found"
                            }
                        }

                        picking = false

                        // Leave the feature selected in QField as visual confirmation.
                        try {
                            layer.selectByIds([feature.id()])
                        } catch (selectError) {}

                        mainWindow.displayToast(
                            "TARGET FOUND: " + name)
                        return true
                    }
                }

                mainWindow.displayToast("NO POINT FOUND")
                return true
            },
            100
        )
    }

    QfToolButton {
        id: stakeButton
        width: 56
        height: 56
        iconSource: Theme.getThemeVectorIcon("ic_navigation_white_24dp")
        iconColor: Theme.toolButtonColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true

        onClicked: startPicking()

        Text {
            anchors.centerIn: parent
            text: "STAKE"
            color: "white"
            font.bold: true
            font.pixelSize: 10
        }
    }
}
