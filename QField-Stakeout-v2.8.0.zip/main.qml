import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    property var mainWindow: iface.mainWindow()
    property var pointHandler: null
    property bool picking: false
    property var targetLayer: null
    property var targetFeature: null
    property string targetName: ""

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(stakeButton)
    }

    function startPicking() {
        pointHandler = iface.findItemByObjectName("pointHandler")
        if (!pointHandler) {
            mainWindow.displayToast("STAKEOUT: point handler unavailable")
            return
        }

        try { pointHandler.deregisterHandler("FieldSurveyProStakeoutNearest") } catch (e) {}

        picking = true
        mainWindow.displayToast("STAKEOUT: TAP A POINT")

        pointHandler.registerHandler(
            "FieldSurveyProStakeoutNearest",
            function(point, type, interactionType) {
                if (!picking || interactionType !== "clicked")
                    return false

                var canvas = iface.mapCanvas()
                var tap = canvas.mapSettings.screenToCoordinate(
                    Qt.point(point.x, point.y))

                var layers = qgisProject.mapLayersByName("FieldSurveyPro_Points")
                if (!layers || layers.length === 0) {
                    mainWindow.displayToast("POINT LAYER NOT FOUND")
                    return true
                }

                var layer = layers[0]
                var it = null

                try {
                    // Do not use a rectangle at all. Read the point layer
                    // and find the feature nearest to the actual tap coordinate.
                    it = LayerUtils.createFeatureIterator(layer)
                } catch (e1) {
                    mainWindow.displayToast("FEATURE ITERATOR ERROR")
                    return true
                }

                if (!it) {
                    mainWindow.displayToast("FEATURE ITERATOR UNAVAILABLE")
                    return true
                }

                var nearest = null
                var nearestDistance = Number.POSITIVE_INFINITY

                while (it.hasNext()) {
                    var f = it.next()
                    if (!f || !f.isValid())
                        continue

                    var p = null
                    try {
                        p = f.geometry().asPoint()
                    } catch (e2) {
                        continue
                    }

                    if (!p)
                        continue

                    var candidate = p

                    // Convert the feature point into the map/project CRS.
                    try {
                        candidate = GeometryUtils.reprojectPoint(
                            p, layer.crs, canvas.mapSettings.destinationCrs)
                    } catch (e3) {
                        // If reprojection is unavailable, retain the raw point.
                    }

                    var dx = Number(candidate.x) - Number(tap.x)
                    var dy = Number(candidate.y) - Number(tap.y)
                    var d2 = dx * dx + dy * dy

                    if (d2 < nearestDistance) {
                        nearestDistance = d2
                        nearest = f
                    }
                }

                if (!nearest) {
                    mainWindow.displayToast("NO FEATURES IN POINT LAYER")
                    return true
                }

                targetLayer = layer
                targetFeature = nearest
                targetName = featureName(nearest)
                picking = false

                try {
                    LayerUtils.selectFeaturesInLayer(
                        layer, [nearest.id()])
                } catch (e4) {}

                mainWindow.displayToast("TARGET FOUND: " + targetName)
                return true
            },
            100
        )
    }

    function featureName(feature) {
        try {
            var v = feature.attribute("name")
            if (v !== null && v !== undefined && String(v) !== "")
                return String(v)
        } catch (e) {}

        try { return "Feature " + feature.id() } catch (e2) {}
        return "Point"
    }

    QfToolButton {
        id: stakeButton
        width: 56
        height: 56
        iconSource: Theme.getThemeVectorIcon("ic_navigation_white_24dp")
        iconColor: Theme.toolButtonColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true

        onClicked: startPicking()

        Text {
            anchors.centerIn: parent
            text: "STAKE"
            color: "white"
            font.bold: true
            font.pixelSize: 10
        }
    }
}
