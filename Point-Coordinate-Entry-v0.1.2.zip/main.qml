import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    objectName: "pointCoordinateEntryPlugin"

    property var dashBoard: iface.findItemByObjectName("dashBoard")
    property var overlayFeatureFormDrawer: iface.findItemByObjectName("overlayFeatureFormDrawer")
    property var mainWindow: iface.mainWindow()

    function showMessage(message) {
        if (mainWindow && mainWindow.displayToast)
            mainWindow.displayToast(message)
    }

    function addPoint() {
        if (!dashBoard) {
            showMessage("QField dashboard is unavailable.")
            return
        }

        dashBoard.ensureEditableLayerSelected()
        var layer = dashBoard.activeLayer
        if (!layer) {
            showMessage("Select an editable point layer first.")
            return
        }

        var x = Number(eastingField.text.trim())
        var y = Number(northingField.text.trim())
        if (eastingField.text.trim() === "" || northingField.text.trim() === "" ||
                !isFinite(x) || !isFinite(y)) {
            showMessage("Enter valid numeric easting and northing values.")
            return
        }

        // UTM coordinates must fall within plausible projected-coordinate ranges.
        if (x < 100000 || x > 900000 || y < 0 || y > 10000000) {
            showMessage("Coordinates are outside plausible UTM ranges.")
            return
        }

        try {
            if (layer.crs.authid !== "EPSG:32617") {
                showMessage("Selected layer must use EPSG:32617. Coordinates will not be reprojected.")
                return
            }
            var geometry = QfGeometryUtils.createGeometryFromWkt(
                        "POINT(" + x + " " + y + ")")
            var feature = QfFeatureUtils.createFeature(layer, geometry)

            overlayFeatureFormDrawer.featureModel.feature = feature
            overlayFeatureFormDrawer.state = "Add"
            overlayFeatureFormDrawer.open()
            entryDialog.close()
        } catch (e) {
            showMessage("Could not create point: " + e)
        }
    }

    QfToolButton {
        id: entryButton
        bgcolor: Theme.darkGray
        iconSource: Theme.getThemeVectorIcon("ic_add_location_white_24dp")
        iconColor: Theme.mainColor
        round: true
        onClicked: {
            eastingField.text = ""
            northingField.text = ""
            entryDialog.open()
        }
    }

    Dialog {
        id: entryDialog
        parent: mainWindow ? mainWindow.contentItem : null
        modal: true
        title: "Enter Point Coordinates"
        standardButtons: Dialog.NoButton
        width: Math.min(parent ? parent.width - 32 : 420, 440)
        anchors.centerIn: parent

        contentItem: ColumnLayout {
            spacing: 12

            Label {
                text: "Enter coordinates in UTM Zone 17N (WGS84)."
                wrapMode: Text.WordWrap
                Layout.fillWidth: true
            }

            TextField {
                id: eastingField
                objectName: "pointEntryEasting"
                placeholderText: "Easting (m)"
                inputMethodHints: Qt.ImhFormattedNumbersOnly
                validator: DoubleValidator { bottom: 100000; top: 900000; decimals: 3; notation: DoubleValidator.StandardNotation }
                Layout.fillWidth: true
            }

            TextField {
                id: northingField
                objectName: "pointEntryNorthing"
                placeholderText: "Northing (m)"
                inputMethodHints: Qt.ImhFormattedNumbersOnly
                validator: DoubleValidator { bottom: 0; top: 10000000; decimals: 3; notation: DoubleValidator.StandardNotation }
                Layout.fillWidth: true
            }

            Label {
                text: "The point will be reprojected to the selected layer's CRS. You can then fill in the layer's attributes."
                wrapMode: Text.WordWrap
                Layout.fillWidth: true
            }

            RowLayout {
                Layout.fillWidth: true
                Item { Layout.fillWidth: true }
                Button {
                    text: "Cancel"
                    onClicked: entryDialog.close()
                }
                Button {
                    text: "Add Point"
                    highlighted: true
                    onClicked: plugin.addPoint()
                }
            }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(entryButton)
    }
}
