Point Coordinate Entry for QField
Version 0.1.2

Purpose
Create a point feature by entering an easting and northing in UTM Zone 17N,
WGS84 (EPSG:32617). The coordinates are written directly to the selected editable
point layer without reprojection. The normal QField feature form then opens so the layer's
attributes can be completed.

Install
1. Copy this ZIP to a location accessible from your device, or host it at a
   direct ZIP URL.
2. In QField, open Settings > Plugins.
3. Choose Install plugin from URL and provide the direct ZIP URL (or install
   the ZIP using the available local installation workflow in your QField build).
4. Enable Point Coordinate Entry and grant its requested permission.

Use
1. Open the project and select an editable point layer.
2. Tap the plugin's toolbar button.
3. Enter UTM easting and northing in metres.
4. Tap Add Point, then complete the normal feature form and save.

Notes
- Input coordinates are always interpreted as EPSG:32617.
- No automatic reprojection is performed. The selected layer must use EPSG:32617.
- The selected layer must be editable and have point geometry.
- This initial build has not been tested on a physical QField device.
