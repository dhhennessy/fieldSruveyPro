import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield.org
import org.qfield.gui

Item {
    id: plugin
    property var mainWindow: iface.mainWindow()
    property var mapCanvas: iface.mapCanvas()
    property var pointHandler: iface.findItemByObjectName("pointHandler")

    property bool picking: false
    property bool active: false
    property var targetLayer: null
    property var targetFeature: null
    property string targetName: ""
    property real arrowRotation: 0
    property real arrivalThreshold: 0.50

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(stakeoutButton)
    }

    function toast(s) {
        try { mainWindow.displayToast(s) } catch (e) {}
    }

    function beginPick() {
        clearTarget(false)

        if (!pointHandler) {
            toast("QField point handler unavailable")
            return
        }

        try { pointHandler.unregisterHandler("FieldSurveyProStakeout432") } catch (e) {}

        picking = true
        stakeoutPanel.visible = true
        statusText.text = "TAP A POINT"
        targetName = ""
        toast("Tap a point to stake out")

        pointHandler.registerHandler(
            "FieldSurveyProStakeout432",
            function(screenPoint, type, interactionType) {
                if (!picking || interactionType !== "clicked")
                    return false

                // QField 4.3.x supplies the tap in screen pixels.
                var x = Number(screenPoint.x)
                var y = Number(screenPoint.y)
                var tl = mapCanvas.mapSettings.screenToCoordinate(Qt.point(x - 10, y - 10))
                var br = mapCanvas.mapSettings.screenToCoordinate(Qt.point(x + 10, y + 10))
                var rectangle = GeometryUtils.createRectangleFromPoints(tl, br)

                var layerIds = mapCanvas.mapSettings.layers
                var bestLayer = null
                var bestFeature = null
                var bestDistance2 = Number.POSITIVE_INFINITY

                for (var i = 0; i < layerIds.length; i++) {
                    var layer = qgisProject.mapLayer(layerIds[i])
                    if (!layer)
                        continue

                    // Only point vector layers are valid stakeout targets.
                    try {
                        if (Number(layer.geometryType()) !== 0)
                            continue
                    } catch (e1) {
                        continue
                    }

                    var it = null
                    try {
                        it = LayerUtils.createFeatureIteratorFromRectangle(layer, rectangle)
                    } catch (e2) {
                        continue
                    }

                    if (!it)
                        continue

                    while (it.hasNext()) {
                        var feature = it.next()
                        if (!feature || !feature.isValid())
                            continue

                        var geom = null
                        try { geom = feature.geometry() } catch (e3) {}
                        if (!geom || geom.isNull())
                            continue

                        // Compare candidate geometry to the actual tap coordinate.
                        var p = null
                        try { p = geom.asPoint() } catch (e4) {}
                        if (!p)
                            continue

                        var dx = Number(p.x()) - Number(tl.x() + br.x()) / 2.0
                        var dy = Number(p.y()) - Number(tl.y() + br.y()) / 2.0
                        var d2 = dx * dx + dy * dy

                        if (d2 < bestDistance2) {
                            bestDistance2 = d2
                            bestLayer = layer
                            bestFeature = feature
                        }
                    }
                }

                if (!bestFeature) {
                    statusText.text = "NO POINT FOUND"
                    toast("No point feature found at that location")
                    return true
                }

                setTarget(bestLayer, bestFeature)
                return true
            },
            QfMapCanvasPointHandler.Priority.High
        )
    }

    function setTarget(layer, feature) {
        targetLayer = layer
        targetFeature = feature
        targetName = getTargetName(feature)
        picking = false
        active = true
        statusText.text = "TARGET SET"

        // Also ask QField to highlight the same feature when supported.
        try {
            layer.selectByIds([feature.id()])
        } catch (e1) {
            try { LayerUtils.selectFeaturesInLayer(layer, [feature.id()]) } catch (e2) {}
        }

        updateNavigationDisplay()
        toast("TARGET SET: " + targetName)
    }

    function clearTarget(hidePanel) {
        try { pointHandler.unregisterHandler("FieldSurveyProStakeout432") } catch (e) {}
        picking = false
        active = false
        targetLayer = null
        targetFeature = null
        targetName = ""
        arrowRotation = 0
        statusText.text = "TAP A POINT"
        if (hidePanel)
            stakeoutPanel.visible = false
    }

    function getTargetName(feature) {
        var names = ["name", "Name", "label", "Label", "id", "ID"]
        for (var i = 0; i < names.length; i++) {
            try {
                var v = feature.attribute(names[i])
                if (v !== null && v !== undefined && String(v) !== "")
                    return String(v)
            } catch (e) {}
        }
        try { return "Point " + feature.id() } catch (e2) {}
        return "Target"
    }

    function targetWgs84() {
        if (!targetFeature || !targetLayer)
            return null
        try {
            var p = targetFeature.geometry().asPoint()
            return QfGeometryUtils.reprojectPoint(
                p, targetLayer.crs, CoordinateReferenceSystemUtils.wgs84Crs())
        } catch (e) {
            return null
        }
    }

    function currentWgs84() {
        try {
            var pos = iface.positioning()
            if (!pos || !pos.valid)
                return null

            var p = pos.projectedPosition
            return QfGeometryUtils.reprojectPoint(
                p, qgisProject.crs, CoordinateReferenceSystemUtils.wgs84Crs())
        } catch (e) {
            return null
        }
    }

    function distanceMeters() {
        var a = currentWgs84()
        var b = targetWgs84()
        if (!a || !b)
            return NaN

        var lat1 = Number(a.y()) * Math.PI / 180.0
        var lat2 = Number(b.y()) * Math.PI / 180.0
        var dLat = (Number(b.y()) - Number(a.y())) * Math.PI / 180.0
        var dLon = (Number(b.x()) - Number(a.x())) * Math.PI / 180.0

        var h = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(lat1) * Math.cos(lat2) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2)

        return 6371008.8 * 2.0 * Math.atan2(Math.sqrt(h), Math.sqrt(1.0 - h))
    }

    function bearingToTarget() {
        var a = currentWgs84()
        var b = targetWgs84()
        if (!a || !b)
            return NaN

        var lat1 = Number(a.y()) * Math.PI / 180.0
        var lat2 = Number(b.y()) * Math.PI / 180.0
        var dLon = (Number(b.x()) - Number(a.x())) * Math.PI / 180.0

        var yy = Math.sin(dLon) * Math.cos(lat2)
        var xx = Math.cos(lat1) * Math.sin(lat2) -
                 Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon)

        var bng = Math.atan2(yy, xx) * 180.0 / Math.PI
        if (bng < 0) bng += 360.0
        return bng
    }

    function walkingArrowRotation() {
        var targetBearing = bearingToTarget()
        if (!isFinite(targetBearing))
            return 0

        try {
            var info = iface.positioning().positionInformation
            if (info && info.directionValid && info.speedValid && Number(info.speed) > 0.15) {
                var travel = Number(info.direction)
                var r = targetBearing - travel
                while (r > 180) r -= 360
                while (r < -180) r += 360
                return r
            }
        } catch (e) {}

        return 0
    }

    function updateNavigationDisplay() {
        arrowRotation = walkingArrowRotation()
    }

    function distanceText() {
        var d = distanceMeters()
        if (!isFinite(d))
            return "--"
        if (d < 1000)
            return d.toFixed(d < 10 ? 2 : 1) + " m"
        return (d / 1000.0).toFixed(3) + " km"
    }

    function accuracyText() {
        try {
            var info = iface.positioning().positionInformation
            if (info && info.haccValid)
                return Number(info.hacc).toFixed(2) + " m"
        } catch (e) {}
        return "--"
    }

    function fixText() {
        try {
            var info = iface.positioning().positionInformation
            if (info && info.fixStatusDescription)
                return String(info.fixStatusDescription)
        } catch (e) {}
        return "--"
    }

    QfToolButton {
        id: stakeoutButton
        width: 56
        height: 56
        bgcolor: "#b71c1c"
        iconSource: Qt.resolvedUrl("stakeout.svg")
        iconColor: "white"
        round: true

        onClicked: {
            if (picking || active)
                clearTarget(true)
            else
                beginPick()
        }

        Text {
            anchors.centerIn: parent
            text: "STAKE"
            color: "white"
            font.bold: true
            font.pixelSize: 10
        }
    }

    Timer {
        interval: 250
        running: active
        repeat: true
        onTriggered: updateNavigationDisplay()
    }

    Rectangle {
        id: stakeoutPanel
        parent: mainWindow.contentItem
        visible: false
        z: 10000
        width: Math.min(mainWindow.width * 0.90, 430)
        height: 330
        x: (mainWindow.width - width) / 2
        y: 75
        radius: 14
        color: "#202124"
        border.color: "#777777"
        border.width: 1

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 16
            spacing: 7

            Label {
                id: statusText
                Layout.fillWidth: true
                text: "TAP A POINT"
                color: "#7CFC00"
                font.pixelSize: 20
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
            }

            Label {
                Layout.fillWidth: true
                text: targetName === "" ? "No target selected" : targetName
                color: "#dddddd"
                font.pixelSize: 17
                horizontalAlignment: Text.AlignHCenter
                elide: Text.ElideMiddle
            }

            Rectangle {
                Layout.fillWidth: true
                height: 150
                radius: 10
                color: "#111111"

                RowLayout {
                    anchors.fill: parent
                    anchors.margins: 8

                    Label {
                        Layout.fillWidth: true
                        text: distanceText()
                        color: "white"
                        font.pixelSize: 38
                        font.bold: true
                        horizontalAlignment: Text.AlignHCenter
                    }

                    Label {
                        Layout.preferredWidth: 110
                        text: "↑"
                        color: "#7CFC00"
                        font.pixelSize: 76
                        font.bold: true
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                        rotation: arrowRotation
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true

                Label {
                    Layout.fillWidth: true
                    text: "GNSS ± " + accuracyText()
                    color: "#cccccc"
                    font.pixelSize: 14
                }

                Label {
                    Layout.fillWidth: true
                    text: "Fix: " + fixText()
                    color: "#cccccc"
                    font.pixelSize: 14
                    horizontalAlignment: Text.AlignRight
                }
            }

            Label {
                Layout.fillWidth: true
                text: active && isFinite(distanceMeters()) && distanceMeters() <= arrivalThreshold
                      ? "✓ ARRIVED — within " + arrivalThreshold.toFixed(1) + " m"
                      : ""
                color: "#7CFC00"
                font.pixelSize: 15
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                Button {
                    Layout.fillWidth: true
                    text: "Pick Another"
                    onClicked: beginPick()
                }

                Button {
                    Layout.fillWidth: true
                    text: "Clear"
                    onClicked: clearTarget(false)
                }

                Button {
                    Layout.fillWidth: true
                    text: "Close"
                    onClicked: stakeoutPanel.visible = false
                }
            }
        }
    }
}
