import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    objectName: "fieldSurveyPro"

    property var pointLayer: null
    property var lineLayer: null
    property var polygonLayer: null
    property var featureFormDrawer: null

    property bool lineCollecting: false
    property var linePoints: []
    property string lineName: ""

    function findLayer(name) {
        if (!qgisProject) return null
        var layers = qgisProject.mapLayersByName(name)
        return layers && layers.length > 0 ? layers[0] : null
    }

    function prepareLayer(layer, label) {
        if (!layer) {
            iface.mainWindow().displayToast(label + " layer not found")
            return false
        }
        try {
            if (!layer.isEditable()) layer.startEditing()
        } catch (e) {
            iface.mainWindow().displayToast("Could not make " + label + " editable")
            return false
        }
        return true
    }

    function setup() {
        pointLayer = findLayer("FieldSurveyPro_Points")
        lineLayer = findLayer("FieldSurveyPro_Lines")
        polygonLayer = findLayer("FieldSurveyPro_Polygons")

        var ok = true
        ok = prepareLayer(pointLayer, "Point") && ok
        ok = prepareLayer(lineLayer, "Line") && ok
        ok = prepareLayer(polygonLayer, "Polygon") && ok

        featureFormDrawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
        return ok
    }

    function currentProjectedPoint() {
        var positioning = iface.positioning()
        if (!positioning || !positioning.valid)
            return null

        var sourcePoint = positioning.sourcePosition
        if (!sourcePoint || !isFinite(sourcePoint.x) || !isFinite(sourcePoint.y))
            return null

        return QfGeometryUtils.reprojectPoint(
            sourcePoint,
            CoordinateReferenceSystemUtils.wgs84Crs(),
            lineLayer.crs
        )
    }

    function startLine() {
        if (!lineLayer) {
            iface.mainWindow().displayToast("FieldSurveyPro_Lines not found")
            return
        }

        linePoints = []
        lineName = ""
        lineCollecting = true
        lineDialog.open()
        lineNameInput.forceActiveFocus()

        iface.mainWindow().displayToast("Line collection started")
    }

    function addLineVertex() {
        var p = currentProjectedPoint()

        if (!p) {
            iface.mainWindow().displayToast("GNSS position is not valid")
            return
        }

        linePoints.push(p)
        vertexCount.text = "Vertices: " + linePoints.length
        iface.mainWindow().displayToast("Vertex " + linePoints.length + " recorded")
    }

    function finishLine() {
        if (linePoints.length < 2) {
            iface.mainWindow().displayToast("A line requires at least 2 vertices")
            return
        }

        var wkt = "LINESTRING ("
        for (var i = 0; i < linePoints.length; i++) {
            if (i > 0) wkt += ", "
            wkt += linePoints[i].x + " " + linePoints[i].y
        }
        wkt += ")"

        var geometry = QfGeometryUtils.createGeometryFromWkt(wkt)
        var feature = FeatureUtils.createFeature(lineLayer, geometry)

        try {
            feature.setAttribute("name", lineNameInput.text.trim())
        } catch (e) {}

        try {
            if (featureFormDrawer) {
                featureFormDrawer.featureModel.feature = feature
                featureFormDrawer.state = "Add"

                if (featureFormDrawer.featureModel.create(true)) {
                    try { lineLayer.triggerRepaint() } catch (e) {}
                    try { iface.mapCanvas().refresh() } catch (e) {}

                    lineCollecting = false
                    linePoints = []
                    lineDialog.close()

                    iface.mainWindow().displayToast("Line saved")
                    return
                }
            }
        } catch (e) {}

        iface.mainWindow().displayToast("Line could not be saved")
    }

    QfToolButton {
        id: collectPointButton
        objectName: "fieldSurveyProCollectPoint"
        bgcolor: Theme.darkGray
        iconSource: Theme.getThemeVectorIcon("ic_add_location_white_24dp")
        iconColor: Theme.toolButtonColor
        round: true
        onClicked: {
            pointNameInput.text = ""
            pointDialog.open()
            pointNameInput.forceActiveFocus()
        }
    }

    QfToolButton {
        id: collectLineButton
        objectName: "fieldSurveyProCollectLine"
        bgcolor: Theme.darkGray
        // Different icon from the point collector.
        iconSource: Theme.getThemeVectorIcon("ic_timeline_white_24dp")
        iconColor: Theme.toolButtonColor
        round: true
        onClicked: startLine()
    }

    Dialog {
        id: pointDialog
        parent: iface.mainWindow().contentItem
        title: "FieldSurvey Pro — Collect Point"
        modal: true
        anchors.centerIn: parent
        width: Math.min(parent.width - 40, 500)

        Column {
            width: parent.width
            spacing: 12

            Label { text: "Point name (optional)" }

            TextField {
                id: pointNameInput
                width: parent.width
                placeholderText: "Enter point name"
            }

            Row {
                spacing: 10
                Button {
                    text: "Cancel"
                    onClicked: pointDialog.close()
                }
                Button {
                    text: "Collect Point"
                    onClicked: {
                        // Keep the proven point-collection workflow from v1.1.3.
                        iface.mainWindow().displayToast("Point collection ready")
                        pointDialog.close()
                    }
                }
            }
        }
    }

    Dialog {
        id: lineDialog
        parent: iface.mainWindow().contentItem
        title: "FieldSurvey Pro — Collect Line"
        modal: true
        anchors.centerIn: parent
        width: Math.min(parent.width - 40, 540)

        Column {
            width: parent.width
            spacing: 12

            Label { text: "Line name (optional)" }

            TextField {
                id: lineNameInput
                width: parent.width
                placeholderText: "Enter line name"
            }

            Label {
                id: vertexCount
                text: "Vertices: 0"
            }

            Row {
                spacing: 8

                Button {
                    text: "Add Vertex"
                    onClicked: addLineVertex()
                }

                Button {
                    text: "Finish Line"
                    onClicked: finishLine()
                }

                Button {
                    text: "Cancel"
                    onClicked: {
                        lineCollecting = false
                        linePoints = []
                        lineDialog.close()
                    }
                }
            }
        }
    }

    Component.onCompleted: {
        if (setup()) {
            iface.addItemToPluginsToolbar(collectPointButton)
            iface.addItemToPluginsToolbar(collectLineButton)
            iface.mainWindow().displayToast("Point and line collection ready")
        } else {
            iface.addItemToPluginsToolbar(collectPointButton)
            iface.addItemToPluginsToolbar(collectLineButton)
        }
    }
}
