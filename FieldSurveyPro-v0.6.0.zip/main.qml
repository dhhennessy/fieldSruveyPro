import QtQuick
import org.qfield.org

Item {
    id: fieldSurveyPro

    Component.onCompleted: {
        iface.mainWindow().displayToast("FieldSurvey Pro loaded")
    }

    function configure() {
        iface.mainWindow().displayToast("FieldSurvey Pro")
    }
}
