import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    property var mainWindow: iface.mainWindow()
    property var pointHandler: null
    property bool picking: false

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(stakeButton)
    }

    function startPicking() {
        pointHandler = iface.findItemByObjectName("pointHandler")
        if (!pointHandler) {
            mainWindow.displayToast("STAKEOUT: pointHandler NOT FOUND")
            return
        }

        try { pointHandler.deregisterHandler("FieldSurveyProStakeoutDiag") } catch (e) {}

        picking = true
        mainWindow.displayToast("STAKEOUT: TAP A POINT")

        pointHandler.registerHandler(
            "FieldSurveyProStakeoutDiag",
            function(point, type, interactionType) {
                if (!picking || interactionType !== "clicked")
                    return false

                // First prove that the QField map-tap callback is firing.
                mainWindow.displayToast("TAP RECEIVED")

                var layers = qgisProject.mapLayersByName("FieldSurveyPro_Points")
                if (!layers || layers.length === 0) {
                    mainWindow.displayToast("LAYER NOT FOUND")
                    return true
                }

                var layer = layers[0]
                mainWindow.displayToast("POINT LAYER FOUND")

                var it = null
                try {
                    it = LayerUtils.createFeatureIterator(layer)
                } catch (e1) {
                    mainWindow.displayToast("ITERATOR ERROR")
                    return true
                }

                if (!it) {
                    mainWindow.displayToast("ITERATOR NULL")
                    return true
                }

                var count = 0
                var firstFeature = null

                while (it.hasNext()) {
                    var f = it.next()
                    if (!f || !f.isValid)
                        continue

                    count++

                    if (!firstFeature)
                        firstFeature = f
                }

                if (!firstFeature) {
                    mainWindow.displayToast("LAYER HAS 0 FEATURES")
                    return true
                }

                var name = ""
                try {
                    name = String(firstFeature.attribute("name"))
                } catch (e2) {}

                if (name === "" || name === "undefined" || name === "null")
                    name = "Feature " + firstFeature.id()

                picking = false
                mainWindow.displayToast(
                    "FOUND " + count + " FEATURES; FIRST = " + name)

                return true
            },
            100
        )
    }

    QfToolButton {
        id: stakeButton
        width: 56
        height: 56
        iconSource: Theme.getThemeVectorIcon("ic_navigation_white_24dp")
        iconColor: Theme.toolButtonColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true

        onClicked: startPicking()

        Text {
            anchors.centerIn: parent
            text: "STAKE"
            color: "white"
            font.bold: true
            font.pixelSize: 10
        }
    }
}
