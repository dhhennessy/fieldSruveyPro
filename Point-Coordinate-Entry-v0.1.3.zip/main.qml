import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    objectName: "pointCoordinateEntryPlugin"

    property var dashBoard: iface.findItemByObjectName("dashBoard")
    property var overlayFeatureFormDrawer: iface.findItemByObjectName("overlayFeatureFormDrawer")
    property var mainWindow: iface.mainWindow()

    function showMessage(message) {
        if (mainWindow)
            mainWindow.displayToast(message)
    }

    function addPoint() {
        if (!dashBoard || !overlayFeatureFormDrawer) {
            showMessage("QField feature form is unavailable.")
            return
        }

        dashBoard.ensureEditableLayerSelected()
        var layer = dashBoard.activeLayer
        if (!layer) {
            showMessage("Select an editable point layer first.")
            return
        }
        if (layer.geometryType !== 0) {
            showMessage("The selected layer is not a point layer.")
            return
        }
        if (layer.crs.authid !== "EPSG:32617") {
            showMessage("Select a point layer using EPSG:32617. No reprojection is performed.")
            return
        }

        var xText = eastingField.text.trim()
        var yText = northingField.text.trim()
        var x = Number(xText)
        var y = Number(yText)
        if (xText === "" || yText === "" || !isFinite(x) || !isFinite(y)) {
            showMessage("Enter valid numeric easting and northing values.")
            return
        }
        if (x < 100000 || x > 900000 || y < 0 || y > 10000000) {
            showMessage("Coordinates are outside plausible UTM ranges.")
            return
        }

        try {
            var geometry = GeometryUtils.createGeometryFromWkt("POINT(" + x + " " + y + ")")
            var feature = FeatureUtils.createFeature(layer, geometry)
            overlayFeatureFormDrawer.featureModel.feature = feature
            overlayFeatureFormDrawer.state = "Add"
            overlayFeatureFormDrawer.open()
            entryDialog.close()
        } catch (error) {
            showMessage("Could not prepare point: " + error)
        }
    }

    QfToolButton {
        id: entryButton
        bgcolor: Theme.darkGray
        iconSource: "icon.svg"
        iconColor: Theme.mainColor
        round: true
        onClicked: {
            eastingField.text = ""
            northingField.text = ""
            entryDialog.open()
        }
    }

    Dialog {
        id: entryDialog
        parent: mainWindow ? mainWindow.contentItem : null
        modal: true
        title: "Enter Point Coordinates"
        standardButtons: Dialog.NoButton
        width: Math.min(parent ? parent.width - 32 : 420, 440)
        anchors.centerIn: parent

        contentItem: ColumnLayout {
            spacing: 12
            Label {
                text: "UTM Zone 17N · WGS84 (EPSG:32617)"
                wrapMode: Text.WordWrap
                Layout.fillWidth: true
            }
            TextField {
                id: eastingField
                objectName: "pointEntryEasting"
                placeholderText: "Easting (m)"
                inputMethodHints: Qt.ImhFormattedNumbersOnly
                validator: DoubleValidator { bottom: 100000; top: 900000; decimals: 3 }
                Layout.fillWidth: true
            }
            TextField {
                id: northingField
                objectName: "pointEntryNorthing"
                placeholderText: "Northing (m)"
                inputMethodHints: Qt.ImhFormattedNumbersOnly
                validator: DoubleValidator { bottom: 0; top: 10000000; decimals: 3 }
                Layout.fillWidth: true
            }
            Label {
                text: "Coordinates are written directly. The selected point layer must use EPSG:32617. The standard feature form will open for attributes."
                wrapMode: Text.WordWrap
                Layout.fillWidth: true
            }
            RowLayout {
                Layout.fillWidth: true
                Item { Layout.fillWidth: true }
                Button { text: "Cancel"; onClicked: entryDialog.close() }
                Button {
                    text: "Add Point"
                    highlighted: true
                    onClicked: plugin.addPoint()
                }
            }
        }
    }

    Component.onCompleted: iface.addItemToPluginsToolbar(entryButton)
}
