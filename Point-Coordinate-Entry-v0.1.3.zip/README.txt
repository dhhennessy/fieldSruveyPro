Point Coordinate Entry for QField
Version 0.1.3

Compatible target: QField 4.3.2
Plugin type: app-wide QML plugin

Creates point features from manually entered UTM Zone 17N WGS84 coordinates
(EPSG:32617). Coordinates are written directly, without reprojection. The
selected editable layer must be a point layer in EPSG:32617. The standard
QField feature form opens so its attributes can be completed and saved.

Install using QField's Plugin Manager > Install plugin from URL, using the
direct GitHub raw ZIP URL. The ZIP contains main.qml at its root.

This build corrects the utility names to GeometryUtils and FeatureUtils and
includes the referenced icon.svg. It has not been run on a QField device.
