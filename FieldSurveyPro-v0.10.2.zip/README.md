# FieldSurvey Pro 0.10.2

Adds automatic creation of a separate editable line layer for every completed line.

## Line workflow
1. Enter any line name.
2. Start Line.
3. Walk the line.
4. Vertices are committed every 5 ft (1.524 m) of movement.
5. Finish Line.
6. FieldSurvey Pro creates a new editable line layer named from the custom line name plus its unique LN identifier.
7. The layer contains the completed line feature and GNSS QA attributes.

Example:
`Fence West` becomes a layer such as `Fence_West_LN-000001`.

The layer is created using QField's memory-layer API and added to the current project. QField exposes `createMemoryLayer`/memory-layer creation specifically for creating vector layers from plugin code. The resulting layer is editable during the current project session.

This version intentionally does not change the working point collector.
