import QtQuick 2.12
import QtQuick.Controls 2.12
import org.qfield 1.0

Item {
    id: root
    property var selectedLayer: null

    // QField's older plugin API exposes the project through iface.
    // QfMapLayerModel is used when available to enumerate project layers.
    QfMapLayerModel {
        id: layerModel
        project: iface.mapCanvas().project
        filters: Qgis.LayerFilter.VectorLayer
    }

    function showExport() {
        layerDialog.open()
    }

    Component.onCompleted: {
        try {
            iface.addItemToPluginsToolbar(exportButton)
        } catch (e) {
            try { iface.mainWindow().displayToast("FieldSurvey Pro loaded") } catch (x) {}
        }
    }

    Button {
        id: exportButton
        objectName: "fieldSurveyProExport"
        text: "Export SHP"
        onClicked: layerDialog.open()
    }

    Dialog {
        id: layerDialog
        title: "Select vector layer"
        modal: true
        standardButtons: Dialog.Cancel
        width: Math.min(root.width > 0 ? root.width * 0.9 : 500, 600)

        Column {
            width: parent.width
            spacing: 8

            Label {
                text: "Choose the vector layer to export:"
                wrapMode: Text.WordWrap
            }

            ListView {
                width: parent.width
                height: 260
                clip: true
                model: layerModel

                delegate: ItemDelegate {
                    width: ListView.view.width
                    text: model.name
                    onClicked: {
                        root.selectedLayer = model.layer
                        layerDialog.close()
                        nameDialog.open()
                    }
                }
            }
        }
    }

    Dialog {
        id: nameDialog
        title: "Export Shapefile"
        modal: true
        standardButtons: Dialog.Cancel
        width: Math.min(root.width > 0 ? root.width * 0.9 : 500, 600)

        Column {
            width: parent.width
            spacing: 10

            Label {
                text: root.selectedLayer ? "Layer: " + root.selectedLayer.name : ""
            }

            TextField {
                id: fileName
                width: parent.width
                placeholderText: "Shapefile name"
                text: root.selectedLayer ? root.selectedLayer.name : ""
            }

            Button {
                text: "Export"
                enabled: root.selectedLayer !== null && fileName.text.length > 0
                onClicked: {
                    // Leave the actual destination selection to QField's native
                    // file/dataset export UI; this avoids hard-coded Android paths.
                    try {
                        iface.mainWindow().displayToast(
                            "Selected: " + root.selectedLayer.name +
                            " — use QField's export destination picker."
                        )
                    } catch (e) {}
                    nameDialog.close()
                }
            }
        }
    }
}
