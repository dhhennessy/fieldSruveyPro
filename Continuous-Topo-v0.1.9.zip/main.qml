import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin

    property var mainWindow: iface.mainWindow()
    property var targetLayer: null
    property bool logging: false
    property var vertices: []
    property var lastPoint: null
    property real totalDistance: 0
    property real intervalM: 1.524
    property real accuracy: -1
    property string lineName: ""
    property string gpsStatus: "Waiting for GNSS"

    Component.onCompleted: iface.addItemToPluginsToolbar(logButton)

    function d2r(v) {
        return v * Math.PI / 180
    }

    function r2d(v) {
        return v * 180 / Math.PI
    }

    function hav(a, b, c, d) {
        var R = 6371008.8
        var p1 = d2r(a)
        var p2 = d2r(c)
        var dp = d2r(c - a)
        var dl = d2r(d - b)
        var x = Math.sin(dp / 2) * Math.sin(dp / 2) +
                Math.cos(p1) * Math.cos(p2) *
                Math.sin(dl / 2) * Math.sin(dl / 2)
        return 2 * R * Math.atan2(Math.sqrt(x), Math.sqrt(Math.max(0, 1 - x)))
    }

    function bear(a, b, c, d) {
        var p1 = d2r(a)
        var p2 = d2r(c)
        var dl = d2r(d - b)
        var y = Math.sin(dl) * Math.cos(p2)
        var x = Math.cos(p1) * Math.sin(p2) -
                Math.sin(p1) * Math.cos(p2) * Math.cos(dl)
        return (r2d(Math.atan2(y, x)) + 360) % 360
    }

    function dest(a, b, br, dist) {
        var R = 6371008.8
        var t = d2r(br)
        var p = d2r(a)
        var l = d2r(b)
        var x = dist / R
        var p2 = Math.asin(
            Math.sin(p) * Math.cos(x) +
            Math.cos(p) * Math.sin(x) * Math.cos(t)
        )
        var l2 = l + Math.atan2(
            Math.sin(t) * Math.sin(x) * Math.cos(p),
            Math.cos(x) - Math.sin(p) * Math.sin(p2)
        )
        return {
            lat: r2d(p2),
            lon: ((r2d(l2) + 540) % 360) - 180
        }
    }

    function current() {
        var pos = iface.positioning()
        if (!pos) {
            gpsStatus = "No positioning service"
            return null
        }

        // QField exposes the live GNSS coordinate through
        // positioning.positionInformation.  The previous version tried
        // to read sourcePosition/valid, which can be unavailable even
        // while QField is receiving a perfectly good GNSS fix.
        var info = pos.positionInformation
        if (!info) {
            gpsStatus = "No position information"
            return null
        }

        if (!info.latitudeValid || !info.longitudeValid) {
            gpsStatus = "Waiting for valid GNSS"
            return null
        }

        var lat = Number(info.latitude)
        var lon = Number(info.longitude)

        if (!isFinite(lat) || !isFinite(lon) ||
            Math.abs(lat) > 90 || Math.abs(lon) > 180) {
            gpsStatus = "Invalid GNSS coordinate"
            return null
        }

        var a = Number(info.hacc)
        if (!isFinite(a))
            a = Number(info.horizontalAccuracy)

        accuracy = (isFinite(a) && a >= 0) ? a : -1
        gpsStatus = "GNSS OK"

        return {
            lat: lat,
            lon: lon
        }
    }

    function add(p) {
        vertices.push({
            lat: p.lat,
            lon: p.lon
        })
    }

    function sample(p) {
        if (!lastPoint) {
            add(p)
            lastPoint = p
            return
        }

        var seg = hav(lastPoint.lat, lastPoint.lon, p.lat, p.lon)
        if (!isFinite(seg) || seg <= 0)
            return

        if (seg < intervalM) {
            // Keep the most recent GNSS position so the next sample is
            // measured from where we actually are, rather than from the
            // last committed vertex.
            lastPoint = p
            return
        }

        var br = bear(lastPoint.lat, lastPoint.lon, p.lat, p.lon)
        var from = lastPoint
        var rem = seg

        while (rem >= intervalM) {
            var n = dest(from.lat, from.lon, br, intervalM)
            add(n)
            totalDistance += intervalM
            from = n
            rem = hav(from.lat, from.lon, p.lat, p.lon)
        }

        lastPoint = from
    }

    function layerIsEditable(layer) {
        if (!layer)
            return false

        try {
            if (typeof layer.isEditable === "function")
                return Boolean(layer.isEditable())
        } catch (e) {
        }

        try {
            return Boolean(layer.isEditable)
        } catch (e) {
            return false
        }
    }

    function getSelectedEditableLayer() {
        var lineLayers = qgisProject.mapLayersByName("FieldSurveyPro_Lines")
        var polygonLayers = qgisProject.mapLayersByName("FieldSurveyPro_Polygons")

        if (lineLayers && lineLayers.length > 0) {
            var line = lineLayers[0]
            if (layerIsEditable(line))
                return line
        }

        if (polygonLayers && polygonLayers.length > 0) {
            var polygon = polygonLayers[0]
            if (layerIsEditable(polygon))
                return polygon
        }

        return null
    }

    function start() {
        targetLayer = getSelectedEditableLayer()

        if (!targetLayer) {
            var lineLayers = qgisProject.mapLayersByName("FieldSurveyPro_Lines")
            var polygonLayers = qgisProject.mapLayersByName("FieldSurveyPro_Polygons")

            if (lineLayers && lineLayers.length > 0)
                targetLayer = lineLayers[0]
            else if (polygonLayers && polygonLayers.length > 0)
                targetLayer = polygonLayers[0]
        }

        if (!targetLayer) {
            mainWindow.displayToast("No FieldSurveyPro line or polygon layer found")
            return
        }

        var p = current()
        if (!p) {
            mainWindow.displayToast("Waiting for GNSS position")
            return
        }

        lineName = nameField.text.trim()

        if (lineName.length === 0) {
            mainWindow.displayToast("Enter a line name first")
            nameField.forceActiveFocus()
            return
        }

        vertices = []
        lastPoint = null
        totalDistance = 0
        logging = true
        sample(p)

        mainWindow.displayToast("CONTINUOUS TOPO: STARTED")
    }

    function stop() {
        if (!logging)
            return

        logging = false

        if (!targetLayer || vertices.length < 2) {
            mainWindow.displayToast("Need at least 2 vertices")
            vertices = []
            lastPoint = null
            return
        }

        try {
            var coords = ""

            for (var i = 0; i < vertices.length; i++) {
                var p = vertices[i]
                var q = QfGeometryUtils.reprojectPoint(
                    QfGeometryUtils.point(p.lon, p.lat),
                    CoordinateReferenceSystemUtils.wgs84Crs(),
                    targetLayer.crs
                )

                if (i)
                    coords += ","

                coords += Number(q.x) + " " + Number(q.y)
            }

            var gt = Number(targetLayer.geometryType())
            var w = ""

            if (gt === 1) {
                w = "LINESTRING(" + coords + ")"
            } else if (gt === 2) {
                var first = vertices[0]
                var fq = QfGeometryUtils.reprojectPoint(
                    QfGeometryUtils.point(first.lon, first.lat),
                    CoordinateReferenceSystemUtils.wgs84Crs(),
                    targetLayer.crs
                )
                coords += "," + Number(fq.x) + " " + Number(fq.y)
                w = "POLYGON((" + coords + "))"
            } else {
                mainWindow.displayToast("Unsupported geometry type")
                vertices = []
                lastPoint = null
                return
            }

            var f = FeatureUtils.createFeature(
                targetLayer,
                GeometryUtils.createGeometryFromWkt(w)
            )

            var fieldNames = f.fields.names
            var nameIndex = fieldNames.indexOf("name")

            if (nameIndex >= 0)
                f.setAttribute(nameIndex, lineName)

            if (LayerUtils.addFeature(targetLayer, f)) {
                var typeText = gt === 2 ? "POLYGON" : "LINE"
                mainWindow.displayToast(
                    typeText + " SAVED: " + lineName +
                    " (" + vertices.length + " vertices)"
                )
            } else {
                mainWindow.displayToast("FEATURE SAVE FAILED")
            }
        } catch (e) {
            mainWindow.displayToast("LINE SAVE ERROR: " + e)
        }

        vertices = []
        lastPoint = null
    }

    Timer {
        interval: 250
        repeat: true
        running: logging

        onTriggered: {
            var p = current()
            if (p)
                sample(p)
        }
    }

    QfToolButton {
        id: logButton

        width: 56
        height: 56
        iconSource: Theme.getThemeVectorIcon("ic_timeline_white_24dp")
        iconColor: "white"
        bgcolor: logging ? "#b00020" : "#1976d2"
        round: true

        onClicked: {
            if (logging)
                stop()
            else
                panel.visible = true
        }

        Text {
            anchors.centerIn: parent
            text: logging ? "STOP" : "LOG"
            color: "white"
            font.bold: true
            font.pixelSize: 10
        }
    }

    Rectangle {
        id: panel
        parent: mainWindow.contentItem
        visible: false

        anchors.top: parent.top
        anchors.topMargin: 80
        anchors.horizontalCenter: parent.horizontalCenter

        width: 330
        height: 320
        radius: 12
        color: "#DD202020"
        border.color: "white"
        border.width: 1
        z: 100000

        Text {
            x: 15
            y: 12
            text: "Continuous Topo"
            color: "white"
            font.bold: true
            font.pixelSize: 20
        }

        Text {
            x: 15
            y: 48
            text: "Line name"
            color: "#DDDDDD"
            font.pixelSize: 14
        }

        TextField {
            id: nameField
            x: 15
            y: 70
            width: 300
            height: 42
            text: lineName
            placeholderText: "Enter line name"
            color: "white"
            placeholderTextColor: "#BBBBBB"
            selectionColor: "#1976d2"
            selectedTextColor: "white"

            background: Rectangle {
                radius: 6
                color: "#3A3A3A"
                border.color: "#8A8A8A"
                border.width: 1
            }

            onTextChanged: lineName = text
        }

        Text {
            x: 15
            y: 120
            text: "Vertex spacing"
            color: "#DDDDDD"
            font.pixelSize: 14
        }

        ComboBox {
            id: spacing
            x: 15
            y: 142
            width: 180
            height: 42

            model: [
                "1 ft (0.3048 m)",
                "5 ft (1.524 m)",
                "10 ft (3.048 m)",
                "25 ft (7.620 m)",
                "50 ft (15.240 m)",
                "Custom"
            ]

            currentIndex: 1

            contentItem: Text {
                leftPadding: 10
                rightPadding: 30
                verticalAlignment: Text.AlignVCenter
                text: spacing.displayText
                color: "black"
                font.pixelSize: 14
                elide: Text.ElideRight
            }

            background: Rectangle {
                radius: 6
                color: "white"
                border.color: "#777777"
                border.width: 1
            }

            onCurrentIndexChanged: {
                if (currentIndex === 0)
                    intervalM = 0.3048
                else if (currentIndex === 1)
                    intervalM = 1.524
                else if (currentIndex === 2)
                    intervalM = 3.048
                else if (currentIndex === 3)
                    intervalM = 7.620
                else if (currentIndex === 4)
                    intervalM = 15.240
            }
        }

        TextField {
            id: custom
            x: 205
            y: 142
            width: 105
            height: 42
            placeholderText: "meters"
            enabled: spacing.currentIndex === 5
            color: "white"
            placeholderTextColor: "#BBBBBB"

            background: Rectangle {
                radius: 6
                color: "#3A3A3A"
                border.color: "#8A8A8A"
                border.width: 1
            }

            onTextChanged: {
                var v = Number(text)
                if (enabled && isFinite(v) && v > 0)
                    intervalM = v
            }
        }

        Text {
            x: 15
            y: 190
            text: "Distance: " + totalDistance.toFixed(1) + " m"
            color: "white"
            font.pixelSize: 15
        }

        Text {
            x: 15
            y: 213
            text: "Vertices: " + vertices.length
            color: "white"
            font.pixelSize: 15
        }

        Text {
            x: 15
            y: 236
            text: logging ? "LOGGING" : gpsStatus
            color: logging ? "#66FF66" : "#DDDDDD"
            font.bold: logging
            font.pixelSize: 13
        }

        Text {
            x: 15
            y: 254
            text: gpsStatus
            color: "#BBBBBB"
            font.pixelSize: 11
        }

        Text {
            x: 150
            y: 236
            text: "Accuracy: " + (accuracy >= 0 ? accuracy.toFixed(2) + " m" : "--")
            color: "#DDDDDD"
            font.pixelSize: 13
        }

        QfToolButton {
            id: startButton
            x: 15
            y: 278
            width: 140
            height: 36
            bgcolor: logging ? "#b00020" : "#1976d2"
            iconColor: "white"

            Text {
                anchors.centerIn: parent
                text: logging ? "STOP" : "START"
                color: "white"
                font.bold: true
            }

            onClicked: {
                if (logging)
                    stop()
                else
                    start()
            }
        }

        Rectangle {
            x: 175
            y: 278
            width: 140
            height: 36
            radius: 7
            color: logging ? "#666666" : "#444444"
            opacity: logging ? 0.45 : 1.0

            Text {
                anchors.centerIn: parent
                text: "CANCEL"
                color: "white"
                font.bold: true
            }

            MouseArea {
                anchors.fill: parent
                onClicked: {
                    if (!logging)
                        panel.visible = false
                }
            }
        }
    }
}
