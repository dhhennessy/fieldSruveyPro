import QtQuick 2.12
import QtQuick.Controls 2.12
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin

    property var selectedLayer: null
    property string selectedLayerName: ""

    QfToolButton {
        id: exportButton
        bgcolor: Theme.darkGray
        iconSource: Qt.resolvedUrl("export.svg")
        iconColor: "white"
        round: true
        onClicked: exportDialog.open()
    }

    Dialog {
        id: exportDialog
        parent: iface.mainWindow().contentItem
        modal: true
        title: "Export Shapefile"
        width: Math.min(iface.mainWindow().width - 40, 560)
        height: Math.min(iface.mainWindow().height - 80, 520)
        x: (iface.mainWindow().width - width) / 2
        y: (iface.mainWindow().height - height) / 2

        contentItem: Column {
            spacing: 10
            padding: 16

            Label {
                text: "Select a vector layer:"
                font.bold: true
            }

            ListView {
                id: layerList
                width: exportDialog.width - 32
                height: 300
                clip: true

                model: ListModel { id: layersModel }

                delegate: ItemDelegate {
                    width: layerList.width
                    text: model.layerName
                    onClicked: {
                        plugin.selectedLayerName = model.layerName
                        plugin.selectedLayer = model.layerObject
                    }
                }
            }

            Label {
                text: plugin.selectedLayer ?
                      "Selected: " + plugin.selectedLayerName :
                      "No layer selected"
                wrapMode: Text.WordWrap
            }

            Row {
                spacing: 10

                Button {
                    text: "Export Shapefile"
                    enabled: plugin.selectedLayer !== null

                    onClicked: {
                        var layer = plugin.selectedLayer
                        var base = plugin.selectedLayerName
                        base = base.replace(/[^A-Za-z0-9_-]/g, "_")
                        if (!base.length)
                            base = "export"

                        // Old QField-compatible route:
                        // saveVectorLayerAs is invoked through the QfLayerUtils
                        // singleton, and the extension selects the OGR driver.
                        try {
                            var path = qgisProject.absolutePath() +
                                       "/" + base + "_FieldSurveyPro.shp"

                            var result = QfLayerUtils.saveVectorLayerAs(
                                layer, path, "ESRI Shapefile"
                            )

                            if (result && result.length > 0) {
                                exportDialog.close()
                                iface.mainWindow().displayToast(
                                    "Shapefile exported: " + result
                                )
                            } else {
                                iface.mainWindow().displayToast(
                                    "Export failed"
                                )
                            }
                        } catch (e) {
                            iface.mainWindow().displayToast(
                                "Export API not available: " + e
                            )
                        }
                    }
                }

                Button {
                    text: "Refresh"
                    onClicked: populateLayers()
                }

                Button {
                    text: "Cancel"
                    onClicked: exportDialog.close()
                }
            }
        }

        function populateLayers() {
            layersModel.clear()
            plugin.selectedLayer = null
            plugin.selectedLayerName = ""

            try {
                // Older QField exposes the QGIS project object and its
                // mapLayers() method. No QfMapLayerModel is used.
                var map = qgisProject.mapLayers()
                for (var id in map) {
                    var layer = map[id]
                    if (!layer)
                        continue

                    // Older QGIS/QField exposes geometryType() for vector
                    // layers. Raster layers do not have this callable.
                    try {
                        var gt = layer.geometryType()
                        layersModel.append({
                            "layerName": layer.name,
                            "layerObject": layer
                        })
                    } catch (e) {
                        // Not a vector layer.
                    }
                }

                if (layersModel.count === 0)
                    iface.mainWindow().displayToast(
                        "No vector layers found"
                    )
            } catch (e) {
                iface.mainWindow().displayToast(
                    "Could not read project layers"
                )
            }
        }

        onOpened: populateLayers()
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(exportButton)
    }
}
