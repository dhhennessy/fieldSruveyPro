# FieldSurvey Pro 0.10.4

Reposted build of the 0.10.3 line-collection build.

Features:
- User-defined point names.
- GNSS quality controls.
- Distance-based line vertices every 5 ft (1.524 m).
- Automatic creation of a separate editable line layer for each completed line.
- Unique LN-000001 style internal line IDs.

This build is otherwise unchanged from 0.10.3.
