import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    property var mainWindow: iface.mainWindow()
    property var dashboard: iface.findItemByObjectName("dashBoard")
    property var navigation: iface.findItemByObjectName("navigation")
    property bool active: false
    property string targetName: ""
    property real arrivalThreshold: 0.5

    Component.onCompleted: iface.addItemToPluginsToolbar(stakeoutButton)

    // QField's layer object exposes selectedFeatureIds() more reliably than
    // selectedFeatures() on older Android/QField plugin environments.
    function selectedFeatureInfo() {
        var layer = dashboard ? dashboard.activeLayer : null
        if (!layer) return null

        try {
            var ids = layer.selectedFeatureIds()
            if (!ids || ids.length !== 1) return null

            var fid = ids[0]
            var feature = layer.getFeature(fid)
            if (!feature || !feature.isValid()) return null

            return { layer: layer, feature: feature }
        } catch (e) {
            iface.logMessage("QField Stakeout selection error: " + e)
            return null
        }
    }

    function startStakeout() {
        var info = selectedFeatureInfo()
        if (!info) {
            mainWindow.displayToast("Select exactly one point feature first")
            return
        }

        try {
            navigation.setDestinationFeature(info.feature, info.layer)
            targetName = getTargetName(info.feature)
            active = true
            mainWindow.displayToast("Stakeout started: " + targetName)
        } catch (e) {
            iface.logMessage("QField Stakeout start error: " + e)
            mainWindow.displayToast("Could not start stakeout")
        }
    }

    function clearStakeout() {
        try { navigation.clear() } catch (e) {
            try { navigation.clearDestinationFeature() } catch (e2) {}
        }
        active = false
        targetName = ""
        mainWindow.displayToast("Stakeout cleared")
    }

    function getTargetName(feature) {
        try {
            var n = feature.attribute("name")
            if (n !== null && n !== undefined && String(n) !== "")
                return String(n)
        } catch (e) {}
        try { return "Point " + feature.id() } catch (e2) {}
        return "Target"
    }

    function distanceText() {
        if (!navigation || !navigation.isActive) return "--"
        var d = Number(navigation.distance)
        if (!isFinite(d)) return "--"
        if (d < 1) return d.toFixed(2) + " m"
        if (d < 1000) return d.toFixed(1) + " m"
        return (d / 1000).toFixed(3) + " km"
    }

    function bearingText() {
        if (!navigation || !navigation.isActive) return "--"
        var b = Number(navigation.bearing)
        if (!isFinite(b)) return "--"
        if (b < 0) b += 360
        return b.toFixed(1) + "°"
    }

    function accuracyText() {
        try {
            var p = iface.positioning()
            var pi = p.positionInformation
            if (pi && pi.haccValid) return Number(pi.hacc).toFixed(2) + " m"
        } catch (e) {}
        return "--"
    }

    function fixText() {
        try {
            var p = iface.positioning()
            var pi = p.positionInformation
            if (pi && pi.fixStatusDescription) return String(pi.fixStatusDescription)
        } catch (e) {}
        return "--"
    }

    QfToolButton {
        id: stakeoutButton
        bgcolor: "#b71c1c"
        iconSource: "stakeout.svg"
        iconColor: "white"
        round: true
        width: 56
        height: 56
        onClicked: {
            if (active) clearStakeout()
            else startStakeout()
        }

        Text {
            anchors.centerIn: parent
            text: "STAKE"
            color: "white"
            font.bold: true
            font.pixelSize: 10
        }
    }

    Timer {
        interval: 500
        running: active
        repeat: true
        onTriggered: stakeoutPanel.visible = true
    }

    Rectangle {
        id: stakeoutPanel
        parent: mainWindow.contentItem
        visible: false
        z: 10000
        width: Math.min(mainWindow.width * 0.90, 430)
        height: 300
        x: (mainWindow.width - width) / 2
        y: 75
        radius: 14
        color: "#202124"
        border.color: "#777777"
        border.width: 1

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 16
            spacing: 8

            Label {
                Layout.fillWidth: true
                text: "STAKEOUT"
                color: "white"
                font.pixelSize: 22
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
            }

            Label {
                Layout.fillWidth: true
                text: targetName
                color: "#dddddd"
                font.pixelSize: 17
                horizontalAlignment: Text.AlignHCenter
                elide: Text.ElideMiddle
            }

            Rectangle {
                Layout.fillWidth: true
                height: 105
                radius: 10
                color: "#111111"

                Column {
                    anchors.centerIn: parent
                    spacing: 4

                    Label {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: distanceText()
                        color: "white"
                        font.pixelSize: 38
                        font.bold: true
                    }

                    Label {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: "BEARING  " + bearingText()
                        color: "#dddddd"
                        font.pixelSize: 18
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true

                Label {
                    Layout.fillWidth: true
                    text: "GNSS ± " + accuracyText()
                    color: "#cccccc"
                    font.pixelSize: 14
                }

                Label {
                    Layout.fillWidth: true
                    text: "Fix: " + fixText()
                    color: "#cccccc"
                    font.pixelSize: 14
                    horizontalAlignment: Text.AlignRight
                }
            }

            Label {
                Layout.fillWidth: true
                text: (navigation && navigation.isActive &&
                       Number(navigation.distance) <= arrivalThreshold)
                      ? "✓ ARRIVED — within " + arrivalThreshold.toFixed(1) + " m"
                      : "Walk toward the target"
                color: (navigation && navigation.isActive &&
                        Number(navigation.distance) <= arrivalThreshold)
                       ? "#7CFC00" : "#eeeeee"
                font.pixelSize: 15
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                Button {
                    Layout.fillWidth: true
                    text: "Clear"
                    onClicked: {
                        clearStakeout()
                        stakeoutPanel.visible = false
                    }
                }

                Button {
                    Layout.fillWidth: true
                    text: "Close"
                    onClicked: stakeoutPanel.visible = false
                }
            }
        }
    }
}
