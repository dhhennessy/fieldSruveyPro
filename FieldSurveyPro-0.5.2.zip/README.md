# FieldSurvey Pro 0.5.2

Compatibility test build.

This build intentionally uses only the minimal QField application-plugin API:
- QtQuick
- org.qfield.org
- iface.mainWindow()
- iface.mapCanvas()
- iface.positioning()

When loaded, QField should display:
"FieldSurvey Pro loaded"

Install from QField:
Side Dashboard -> Plugin Manager -> Install plugin from URL

The URL must point directly to this ZIP archive. The ZIP must have main.qml at its root.
