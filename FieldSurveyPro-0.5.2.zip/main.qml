import QtQuick
import org.qfield.org

Item {
    id: fieldSurveyPro
    objectName: "fieldSurveyPro"

    property var mainWindow: iface.mainWindow()
    property var mapCanvas: iface.mapCanvas()
    property var positioning: iface.positioning()

    Component.onCompleted: {
        mainWindow.displayToast("FieldSurvey Pro loaded")
    }
}
