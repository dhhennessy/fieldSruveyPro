import QtQuick
import QtQuick.Controls
import QtCore
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    objectName: "fieldSurveyPro"

    property var dashBoard: iface.findItemByObjectName("dashBoard")
    property var overlayFeatureFormDrawer: iface.findItemByObjectName("overlayFeatureFormDrawer")
    property var positioning: iface.positioning()
    property var mainWindow: iface.mainWindow()

    Settings {
        id: settings
        category: "FieldSurveyPro"
        property int pointCounter: 1
        property string pointPrefix: "PT-"
    }

    function pointId() {
        return settings.pointPrefix + ("000000" + settings.pointCounter).slice(-6)
    }

    function fieldIndex(layer, fieldName) {
        if (!layer || !layer.fields)
            return -1
        return layer.fields.indexOf(fieldName)
    }

    function setIfPresent(feature, layer, fieldName, value) {
        if (fieldIndex(layer, fieldName) >= 0)
            feature.setAttribute(fieldName, value)
    }

    function gnssInfo() {
        if (!positioning || !positioning.active)
            return null
        return positioning.positionInformation
    }

    function collectPoint() {
        dashBoard.ensureEditableLayerSelected()

        if (!dashBoard.activeLayer) {
            mainWindow.displayToast("Select an editable point layer first")
            return
        }

        const layer = dashBoard.activeLayer
        const info = gnssInfo()

        if (!info) {
            mainWindow.displayToast("GNSS positioning is not active")
            return
        }

        if (!info.longitudeValid || !info.latitudeValid) {
            mainWindow.displayToast("No valid GNSS position")
            return
        }

        const projectedPosition = positioning.projectedPosition
        const wkt = "POINT(" + projectedPosition.x + " " + projectedPosition.y + ")"
        const geometry = GeometryUtils.createGeometryFromWkt(wkt)
        const feature = FeatureUtils.createFeature(layer, geometry)
        const id = pointId()

        setIfPresent(feature, layer, "name", id)
        setIfPresent(feature, layer, "id", id)
        setIfPresent(feature, layer, "feature_id", id)

        // GNSS quality fields. Field names are intentionally simple and
        // only populated when the destination layer already contains them.
        setIfPresent(feature, layer, "gnss_status", info.qualityDescription)
        setIfPresent(feature, layer, "h_accuracy", info.horizontalAccuracy)
        setIfPresent(feature, layer, "v_accuracy", info.verticalAccuracy)
        setIfPresent(feature, layer, "pdop", info.pdop)
        setIfPresent(feature, layer, "satellites", info.numberOfUsedSatellites)
        setIfPresent(feature, layer, "gnss_source", info.sourceName)

        // Also support common alternate field names.
        setIfPresent(feature, layer, "horizontal_accuracy", info.horizontalAccuracy)
        setIfPresent(feature, layer, "vertical_accuracy", info.verticalAccuracy)
        setIfPresent(feature, layer, "gnss_pdop", info.pdop)
        setIfPresent(feature, layer, "gnss_satellites", info.numberOfUsedSatellites)
        setIfPresent(feature, layer, "gnss_quality", info.qualityDescription)

        settings.pointCounter = settings.pointCounter + 1

        overlayFeatureFormDrawer.featureModel.feature = feature
        overlayFeatureFormDrawer.state = "Add"
        overlayFeatureFormDrawer.open()
    }

    function statusText() {
        const info = gnssInfo()
        if (!info)
            return "GNSS: inactive"

        if (!info.longitudeValid || !info.latitudeValid)
            return "GNSS: no valid fix"

        return "GNSS: " + info.qualityDescription +
               "\nH: " + Number(info.horizontalAccuracy).toFixed(3) + " m" +
               "   V: " + Number(info.verticalAccuracy).toFixed(3) + " m" +
               "\nPDOP: " + Number(info.pdop).toFixed(2) +
               "   Satellites: " + info.numberOfUsedSatellites
    }

    QfToolButton {
        id: surveyButton
        objectName: "fieldSurveyProButton"
        bgcolor: Theme.darkGray
        iconSource: "icon.svg"
        iconColor: Theme.mainColor
        round: true

        onClicked: panel.open()
    }

    Dialog {
        id: panel
        title: "FieldSurvey Pro"
        modal: true
        parent: mainWindow.contentItem
        width: Math.min(mainWindow.width - 40, 420)
        x: (mainWindow.width - width) / 2
        y: (mainWindow.height - height) / 2

        Column {
            width: parent.width
            spacing: 12

            Label {
                width: parent.width
                text: "GNSS Point Collection"
                font.bold: true
                font.pixelSize: 20
            }

            Label {
                width: parent.width
                text: "Next point: " + pointId()
            }

            Label {
                width: parent.width
                text: statusText()
                wrapMode: Text.WordWrap
            }

            Button {
                width: parent.width
                text: "COLLECT POINT"
                enabled: gnssInfo() !== null &&
                         gnssInfo().longitudeValid &&
                         gnssInfo().latitudeValid
                onClicked: {
                    panel.close()
                    collectPoint()
                }
            }

            Label {
                width: parent.width
                text: "The active QField layer must be an editable point layer. GNSS QA values are written only when matching fields exist."
                wrapMode: Text.WordWrap
            }

            Button {
                width: parent.width
                text: "Close"
                onClicked: panel.close()
            }
        }
    }

    function configure() {
        panel.open()
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(surveyButton)
        mainWindow.displayToast("FieldSurvey Pro 0.8.2 loaded")
    }
}
