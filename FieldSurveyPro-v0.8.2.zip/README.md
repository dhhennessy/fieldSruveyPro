# FieldSurvey Pro 0.8.2

Conservative GNSS point-collection build for QField.

## Changes in 0.8.2
- Keeps the working 0.8.1 point-collection workflow.
- Captures GNSS quality information from QField's live positioning object.
- Shows GNSS status, horizontal accuracy, vertical accuracy, PDOP, and satellite count before collection.
- Writes GNSS QA values into matching fields when those fields already exist in the active point layer.
- Does not require those fields to exist; collection still works if they are absent.

Recommended point-layer fields:
- name
- id
- feature_id
- gnss_status
- h_accuracy
- v_accuracy
- pdop
- satellites
- gnss_source

The plugin deliberately does not create or modify project layers automatically yet.
