# FieldSurvey Pro 0.9.1

Adds user-defined point names while retaining the unique internal point ID.

## Point naming
- The collector now has a Point name field.
- Enter any name you want for each point.
- The `name` attribute receives that value.
- The `id` / `feature_id` fields continue to receive the automatically generated unique ID when those fields exist.
- The next suggested name defaults to the next generated point ID.
- Blank point names are rejected.

GNSS quality controls and attributes from 0.9.0 remain unchanged.
