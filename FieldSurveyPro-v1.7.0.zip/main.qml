import QtQuick 2.12
import QtQuick.Controls 2.12
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    objectName: "FieldSurveyPro"

    property var selectedLayer: null
    property string selectedLayerName: ""

    QfToolButton {
        id: exportButton
        objectName: "fieldSurveyProExportButton"
        bgcolor: Theme.darkGray
        iconSource: Qt.resolvedUrl("export.svg")
        iconColor: "white"
        round: true
        onClicked: exportDialog.open()
    }

    Dialog {
        id: exportDialog
        parent: iface.mainWindow().contentItem
        modal: true
        title: "Export Shapefile"
        width: Math.min(iface.mainWindow().width - 40, 560)
        height: Math.min(iface.mainWindow().height - 80, 560)
        x: (iface.mainWindow().width - width) / 2
        y: (iface.mainWindow().height - height) / 2

        property bool populated: false

        function populateLayers() {
            vectorLayers.clear()
            selectedLayer = null
            selectedLayerName = ""

            try {
                // This avoids QfMapLayerModel completely.
                // QField exposes the rendered project layers through mapSettings.layers.
                var layers = iface.mapCanvas().mapSettings.layers
                for (var i = 0; i < layers.length; ++i) {
                    var lyr = layers[i]
                    if (!lyr)
                        continue

                    // QgsMapLayer::VectorLayer == 0.
                    var isVector = false
                    try {
                        isVector = (lyr.type === 0)
                    } catch (e) {}

                    if (isVector) {
                        vectorLayers.append({
                            "layerName": lyr.name,
                            "layerId": lyr.id
                        })
                    }
                }
                populated = true
            } catch (e) {
                try {
                    iface.mainWindow().displayToast("Could not read project layers")
                } catch (x) {}
            }
        }

        onOpened: populateLayers()

        contentItem: Column {
            spacing: 10
            padding: 16

            Label {
                text: "Select a vector layer:"
                font.bold: true
            }

            ListView {
                id: layerList
                width: exportDialog.width - 32
                height: 300
                clip: true
                model: ListModel { id: vectorLayers }

                delegate: ItemDelegate {
                    width: layerList.width
                    text: model.layerName
                    highlighted: plugin.selectedLayerName === model.layerName
                    onClicked: {
                        plugin.selectedLayer = qgisProject.mapLayer(model.layerId)
                        plugin.selectedLayerName = model.layerName
                    }
                }
            }

            Label {
                width: parent.width
                text: plugin.selectedLayer
                      ? "Selected: " + plugin.selectedLayerName
                      : "No layer selected"
                wrapMode: Text.WordWrap
            }

            Row {
                spacing: 10

                Button {
                    text: "Export Shapefile"
                    enabled: plugin.selectedLayer !== null
                    onClicked: {
                        if (!plugin.selectedLayer)
                            return

                        var base = plugin.selectedLayer.name
                        base = base.replace(/[^A-Za-z0-9_-]/g, "_")
                        if (base.length === 0)
                            base = "export"

                        var tempPath = qgisProject.absolutePath()
                                      + "/"
                                      + base
                                      + "_FieldSurveyPro.shp"

                        try {
                            // QField's LayerUtils writes vector layers through OGR.
                            var result = LayerUtils.saveVectorLayerAs(
                                plugin.selectedLayer,
                                tempPath,
                                "ESRI Shapefile"
                            )

                            if (result !== "") {
                                exportDialog.close()

                                // Ask QField's platform utility to let the user
                                // choose the destination for the exported dataset.
                                try {
                                    platformUtilities.exportDatasetTo(result)
                                } catch (e1) {
                                    try {
                                        var pu = iface.findItemByObjectName("platformUtilities")
                                        pu.exportDatasetTo(result)
                                    } catch (e2) {
                                        iface.mainWindow().displayToast(
                                            "Shapefile created in the project folder"
                                        )
                                    }
                                }
                            } else {
                                iface.mainWindow().displayToast(
                                    "Shapefile export failed"
                                )
                            }
                        } catch (e) {
                            iface.mainWindow().displayToast(
                                "Export error: " + e
                            )
                        }
                    }
                }

                Button {
                    text: "Cancel"
                    onClicked: exportDialog.close()
                }
            }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(exportButton)
    }
}
