import QtQuick
import QtQuick.Controls
import QtCore
import org.qfield
import org.qgis
import Theme

Item {
    property string panelMode: "point"
    id: plugin
    objectName: "fieldSurveyPro"

    property var dashBoard: iface.findItemByObjectName("dashBoard")
    property var overlayFeatureFormDrawer: iface.findItemByObjectName("overlayFeatureFormDrawer")
    property var positioning: iface.positioning()
    property var mainWindow: iface.mainWindow()

    Settings {
        id: settings
        category: "FieldSurveyPro"
        property int pointCounter: 1
        property string pointPrefix: "PT-"
        property string lastPointName: ""
        property int lineCounter: 1
        property string linePrefix: "LN-"
        property bool qualityLock: false
        property real maxHorizontalAccuracy: 0.10
        property real maxVerticalAccuracy: 0.20
        property real maxPdop: 3.0
        property int minSatellites: 8
        property bool rtkOnly: false
    }

    property var pointLayer: null
    property var lineLayer: null
    property var polygonLayer: null

    function findLayer(name, geometryType) {
        const matches = qgisProject.mapLayersByName(name)
        if (!matches || matches.length === 0)
            return null
        for (let i = 0; i < matches.length; i++) {
            const l = matches[i]
            if (l && l.geometryType === geometryType)
                return l
        }
        return null
    }

    function makeLayer(name, geometry, properties, seedGeometry) {
        const geojson = JSON.stringify({
            type: "FeatureCollection",
            features: [{
                type: "Feature",
                properties: properties,
                geometry: seedGeometry
            }]
        })
        let layer = null
        try {
            layer = LayerUtils.memoryLayerFromJsonString(name, geojson, qgisProject.crs)
        } catch (e) {
            mainWindow.displayToast("Could not create " + name)
            return null
        }
        if (!layer)
            return null

        qgisProject.addMapLayer(layer)

        // Memory layers have no guaranteed renderer when created by a plugin.
        // Give the survey layer a visible default symbol immediately.
        try {
            LayerUtils.setDefaultRenderer(layer, qgisProject)
        } catch (e) {}

        try {
            layer.setVisible(true)
        } catch (e) {}

        // The GeoJSON seed establishes the attribute schema. Remove the seed
        // immediately so the new layer starts empty.
        try {
            LayerUtils.deleteFeature(qgisProject, layer, 1, true)
        } catch (e) {
            // If a provider uses another initial FID, leave the layer intact;
            // collection remains usable and the issue is reported below.
        }

        try {
            if (layer.startEditing)
                layer.startEditing()
        } catch (e) {}

        return layer
    }

    function ensureSurveyLayers() {
        pointLayer = findLayer("FieldSurveyPro_Points", 0)
        lineLayer = findLayer("FieldSurveyPro_Lines", 1)
        polygonLayer = findLayer("FieldSurveyPro_Polygons", 2)

        if (!pointLayer) {
            pointLayer = makeLayer(
                "FieldSurveyPro_Points",
                "Point",
                {name:"", id:"", feature_id:"", gnss_status:"", h_accuracy:0.0,
                 v_accuracy:0.0, pdop:0.0, satellites:0, gnss_source:"", gnss_timestamp:""},
                {type:"Point", coordinates:[0,0]})
        }

        if (!lineLayer) {
            lineLayer = makeLayer(
                "FieldSurveyPro_Lines",
                "LineString",
                {name:"", id:"", feature_id:"", vertex_count:0, length_m:0.0,
                 gnss_status:"", h_accuracy:0.0, v_accuracy:0.0, pdop:0.0,
                 satellites:0, gnss_source:""},
                {type:"LineString", coordinates:[[0,0],[0.000001,0.000001]]})
        }

        if (!polygonLayer) {
            polygonLayer = makeLayer(
                "FieldSurveyPro_Polygons",
                "Polygon",
                {name:"", id:"", feature_id:"", vertex_count:0, area_m2:0.0,
                 gnss_status:"", h_accuracy:0.0, v_accuracy:0.0, pdop:0.0,
                 satellites:0, gnss_source:""},
                {type:"Polygon", coordinates:[[[0,0],[0.000001,0],[0,0.000001],[0,0]]]})
        }

        if (pointLayer && pointLayer.startEditing) pointLayer.startEditing()
        if (lineLayer && lineLayer.startEditing) lineLayer.startEditing()
        if (polygonLayer && polygonLayer.startEditing) polygonLayer.startEditing()

        if (pointLayer && lineLayer && polygonLayer)
            mainWindow.displayToast("FieldSurvey Pro: point, line and polygon layers ready")
        else
            mainWindow.displayToast("FieldSurvey Pro: one or more survey layers could not be created")
    }

    function pointId() {
        return settings.pointPrefix + ("000000" + settings.pointCounter).slice(-6)
    }

    function fieldIndex(layer, fieldName) {
        if (!layer || !layer.fields)
            return -1
        return layer.fields.indexOf(fieldName)
    }

    function setIfPresent(feature, layer, fieldName, value) {
        if (fieldIndex(layer, fieldName) >= 0)
            feature.setAttribute(fieldName, value)
    }

    function gnssInfo() {
        void gnssStatusVersion
        if (!positioning || !positioning.active)
            return null
        return positioning.positionInformation
    }

    function hasValidPosition(info) {
        return info &&
               info.longitudeValid &&
               info.latitudeValid
    }

    function qualityPasses(info) {
        if (!qualityLockEnabled)
            return hasValidPosition(info)

        if (!hasValidPosition(info))
            return false

        const h = Number(info.hacc)
        const v = Number(info.vacc)
        const p = Number(info.pdop)
        const s = Number(info.satellitesUsed)

        if (!info.haccValid || !info.vaccValid || !isFinite(h) || !isFinite(v) || !isFinite(p) || !isFinite(s))
            return false

        if (h > settings.maxHorizontalAccuracy)
            return false
        if (v > settings.maxVerticalAccuracy)
            return false
        if (p > settings.maxPdop)
            return false
        if (s < settings.minSatellites)
            return false

        if (settings.rtkOnly &&
            String(info.qualityDescription).toLowerCase().indexOf("rtk") < 0)
            return false

        return true
    }

    function qualityReason(info) {
        if (!info || !positioning || !positioning.active)
            return "GNSS positioning is inactive"
        if (!hasValidPosition(info))
            return "No valid GNSS position"

        const h = Number(info.hacc)
        const v = Number(info.vacc)
        const p = Number(info.pdop)
        const s = Number(info.satellitesUsed)

        if (!info.haccValid || !info.vaccValid || !isFinite(h) || !isFinite(v) || !isFinite(p) || !isFinite(s))
            return "Waiting for GNSS quality data"
        if (h > settings.maxHorizontalAccuracy)
            return "Horizontal accuracy is above limit"
        if (v > settings.maxVerticalAccuracy)
            return "Vertical accuracy is above limit"
        if (p > settings.maxPdop)
            return "PDOP is above limit"
        if (s < settings.minSatellites)
            return "Too few satellites"
        if (settings.rtkOnly &&
            String(info.qualityDescription).toLowerCase().indexOf("rtk") < 0)
            return "RTK-only requirement not met"
        return "Quality requirements met"
    }


    property bool lineRecording: false
    property var lineVertices: []
    property real lineDistance: 0.0
    property var lastLinePosition: null
    property string currentLineName: ""
    property var currentLineLayer: null
    property bool qualityLockEnabled: false

    readonly property real lineVertexSpacingMeters: 1.524

    function lineId() {
        return settings.linePrefix + ("000000" + settings.lineCounter).slice(-6)
    }

    function distanceBetween(a, b) {
        if (!a || !b)
            return 0.0
        const dx = Number(a.x) - Number(b.x)
        const dy = Number(a.y) - Number(b.y)
        return Math.sqrt(dx * dx + dy * dy)
    }

    function lineInfoText() {
        if (!lineRecording)
            return "Line: not recording"
        return "Line: " + currentLineName +
               "\nVertices: " + lineVertices.length +
               "\nDistance: " + lineDistance.toFixed(2) + " m" +
               "\nVertex interval: 5 ft (1.524 m)"
    }

    function startLine() {
        ensureSurveyLayers()
        let layer = lineLayer
        if (!layer) {
            mainWindow.displayToast("Line layer is not available")
            return
        }
        if (layer.startEditing)
            layer.startEditing()

        const requestedName = lineNameField.text.trim()
        if (requestedName.length === 0) {
            mainWindow.displayToast("Enter a line name")
            return
        }

        const info = gnssInfo()
        if (!hasValidPosition(info)) {
            mainWindow.displayToast("No valid GNSS position")
            return
        }
        if (!qualityPasses(info)) {
            mainWindow.displayToast(qualityReason(info))
            return
        }

        const p = positioning.projectedPosition
        lineVertices = [ { x: Number(p.x), y: Number(p.y) } ]
        lastLinePosition = { x: Number(p.x), y: Number(p.y) }
        lineDistance = 0.0
        currentLineName = requestedName
        currentLineLayer = layer
        lineRecording = true

        mainWindow.displayToast("Line started")
    }

    function sampleLinePosition() {
        if (!lineRecording)
            return

        const info = gnssInfo()
        if (!hasValidPosition(info))
            return
        if (!qualityPasses(info))
            return

        const p = positioning.projectedPosition
        const current = { x: Number(p.x), y: Number(p.y) }
        const d = distanceBetween(lastLinePosition, current)

        // Vertices are distance-driven, not time-driven. The timer only
        // checks for movement; a vertex is committed only after 5 ft.
        if (d < lineVertexSpacingMeters)
            return

        // If a GNSS update jumps more than one interval, place vertices
        // at 5-ft increments along the traveled segment.
        const ux = (current.x - lastLinePosition.x) / d
        const uy = (current.y - lastLinePosition.y) / d
        let remaining = d
        let anchor = { x: lastLinePosition.x, y: lastLinePosition.y }

        while (remaining >= lineVertexSpacingMeters) {
            anchor = {
                x: anchor.x + ux * lineVertexSpacingMeters,
                y: anchor.y + uy * lineVertexSpacingMeters
            }
            lineVertices.push({ x: anchor.x, y: anchor.y })
            lineDistance += lineVertexSpacingMeters
            remaining -= lineVertexSpacingMeters
        }

        lastLinePosition = current
    }

    function safeLayerName(name, id) {
        let s = String(name).trim()
        if (s.length === 0)
            s = id
        s = s.replace(/[^A-Za-z0-9_-]+/g, "_")
        if (s.length > 50)
            s = s.substring(0, 50)
        return s + "_" + id
    }

    function finishLine() {
        if (!lineRecording)
            return

        if (lineVertices.length < 2) {
            lineRecording = false
            currentLineLayer = null
            mainWindow.displayToast("Move at least 5 ft before finishing")
            return
        }

        const layer = lineLayer
        if (!layer) {
            lineRecording = false
            currentLineLayer = null
            mainWindow.displayToast("Line layer is not available")
            return
        }
        if (layer.startEditing)
            layer.startEditing()

        const id = lineId()
        const coords = []
        for (let i = 0; i < lineVertices.length; i++)
            coords.push([lineVertices[i].x, lineVertices[i].y])

        const wktParts = []
        for (let i = 0; i < coords.length; i++)
            wktParts.push(coords[i][0] + " " + coords[i][1])
        const geometry = GeometryUtils.createGeometryFromWkt("LINESTRING(" + wktParts.join(",") + ")")
        const feature = FeatureUtils.createFeature(layer, geometry)
        setIfPresent(feature, layer, "name", currentLineName)
        setIfPresent(feature, layer, "id", id)
        setIfPresent(feature, layer, "feature_id", id)
        setIfPresent(feature, layer, "vertex_count", lineVertices.length)
        setIfPresent(feature, layer, "length_m", Number(lineDistance.toFixed(3)))

        const info = gnssInfo()
        if (info) {
            setIfPresent(feature, layer, "gnss_status", info.qualityDescription)
            setIfPresent(feature, layer, "h_accuracy", info.hacc)
            setIfPresent(feature, layer, "v_accuracy", info.vacc)
            setIfPresent(feature, layer, "pdop", info.pdop)
            setIfPresent(feature, layer, "satellites", info.satellitesUsed)
            setIfPresent(feature, layer, "gnss_source", info.sourceName)
        }

        if (!LayerUtils.addFeature(layer, feature)) {
            mainWindow.displayToast("Could not record line")
            return
        }

        try {
            layer.triggerRepaint()
            iface.mapCanvas().refresh()
        } catch (e) {}

        settings.lineCounter = settings.lineCounter + 1
        lineRecording = false
        lineVertices = []
        lastLinePosition = null
        lineDistance = 0.0
        currentLineName = ""
        currentLineLayer = layer
        mainWindow.displayToast("Line recorded: " + id)
    }

    Timer {
        id: gnssRefresh
        interval: 500
        repeat: true
        running: panel.visible
        onTriggered: {
            gnssStatusVersion = gnssStatusVersion + 1
        }
    }

    property int gnssStatusVersion: 0

    Timer {
        id: lineSampler
        interval: 250
        repeat: true
        running: lineRecording
        onTriggered: sampleLinePosition()
    }

    function collectPoint() {
        const requestedName = pointNameField.text.trim()
        if (requestedName.length === 0) {
            mainWindow.displayToast("Enter a point name")
            return
        }

        ensureSurveyLayers()
        const layer = pointLayer
        if (!layer) {
            mainWindow.displayToast("Point layer is not available")
            return
        }

        if (layer.startEditing)
            layer.startEditing()

        const info = gnssInfo()
        if (qualityLockEnabled && !qualityPasses(info)) {
            mainWindow.displayToast(qualityReason(info))
            return
        }

        if (!positioning) {
            mainWindow.displayToast("QField positioning is unavailable")
            return
        }

        const projectedPosition = positioning.projectedPosition
        if (!projectedPosition) {
            mainWindow.displayToast("QField has no projected GNSS position")
            return
        }

        const x = Number(projectedPosition.x)
        const y = Number(projectedPosition.y)
        if (!isFinite(x) || !isFinite(y)) {
            mainWindow.displayToast("QField GNSS position is not valid")
            return
        }

        const geometry = GeometryUtils.createGeometryFromWkt(
            "POINT(" + x + " " + y + ")"
        )
        const feature = FeatureUtils.createFeature(layer, geometry)
        const id = pointId()

        setIfPresent(feature, layer, "name", requestedName)
        setIfPresent(feature, layer, "id", id)
        setIfPresent(feature, layer, "feature_id", id)

        if (info) {
            const sat = Number(info.satellitesUsed)
            const satFallback = (isFinite(sat) && sat > 0)
                              ? sat
                              : (info.satellitesInView ? info.satellitesInView.length : 0)

            setIfPresent(feature, layer, "gnss_status",
                         info.qualityDescription ? info.qualityDescription : String(info.status))
            setIfPresent(feature, layer, "h_accuracy", info.hacc)
            setIfPresent(feature, layer, "v_accuracy", info.vacc)
            setIfPresent(feature, layer, "pdop", info.pdop)
            setIfPresent(feature, layer, "satellites", satFallback)
            setIfPresent(feature, layer, "gnss_source", info.sourceName)
            setIfPresent(feature, layer, "gnss_timestamp", info.utcDateTime)
            setIfPresent(feature, layer, "averaged_count", info.averagedCount)

            setIfPresent(feature, layer, "horizontal_accuracy", info.hacc)
            setIfPresent(feature, layer, "vertical_accuracy", info.vacc)
            setIfPresent(feature, layer, "gnss_pdop", info.pdop)
            setIfPresent(feature, layer, "gnss_satellites", satFallback)
            setIfPresent(feature, layer, "gnss_quality",
                         info.qualityDescription ? info.qualityDescription : String(info.status))
        }

        // Record directly into the editable survey layer.
        // Do NOT open the QField feature form: that was the source of the
        // disappearing popup and the apparent failure to save the point.
        let added = false
        try {
            added = LayerUtils.addFeature(layer, feature)
        } catch (e) {
            mainWindow.displayToast("Point save error: " + e)
            return
        }

        if (!added) {
            mainWindow.displayToast("QField could not add the point to the editable layer")
            return
        }

        try {
            layer.triggerRepaint()
            iface.mapCanvas().refresh()
        } catch (e) {}

        settings.pointCounter = settings.pointCounter + 1
        settings.lastPointName = requestedName
        pointNameField.text = ""

        const satDisplay = info
                         ? ((Number(info.satellitesUsed) > 0)
                            ? Number(info.satellitesUsed)
                            : (info.satellitesInView ? info.satellitesInView.length : 0))
                         : 0
        const pdopDisplay = info && isFinite(Number(info.pdop))
                         ? Number(info.pdop).toFixed(2)
                         : "unavailable"

        mainWindow.displayToast(
            "Point recorded: " + id +
            "\nSatellites: " + satDisplay +
            "  PDOP: " + pdopDisplay
        )
    }

    function collectPolygon() {
        const requestedName = polygonNameField.text.trim()
        if (requestedName.length === 0) {
            mainWindow.displayToast("Enter a polygon name")
            return
        }
        ensureSurveyLayers()
        const layer = polygonLayer
        if (!layer) {
            mainWindow.displayToast("Polygon layer is not available")
            return
        }
        if (layer.startEditing)
            layer.startEditing()

        const info = gnssInfo()
        const p = positioning.projectedPosition
        const x = Number(p.x), y = Number(p.y)
        if (!isFinite(x) || !isFinite(y)) {
            mainWindow.displayToast("No valid projected GNSS position")
            return
        }
        if (qualityLockEnabled && !qualityPasses(info)) {
            mainWindow.displayToast(qualityReason(info))
            return
        }
        const size = 2.0
        const wkt = "POLYGON((" +
            x + " " + y + "," +
            (x + size) + " " + y + "," +
            (x + size) + " " + (y + size) + "," +
            x + " " + (y + size) + "," +
            x + " " + y + "))"
        const geometry = GeometryUtils.createGeometryFromWkt(wkt)
        const feature = FeatureUtils.createFeature(layer, geometry)
        const id = "PG-" + ("000000" + settings.pointCounter).slice(-6)
        setIfPresent(feature, layer, "name", requestedName)
        setIfPresent(feature, layer, "id", id)
        setIfPresent(feature, layer, "feature_id", id)
        setIfPresent(feature, layer, "vertex_count", 5)
        setIfPresent(feature, layer, "area_m2", size * size)
        if (info) {
            setIfPresent(feature, layer, "gnss_status", info.qualityDescription)
            setIfPresent(feature, layer, "h_accuracy", info.hacc)
            setIfPresent(feature, layer, "v_accuracy", info.vacc)
            setIfPresent(feature, layer, "pdop", info.pdop)
            setIfPresent(feature, layer, "satellites", info.satellitesUsed)
            setIfPresent(feature, layer, "gnss_source", info.sourceName)
        }
        if (!LayerUtils.addFeature(layer, feature)) {
            mainWindow.displayToast("Could not record polygon")
            return
        }
        settings.pointCounter = settings.pointCounter + 1
        mainWindow.displayToast("Polygon recorded: " + id)
    }

    function statusText() {
        const info = gnssInfo()
        if (!info)
            return "GNSS: inactive"

        const h = Number(info.hacc)
        const v = Number(info.vacc)
        const p = Number(info.pdop)
        let s = Number(info.satellitesUsed)

        if ((!isFinite(s) || s <= 0) && info.satellitesInView)
            s = info.satellitesInView.length

        const fixText = info.fixStatusDescription
                      ? info.fixStatusDescription
                      : (info.qualityDescription
                         ? info.qualityDescription
                         : "unknown")

        return "GNSS: " + fixText +
               "\nSource: " + (info.sourceName ? info.sourceName : "unknown") +
               "\nH: " + (isFinite(h) ? h.toFixed(3) + " m" : "unavailable") +
               "   V: " + (isFinite(v) ? v.toFixed(3) + " m" : "unavailable") +
               "\nPDOP: " + ((isFinite(p) && p > 0) ? p.toFixed(2) : "unavailable") +
               "   Satellites: " + ((isFinite(s) && s > 0) ? s : "unavailable") +
               "\nQuality: " + qualityReason(info)
    }

    QfToolButton {
        id: pointButton
        objectName: "fieldSurveyProPointButton"
        bgcolor: Theme.darkGray
        iconSource: "icon.svg"
        iconColor: Theme.mainColor
        round: true
        onClicked: {
            panelMode = "point"
            panel.open()
        }
    }

    QfToolButton {
        id: lineButton
        objectName: "fieldSurveyProLineButton"
        bgcolor: Theme.darkGray
        iconSource: "icon.svg"
        iconColor: Theme.mainColor
        round: true
        onClicked: {
            panelMode = "line"
            panel.open()
        }
    }

    Dialog {
        id: panel
        title: panelMode === "point" ? "FieldSurvey Pro — Points" : "FieldSurvey Pro — Lines"
        modal: true
        parent: mainWindow.contentItem
        width: Math.min(mainWindow.width - 40, 440)
        x: (mainWindow.width - width) / 2
        y: (mainWindow.height - height) / 2

        Column {
            width: parent.width
            spacing: 10

            Label {
                width: parent.width
                text: "GNSS Point Collection"
                font.bold: true
                font.pixelSize: 20
            }

            Label {
                visible: panelMode === "point"
                width: parent.width
                text: "Next point ID: " + pointId()
            }

            Label {
                visible: panelMode === "point"
                width: parent.width
                text: "Point name"
                font.bold: true
            }

            TextField {
                visible: panelMode === "point"
                id: pointNameField
                width: parent.width
                text: settings.lastPointName.length > 0 ? "" : pointId()
                placeholderText: "Enter any name"
                selectByMouse: true
            }

            Label {
                visible: panelMode === "point"
                width: parent.width
                text: statusText()
                wrapMode: Text.WordWrap
            }

            Button {
                visible: panelMode === "point"
                width: parent.width
                text: "COLLECT POINT"
                enabled: true
                onClicked: {
                    mainWindow.displayToast("Recording point...")
                    collectPoint()
                }
            }

            CheckBox {
                visible: panelMode === "point"
                id: qualityLockBox
                text: qualityLockEnabled
                      ? "Require GNSS quality limits: ON"
                      : "Require GNSS quality limits: OFF"
                checked: qualityLockEnabled
                onClicked: {
                    qualityLockEnabled = checked
                    settings.qualityLock = checked
                }
            }

            CheckBox {
                visible: panelMode === "point"
                id: rtkBox
                text: "Require RTK"
                checked: settings.rtkOnly
                onClicked: settings.rtkOnly = checked
                enabled: qualityLockEnabled
            }

            Label {
                visible: panelMode === "point"
                width: parent.width
                text: "Limits: H ≤ " + settings.maxHorizontalAccuracy.toFixed(2) +
                      " m, V ≤ " + settings.maxVerticalAccuracy.toFixed(2) +
                      " m, PDOP ≤ " + settings.maxPdop.toFixed(1) +
                      ", satellites ≥ " + settings.minSatellites
                wrapMode: Text.WordWrap
                enabled: qualityLockEnabled
            }

            Label {
                visible: panelMode === "point"
                width: parent.width
                text: qualityLockEnabled
                      ? "QUALITY LOCK: ON — point collection is blocked until all limits pass."
                      : "QUALITY LOCK: OFF — point collection does not require accuracy, PDOP, or satellite limits."
                wrapMode: Text.WordWrap
                font.bold: true
            }

            Label {
                width: parent.width
                text: "Line Collection"
                font.bold: true
                font.pixelSize: 18
            }

            TextField {
                visible: panelMode === "line"
                id: lineNameField
                width: parent.width
                placeholderText: "Line name"
                text: ""
                enabled: !lineRecording
            }

            Label {
                visible: panelMode === "line"
                width: parent.width
                text: lineInfoText()
                wrapMode: Text.WordWrap
            }

            Button {
                visible: panelMode === "line"
                width: parent.width
                text: lineRecording ? "FINISH LINE" : "START LINE"
                enabled: true
                onClicked: {
                    if (lineRecording)
                        finishLine()
                    else
                        startLine()
                }
            }

            Label {
                visible: panelMode === "line"
                width: parent.width
                text: "Vertices are collected every 5 ft (1.524 m) of movement. The timer only checks the GNSS position; it does not determine vertex spacing."
                wrapMode: Text.WordWrap
            }

            Label {
                visible: panelMode === "line"
                width: parent.width
                text: "Polygon Collection"
                font.bold: true
                font.pixelSize: 18
            }

            TextField {
                visible: panelMode === "line"
                id: polygonNameField
                width: parent.width
                placeholderText: "Polygon name"
                text: ""
            }

            Button {
                visible: panelMode === "line"
                width: parent.width
                text: "COLLECT POLYGON"
                enabled: true
                onClicked: collectPolygon()
            }

            Button {
                visible: panelMode === "line"
                width: parent.width
                text: "Close"
                enabled: !lineRecording
                onClicked: panel.close()
            }
        }
    }

    function configure() {
        panel.open()
    }

    Component.onCompleted: {
        qualityLockEnabled = settings.qualityLock
        iface.addItemToPluginsToolbar(pointButton)
        iface.addItemToPluginsToolbar(lineButton)
        ensureSurveyLayers()
        mainWindow.displayToast("FieldSurvey Pro 0.13.2 loaded")
    }
}
