import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    objectName: "fieldSurveyPro"

    property var mainWindow: iface.mainWindow()
    property var positioning: iface.positioning()

    property var pointLayer: null
    property var lineLayer: null
    property var polygonLayer: null

    Settings {
        id: settings
        category: "FieldSurveyPro-v1"
        property int pointCounter: 1
        property string pointPrefix: "PT-"
    }

    function projectFilePath() {
        if (!qgisProject || !qgisProject.fileName)
            return ""
        let p = qgisProject.fileName.toString()
        if (p.indexOf("file://") === 0)
            p = decodeURIComponent(p.substring(7))
        return p
    }

    function projectFolder() {
        let p = projectFilePath()
        if (!p)
            return ""
        p = p.replace(/\\/g, "/")
        const i = p.lastIndexOf("/")
        return i >= 0 ? p.substring(0, i) : ""
    }

    function layerPath(baseName) {
        const folder = projectFolder()
        if (!folder)
            return ""
        return folder + "/" + baseName + ".gpkg"
    }

    function findLayer(name, geometryType) {
        const layers = qgisProject.mapLayersByName(name)
        if (!layers || layers.length === 0)
            return null
        for (let i = 0; i < layers.length; i++) {
            if (layers[i] && layers[i].geometryType === geometryType)
                return layers[i]
        }
        return null
    }

    function createPersistentLayer(name, geometryType, wktSeed) {
        const path = layerPath(name)
        if (!path)
            return null

        // Create a temporary memory layer only long enough to create the
        // permanent GeoPackage dataset in the project folder.
        const geojson = JSON.stringify({
            type: "FeatureCollection",
            features: [{
                type: "Feature",
                properties: {
                    name: "",
                    feature_id: ""
                },
                geometry: {
                    type: geometryType,
                    coordinates: geometryType === "Point"
                        ? [0, 0]
                        : geometryType === "LineString"
                            ? [[0, 0], [0.000001, 0.000001]]
                            : [[[0,0], [0.000001,0], [0,0.000001], [0,0]]]
                }
            }]
        })

        let memory = null
        try {
            memory = LayerUtils.memoryLayerFromJsonString(
                name, geojson, qgisProject.crs
            )
        } catch (e) {
            return null
        }

        if (!memory)
            return null

        let saved = ""
        try {
            saved = LayerUtils.saveVectorLayerAs(
                memory, path, "GPKG"
            )
        } catch (e) {
            return null
        }

        if (!saved)
            return null

        // Load the permanent on-disk layer into the project.
        let layer = null
        try {
            layer = LayerUtils.loadVectorLayer(
                path + "|layername=" + name,
                name,
                "ogr"
            )
        } catch (e) {
            return null
        }

        if (!layer)
            return null

        qgisProject.addMapLayer(layer)

        // Remove the seed feature. The layer is now an empty persistent
        // GeoPackage layer.
        try {
            const ids = []
            const it = LayerUtils.createFeatureIterator(layer)
            while (it.hasNext())
                ids.push(it.next().id())
            for (let i = 0; i < ids.length; i++)
                LayerUtils.deleteFeature(qgisProject, layer, ids[i], true)
        } catch (e) {}

        try {
            if (layer.startEditing)
                layer.startEditing()
            LayerUtils.setDefaultRenderer(layer, qgisProject)
        } catch (e) {}

        return layer
    }

    function ensureLayers() {
        if (!qgisProject || !qgisProject.fileName) {
            mainWindow.displayToast("Open and save a QGIS project first")
            return false
        }

        pointLayer = findLayer("FieldSurveyPro_Points", 0)
        lineLayer = findLayer("FieldSurveyPro_Lines", 1)
        polygonLayer = findLayer("FieldSurveyPro_Polygons", 2)

        if (!pointLayer)
            pointLayer = createPersistentLayer(
                "FieldSurveyPro_Points", "Point", "POINT(0 0)"
            )

        if (!lineLayer)
            lineLayer = createPersistentLayer(
                "FieldSurveyPro_Lines", "LineString",
                "LINESTRING(0 0,0.000001 0.000001)"
            )

        if (!polygonLayer)
            polygonLayer = createPersistentLayer(
                "FieldSurveyPro_Polygons", "Polygon",
                "POLYGON((0 0,0.000001 0,0 0.000001,0 0))"
            )

        if (pointLayer && pointLayer.startEditing)
            pointLayer.startEditing()
        if (lineLayer && lineLayer.startEditing)
            lineLayer.startEditing()
        if (polygonLayer && polygonLayer.startEditing)
            polygonLayer.startEditing()

        return !!pointLayer
    }

    function nextPointId() {
        return settings.pointPrefix +
               ("000000" + settings.pointCounter).slice(-6)
    }

    function collectPoint() {
        if (!ensureLayers())
            return

        if (!positioning || !positioning.projectedPosition) {
            mainWindow.displayToast("No GNSS position is available")
            return
        }

        const p = positioning.projectedPosition
        const x = Number(p.x)
        const y = Number(p.y)

        if (!isFinite(x) || !isFinite(y)) {
            mainWindow.displayToast("GNSS position is invalid")
            return
        }

        const name = pointNameField.text.trim()
        if (!name) {
            mainWindow.displayToast("Enter a point name")
            return
        }

        const geometry = GeometryUtils.createGeometryFromWkt(
            "POINT(" + x + " " + y + ")"
        )
        const feature = FeatureUtils.createFeature(pointLayer, geometry)
        const id = nextPointId()

        feature.setAttribute("name", name)
        feature.setAttribute("feature_id", id)

        if (!LayerUtils.addFeature(pointLayer, feature)) {
            mainWindow.displayToast("Could not save point")
            return
        }

        try {
            pointLayer.triggerRepaint()
            iface.mapCanvas().refresh()
        } catch (e) {}

        settings.pointCounter = settings.pointCounter + 1
        pointNameField.text = ""

        mainWindow.displayToast("Point " + id + " recorded")
    }

    QfToolButton {
        id: pointButton
        objectName: "fieldSurveyProPointButton"
        bgcolor: Theme.darkGray
        iconSource: "icon.svg"
        iconColor: Theme.mainColor
        round: true
        onClicked: pointDialog.open()
    }

    Dialog {
        id: pointDialog
        title: "FieldSurvey Pro — Collect Point"
        modal: true
        parent: mainWindow.contentItem
        width: Math.min(mainWindow.width - 40, 420)
        x: (mainWindow.width - width) / 2
        y: (mainWindow.height - height) / 2

        Column {
            width: parent.width
            spacing: 12

            Label {
                width: parent.width
                text: "Next point: " + nextPointId()
                font.bold: true
            }

            TextField {
                id: pointNameField
                width: parent.width
                placeholderText: "Point name"
                selectByMouse: true
                focus: true
            }

            Label {
                width: parent.width
                text: positioning && positioning.projectedPosition
                      ? "GNSS position available"
                      : "Waiting for GNSS position"
                wrapMode: Text.WordWrap
            }

            Button {
                width: parent.width
                text: "COLLECT POINT"
                enabled: true
                onClicked: collectPoint()
            }

            Button {
                width: parent.width
                text: "Close"
                onClicked: pointDialog.close()
            }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(pointButton)
        // Layer creation is deliberately delayed until the project is fully
        // available, rather than being performed during QML construction.
        Qt.callLater(function() {
            ensureLayers()
            mainWindow.displayToast("FieldSurvey Pro 1.0.0 ready")
        })
    }
}
