import QtQuick
import QtQuick.Controls
import QtCore
import org.qfield
import org.qgis
import Theme

Item {
  id: plugin
  objectName: "fieldSurveyPro"

  property var dashBoard: iface.findItemByObjectName("dashBoard")
  property var positioning: iface.positioning()
  property var mainWindow: iface.mainWindow()
  property var mapCanvas: iface.mapCanvas()
  property var overlayFeatureFormDrawer: iface.findItemByObjectName("overlayFeatureFormDrawer")

  property bool collecting: false
  property string collectionType: ""
  property var vertices: []
  property string currentId: ""

  Settings {
    id: settings
    category: "FieldSurveyPro"
    property int pointCounter: 1
    property int lineCounter: 1
    property int boundaryCounter: 1
    property string pointPrefix: "PT-"
    property string linePrefix: "LN-"
    property string boundaryPrefix: "BD-"
  }

  function nextId(prefix, counter) {
    return prefix + ("000000" + counter).slice(-6)
  }

  function gnssInfo() {
    if (!positioning || !positioning.active)
      return "GNSS: inactive"
    var p = positioning.positionInformation
    if (!p || !p.latitudeValid || !p.longitudeValid)
      return "GNSS: waiting for position"
    return "GNSS: " + Number(p.latitude).toFixed(7) + ", " +
           Number(p.longitude).toFixed(7)
  }

  function currentProjectPoint() {
    if (!positioning || !positioning.active)
      return null
    var p = positioning.projectedPosition
    if (!p)
      return null
    return p
  }

  function ensureLayer() {
    if (!dashBoard) {
      mainWindow.displayToast("QField dashboard is unavailable")
      return null
    }
    try {
      dashBoard.ensureEditableLayerSelected()
    } catch (e) {}
    var layer = dashBoard.activeLayer
    if (!layer) {
      mainWindow.displayToast("Select an editable layer first")
      return null
    }
    return layer
  }

  function setAttributeIfPresent(feature, name, value) {
    try {
      var idx = feature.fields().indexOf(name)
      if (idx >= 0)
        feature.setAttribute(name, value)
    } catch (e) {}
  }

  function openFeature(feature) {
    if (!overlayFeatureFormDrawer) {
      mainWindow.displayToast("QField feature form is unavailable")
      return
    }
    overlayFeatureFormDrawer.featureModel.feature = feature
    overlayFeatureFormDrawer.state = "Add"
    overlayFeatureFormDrawer.open()
  }

  function addPoint() {
    var layer = ensureLayer()
    if (!layer) return

    var p = currentProjectPoint()
    if (!p) {
      mainWindow.displayToast("No valid GNSS position")
      return
    }

    var geometry = GeometryUtils.createGeometryFromWkt(
      "POINT(" + p.x + " " + p.y + ")"
    )
    var feature = FeatureUtils.createFeature(layer, geometry)
    var id = nextId(settings.pointPrefix, settings.pointCounter)
    settings.pointCounter++

    setAttributeIfPresent(feature, "name", id)
    setAttributeIfPresent(feature, "id", id)
    setAttributeIfPresent(feature, "feature_id", id)
    setAttributeIfPresent(feature, "description", "FieldSurvey Pro point")
    openFeature(feature)
  }

  function beginCollection(type) {
    var layer = ensureLayer()
    if (!layer) return
    vertices = []
    collectionType = type
    collecting = true

    if (type === "line")
      currentId = nextId(settings.linePrefix, settings.lineCounter)
    else
      currentId = nextId(settings.boundaryPrefix, settings.boundaryCounter)

    mainWindow.displayToast(currentId + " started")
  }

  function addVertex() {
    if (!collecting) return
    var p = currentProjectPoint()
    if (!p) {
      mainWindow.displayToast("No valid GNSS position")
      return
    }
    vertices.push(Qt.point(p.x, p.y))
    mainWindow.displayToast("Vertex " + vertices.length + " added")
  }

  function undoVertex() {
    if (vertices.length > 0) {
      vertices.pop()
      mainWindow.displayToast("Vertex removed")
    }
  }

  function finishCollection() {
    if (!collecting) return
    if (vertices.length < 2) {
      mainWindow.displayToast("At least 2 vertices are required")
      return
    }

    var layer = ensureLayer()
    if (!layer) return

    var parts = []
    for (var i = 0; i < vertices.length; i++)
      parts.push(vertices[i].x + " " + vertices[i].y)

    var wkt
    if (collectionType === "line") {
      wkt = "LINESTRING(" + parts.join(",") + ")"
    } else {
      if (vertices.length < 3) {
        mainWindow.displayToast("A boundary needs at least 3 vertices")
        return
      }
      parts.push(vertices[0].x + " " + vertices[0].y)
      wkt = "POLYGON((" + parts.join(",") + "))"
    }

    var geometry = GeometryUtils.createGeometryFromWkt(wkt)
    var feature = FeatureUtils.createFeature(layer, geometry)

    setAttributeIfPresent(feature, "name", currentId)
    setAttributeIfPresent(feature, "id", currentId)
    setAttributeIfPresent(feature, "feature_id", currentId)
    setAttributeIfPresent(feature, "description",
                          collectionType === "line" ? "FieldSurvey Pro line" :
                                                       "FieldSurvey Pro boundary")

    if (collectionType === "line")
      settings.lineCounter++
    else
      settings.boundaryCounter++

    collecting = false
    vertices = []
    openFeature(feature)
  }

  function cancelCollection() {
    collecting = false
    vertices = []
    currentId = ""
    mainWindow.displayToast("Collection cancelled")
  }

  QfToolButton {
    id: surveyButton
    objectName: "fieldSurveyProButton"
    iconSource: Theme.getThemeVectorIcon("ic_geotag_white_24dp")
    iconColor: Theme.toolButtonColor
    bgcolor: Theme.toolButtonBackgroundColor
    round: true
    onClicked: panel.open()
  }

  Component.onCompleted: {
    iface.addItemToPluginsToolbar(surveyButton)
    mainWindow.displayToast("FieldSurvey Pro loaded")
  }

  QfDialog {
    id: panel
    parent: mainWindow.contentItem
    width: Math.min(mainWindow.width - 32, 440)
    height: Math.min(mainWindow.height - 48, 620)
    x: (mainWindow.width - width) / 2
    y: (mainWindow.height - height) / 2
    title: "FieldSurvey Pro"

    Column {
      width: parent.width
      spacing: 10

      Label {
        width: parent.width
        text: gnssInfo()
        wrapMode: Text.WordWrap
      }

      Label {
        width: parent.width
        text: collecting
              ? currentId + "  •  " + vertices.length + " vertices"
              : "Ready to collect"
        font.bold: true
      }

      Button {
        width: parent.width
        text: "POINT  " + nextId(settings.pointPrefix, settings.pointCounter)
        enabled: !collecting
        onClicked: {
          addPoint()
          panel.close()
        }
      }

      Button {
        width: parent.width
        text: collecting && collectionType === "line"
              ? "ADD LINE VERTEX"
              : "LINE  " + nextId(settings.linePrefix, settings.lineCounter)
        enabled: !collecting || collectionType === "line"
        onClicked: {
          if (!collecting) beginCollection("line")
          else addVertex()
        }
      }

      Button {
        width: parent.width
        text: collecting && collectionType === "boundary"
              ? "ADD BOUNDARY VERTEX"
              : "BOUNDARY  " + nextId(settings.boundaryPrefix, settings.boundaryCounter)
        enabled: !collecting || collectionType === "boundary"
        onClicked: {
          if (!collecting) beginCollection("boundary")
          else addVertex()
        }
      }

      Row {
        width: parent.width
        spacing: 8
        visible: collecting

        Button {
          width: (parent.width - 16) / 3
          text: "UNDO"
          onClicked: undoVertex()
        }
        Button {
          width: (parent.width - 16) / 3
          text: "FINISH"
          onClicked: finishCollection()
        }
        Button {
          width: (parent.width - 16) / 3
          text: "CANCEL"
          onClicked: cancelCollection()
        }
      }

      Label {
        width: parent.width
        wrapMode: Text.WordWrap
        text: "The active editable QField layer determines the geometry type. Use a point layer for POINT, a line layer for LINE, and a polygon layer for BOUNDARY."
      }

      Button {
        width: parent.width
        text: "CLOSE"
        onClicked: panel.close()
      }
    }
  }

  function configure() {
    panel.open()
  }
}
