# FieldSurvey Pro 0.7.0

QField app-wide plugin for survey collection.

## Features
- Visible FieldSurvey Pro toolbar button
- GNSS position display
- Point creation using the current GNSS/projected position
- Line collection by repeated GNSS vertices
- Boundary collection by repeated GNSS vertices
- Undo/cancel/finish controls
- Persistent unique IDs: PT-000001, LN-000001, BD-000001
- Uses QField's native feature form for saving/editing attributes

## Installation
Install the ZIP through QField:
Settings -> Plugins -> Install plugin from URL

Use a direct URL to the ZIP, not a GitHub `blob` page.

The plugin expects an editable layer selected in QField:
- POINT -> point layer
- LINE -> line layer
- BOUNDARY -> polygon layer

This build intentionally uses QField's documented FeatureUtils/GeometryUtils and feature-form workflow.
