import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
 id: plugin
 property var mainWindow: iface.mainWindow()
 property var lineLayer: null
 property bool logging: false
 property var vertices: []
 property var lastPoint: null
 property real totalDistance: 0
 property real intervalM: 1.524
 property real accuracy: -1
 property string lineName: ""

 Component.onCompleted: iface.addItemToPluginsToolbar(logButton)

 function d2r(v){return v*Math.PI/180}
 function r2d(v){return v*180/Math.PI}
 function hav(a,b,c,d){var R=6371008.8,p1=d2r(a),p2=d2r(c),dp=d2r(c-a),dl=d2r(d-b),x=Math.sin(dp/2)*Math.sin(dp/2)+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);return 2*R*Math.atan2(Math.sqrt(x),Math.sqrt(Math.max(0,1-x)))}
 function bear(a,b,c,d){var p1=d2r(a),p2=d2r(c),dl=d2r(d-b),y=Math.sin(dl)*Math.cos(p2),x=Math.cos(p1)*Math.sin(p2)-Math.sin(p1)*Math.cos(p2)*Math.cos(dl);return (r2d(Math.atan2(y,x))+360)%360}
 function dest(a,b,br,dist){var R=6371008.8,t=d2r(br),p=d2r(a),l=d2r(b),x=dist/R,p2=Math.asin(Math.sin(p)*Math.cos(x)+Math.cos(p)*Math.sin(x)*Math.cos(t)),l2=l+Math.atan2(Math.sin(t)*Math.sin(x)*Math.cos(p),Math.cos(x)-Math.sin(p)*Math.sin(p2));return {lat:r2d(p2),lon:((r2d(l2)+540)%360)-180}}
 function current(){
  var pos=iface.positioning(); if(!pos||!pos.valid)return null
  var p=pos.sourcePosition;if(!p)return null
  var a=Number(pos.positionInformation.hacc);accuracy=(isFinite(a)&&a>=0)?a:-1
  return {lat:Number(p.y),lon:Number(p.x)}
 }
 function add(p){vertices.push({lat:p.lat,lon:p.lon})}
 function sample(p){
  if(!lastPoint){add(p);lastPoint=p;return}
  var seg=hav(lastPoint.lat,lastPoint.lon,p.lat,p.lon); if(seg<intervalM)return
  var br=bear(lastPoint.lat,lastPoint.lon,p.lat,p.lon),from=lastPoint,rem=seg
  while(rem>=intervalM){var n=dest(from.lat,from.lon,br,intervalM);add(n);totalDistance+=intervalM;from=n;rem=hav(from.lat,from.lon,p.lat,p.lon)}
  lastPoint=from
 }
 function start(){
  var ls=qgisProject.mapLayersByName("FieldSurveyPro_Lines");if(!ls||ls.length===0){mainWindow.displayToast("FieldSurveyPro_Lines not found");return}
  lineLayer=ls[0];var p=current();if(!p){mainWindow.displayToast("Waiting for GNSS position");return}
  vertices=[];lastPoint=null;totalDistance=0;logging=true;sample(p);mainWindow.displayToast("DISTANCE LOGGER: STARTED")
 }
 function stop(){
  if(!logging)return
  logging=false
  if(!lineLayer||vertices.length<2){mainWindow.displayToast("Need at least 2 vertices");vertices=[];lastPoint=null;return}
  try{
   var w="LINESTRING("
   for(var i=0;i<vertices.length;i++){
    var p=vertices[i],q=QfGeometryUtils.reprojectPoint(QfGeometryUtils.point(p.lon,p.lat),CoordinateReferenceSystemUtils.wgs84Crs(),lineLayer.crs)
    if(i)w+=","
    w+=Number(q.x)+" "+Number(q.y)
   }
   w+=")"
   var f=FeatureUtils.createFeature(lineLayer,GeometryUtils.createGeometryFromWkt(w))
   var fieldNames=f.fields.names
   if(fieldNames.indexOf("name")>=0) f.setAttribute(fieldNames.indexOf("name"),lineName)
   if(LayerUtils.addFeature(lineLayer,f))mainWindow.displayToast("LINE SAVED: "+(lineName.length>0?lineName:"Unnamed")+" ("+vertices.length+" vertices)")
   else mainWindow.displayToast("LINE SAVE FAILED")
  }catch(e){mainWindow.displayToast("LINE SAVE ERROR: "+e)}
  vertices=[];lastPoint=null
 }
 Timer{interval:250;repeat:true;running:logging;onTriggered:{var p=current();if(p)sample(p)}}
 QfToolButton{
  id:logButton;width:56;height:56
  iconSource:Theme.getThemeVectorIcon("ic_timeline_white_24dp")
  iconColor:"white";bgcolor:logging?"#b00020":"#1976d2";round:true
  onClicked:{if(logging)stop();else panel.visible=true}
  Text{anchors.centerIn:parent;text:logging?"STOP":"LOG";color:"white";font.bold:true;font.pixelSize:10}
 }
 Rectangle{
  id:panel;parent:mainWindow.contentItem;visible:false
  anchors.top:parent.top;anchors.topMargin:80;anchors.horizontalCenter:parent.horizontalCenter
  width:330;height:300;radius:12;color:"#DD202020";border.color:"white";border.width:1;z:100000
  Text{x:15;y:12;text:"Continuous Topo";color:"white";font.bold:true;font.pixelSize:20}
  Text{x:15;y:48;text:"Line name";color:"#DDDDDD";font.pixelSize:14}
  TextField{
   id:nameField;x:15;y:70;width:300;height:42
   text:lineName;placeholderText:"Enter line name"
   color:"white";placeholderTextColor:"#BBBBBB"
   selectionColor:"#1976d2";selectedTextColor:"white"
   background:Rectangle{radius:6;color:"#3A3A3A";border.color:"#8A8A8A";border.width:1}
   onTextChanged:lineName=text
  }
  Text{x:15;y:120;text:"Vertex spacing";color:"#DDDDDD";font.pixelSize:14}
  ComboBox{
   id:spacing;x:15;y:142;width:180
   model:["1 ft (0.3048 m)","5 ft (1.524 m)","10 ft (3.048 m)","25 ft (7.620 m)","50 ft (15.240 m)","Custom"]
   currentIndex:1
   onCurrentIndexChanged:{if(currentIndex===0)intervalM=.3048;else if(currentIndex===1)intervalM=1.524;else if(currentIndex===2)intervalM=3.048;else if(currentIndex===3)intervalM=7.620;else if(currentIndex===4)intervalM=15.240}
  }
  TextField{id:custom;x:205;y:142;width:105;height:42;placeholderText:"meters";enabled:spacing.currentIndex===5;color:"white";placeholderTextColor:"#BBBBBB";background:Rectangle{radius:6;color:"#3A3A3A";border.color:"#8A8A8A";border.width:1};onTextChanged:{var v=Number(text);if(enabled&&isFinite(v)&&v>0)intervalM=v}}
  Text{x:15;y:190;text:"Distance: "+totalDistance.toFixed(1)+" m";color:"white";font.pixelSize:15}
  Text{x:15;y:213;text:"Vertices: "+vertices.length;color:"white";font.pixelSize:15}
  Text{x:15;y:236;text:"Accuracy: "+(accuracy>=0?accuracy.toFixed(2)+" m":"--");color:"#DDDDDD";font.pixelSize:13}
  Rectangle{x:15;y:265;width:140;height:30;radius:7;color:"#1976d2"
   Text{anchors.centerIn:parent;text:"START";color:"white";font.bold:true}
   MouseArea{anchors.fill:parent;onClicked:{panel.visible=false;start()}}
  }
  Rectangle{x:175;y:265;width:140;height:30;radius:7;color:"#444444"
   Text{anchors.centerIn:parent;text:"CANCEL";color:"white";font.bold:true}
   MouseArea{anchors.fill:parent;onClicked:panel.visible=false}
  }
 }
}