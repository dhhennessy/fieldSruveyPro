import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    property var mainWindow: iface.mainWindow()
    property var pointHandler: iface.findItemByObjectName("pointHandler")
    property bool picking: false
    property bool active: false
    property string targetName: ""
    property var targetLayer: null
    property var targetFeature: null
    property real arrowRotation: 0
    property real arrivalThreshold: 0.5

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(stakeoutButton)
    }

    function log(msg) {
        try { iface.logMessage("Stakeout: " + msg) } catch (e) {}
    }

    function beginPick() {
        if (!pointHandler) {
            mainWindow.displayToast("QField point handler unavailable")
            return
        }

        try { pointHandler.unregisterHandler("FieldSurveyProStakeout") } catch (e) {}

        picking = true
        active = false
        targetLayer = null
        targetFeature = null
        targetName = ""
        stakeoutPanel.visible = true
        statusText.text = "TAP A POINT"

        pointHandler.registerHandler("FieldSurveyProStakeout",
            function(point, type, interactionType) {
                if (!picking || interactionType !== "clicked")
                    return false

                var canvas = iface.mapCanvas()
                var p1 = canvas.mapSettings.screenToCoordinate(
                    Qt.point(point.x - 12, point.y - 12))
                var p2 = canvas.mapSettings.screenToCoordinate(
                    Qt.point(point.x + 12, point.y + 12))
                var projectRect

                try {
                    projectRect = GeometryUtils.createRectangleFromPoints(p1, p2)
                } catch (e1) {
                    log("Could not create tap rectangle: " + e1)
                    mainWindow.displayToast("Could not read map location")
                    return true
                }

                var layerIds = canvas.mapSettings.layers
                var found = false

                for (var i = 0; i < layerIds.length && !found; i++) {
                    var layer = qgisProject.mapLayer(layerIds[i])
                    if (!layer) continue

                    var layerRect = projectRect
                    try {
                        if (layer.crs && qgisProject.crs &&
                            layer.crs.authid !== qgisProject.crs.authid) {
                            try {
                                layerRect = QfGeometryUtils.reprojectRectangle(
                                    projectRect, qgisProject.crs, layer.crs)
                            } catch (e2) {
                                try {
                                    layerRect = GeometryUtils.reprojectRectangle(
                                        projectRect, qgisProject.crs, layer.crs)
                                } catch (e3) {
                                    log("CRS transform unavailable for " + layer.name)
                                    continue
                                }
                            }
                        }
                    } catch (e4) {}

                    try {
                        var it = LayerUtils.createFeatureIteratorFromRectangle(layer, layerRect)
                        while (it && it.hasNext()) {
                            var f = it.next()
                            if (!f || !f.isValid()) continue

                            var geom = null
                            try { geom = f.geometry() } catch (eg) {}
                            if (!geom || geom.isNull()) continue

                            // Only accept point features.
                            var gtype = -1
                            try { gtype = Number(geom.type()) } catch (egt) {}
                            if (gtype !== 0) continue

                            setTarget(layer, f)
                            found = true
                            break
                        }
                    } catch (e5) {
                        log("Layer search error on " + layer.name + ": " + e5)
                    }
                }

                if (!found) {
                    statusText.text = "NO POINT AT TAP"
                    mainWindow.displayToast("No point found at that location")
                }

                return true
            })
    }

    function setTarget(layer, feature) {
        targetLayer = layer
        targetFeature = feature
        targetName = getTargetName(feature)
        active = true
        picking = false

        // Visually select the feature in QField as confirmation that the
        // plugin registered the same point the operator tapped.
        try {
            LayerUtils.selectFeaturesInLayer(layer, [feature.id()])
        } catch (e) {
            log("Could not select target feature: " + e)
        }

        statusText.text = "TARGET SET"
        updateNavigationDisplay()
        mainWindow.displayToast("TARGET SET: " + targetName)
    }

    function clearStakeout() {
        try { pointHandler.unregisterHandler("FieldSurveyProStakeout") } catch (e) {}
        picking = false
        active = false
        targetLayer = null
        targetFeature = null
        targetName = ""
        statusText.text = "TAP A POINT"
        stakeoutPanel.visible = false
    }

    function getTargetName(feature) {
        try {
            var n = feature.attribute("name")
            if (n !== null && n !== undefined && String(n) !== "")
                return String(n)
        } catch (e) {}
        try {
            var n2 = feature.attribute("Name")
            if (n2 !== null && n2 !== undefined && String(n2) !== "")
                return String(n2)
        } catch (e2) {}
        try { return "Point " + feature.id() } catch (e3) {}
        return "Target"
    }

    function targetPointWgs84() {
        if (!targetFeature || !targetLayer) return null
        try {
            var pt = targetFeature.geometry().asPoint()
            try {
                return QfGeometryUtils.reprojectPoint(
                    pt, targetLayer.crs, CoordinateReferenceSystemUtils.wgs84Crs())
            } catch (e1) {
                return GeometryUtils.reprojectPoint(
                    pt, targetLayer.crs, CoordinateReferenceSystemUtils.wgs84Crs())
            }
        } catch (e) {
            log("Target WGS84 transform failed: " + e)
            return null
        }
    }

    function currentPositionWgs84() {
        try {
            var pos = iface.positioning()
            if (!pos || !pos.valid) return null
            var p = pos.projectedPosition
            try {
                return QfGeometryUtils.reprojectPoint(
                    p, qgisProject.crs, CoordinateReferenceSystemUtils.wgs84Crs())
            } catch (e1) {
                return GeometryUtils.reprojectPoint(
                    p, qgisProject.crs, CoordinateReferenceSystemUtils.wgs84Crs())
            }
        } catch (e) {
            return null
        }
    }

    function distanceMeters() {
        var a = currentPositionWgs84()
        var b = targetPointWgs84()
        if (!a || !b) return NaN

        var lat1 = Number(a.y()) * Math.PI / 180
        var lat2 = Number(b.y()) * Math.PI / 180
        var dLat = (Number(b.y()) - Number(a.y())) * Math.PI / 180
        var dLon = (Number(b.x()) - Number(a.x())) * Math.PI / 180
        var s = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(lat1) * Math.cos(lat2) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2)
        return 6371008.8 * 2 * Math.atan2(Math.sqrt(s), Math.sqrt(1 - s))
    }

    function targetBearingTrueNorth() {
        var a = currentPositionWgs84()
        var b = targetPointWgs84()
        if (!a || !b) return NaN

        var lat1 = Number(a.y()) * Math.PI / 180
        var lat2 = Number(b.y()) * Math.PI / 180
        var dLon = (Number(b.x()) - Number(a.x())) * Math.PI / 180
        var y = Math.sin(dLon) * Math.cos(lat2)
        var x = Math.cos(lat1) * Math.sin(lat2) -
                Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon)
        var brng = Math.atan2(y, x) * 180 / Math.PI
        if (brng < 0) brng += 360
        return brng
    }

    function distanceText() {
        var d = distanceMeters()
        if (!isFinite(d)) return "--"
        if (d < 1000) return d.toFixed(d < 10 ? 2 : 1) + " m"
        return (d / 1000).toFixed(3) + " km"
    }

    function accuracyText() {
        try {
            var pi = iface.positioning().positionInformation
            if (pi && pi.haccValid) return Number(pi.hacc).toFixed(2) + " m"
        } catch (e) {}
        return "--"
    }

    function fixText() {
        try {
            var pi = iface.positioning().positionInformation
            if (pi && pi.fixStatusDescription) return String(pi.fixStatusDescription)
        } catch (e) {}
        return "--"
    }

    function updateNavigationDisplay() {
        arrowRotation = walkingArrowRotation()
    }

    function walkingArrowRotation() {
        var targetBearing = targetBearingTrueNorth()
        if (!isFinite(targetBearing)) return 0

        try {
            var pi = iface.positioning().positionInformation
            if (pi && pi.directionValid && pi.speedValid && Number(pi.speed) > 0.15) {
                var travel = Number(pi.direction)
                var r = targetBearing - travel
                while (r > 180) r -= 360
                while (r < -180) r += 360
                return r
            }
        } catch (e) {}
        return 0
    }

    QfToolButton {
        id: stakeoutButton
        bgcolor: "#b71c1c"
        iconSource: "stakeout.svg"
        iconColor: "white"
        round: true
        width: 56
        height: 56

        onClicked: {
            if (active || picking) clearStakeout()
            else beginPick()
        }

        Text {
            anchors.centerIn: parent
            text: "STAKE"
            color: "white"
            font.bold: true
            font.pixelSize: 10
        }
    }

    Timer {
        interval: 250
        running: active
        repeat: true
        onTriggered: updateNavigationDisplay()
    }

    Rectangle {
        id: stakeoutPanel
        parent: mainWindow.contentItem
        visible: false
        z: 10000
        width: Math.min(mainWindow.width * 0.90, 430)
        height: 330
        x: (mainWindow.width - width) / 2
        y: 75
        radius: 14
        color: "#202124"
        border.color: "#777777"
        border.width: 1

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 16
            spacing: 7

            Label {
                id: statusText
                Layout.fillWidth: true
                text: "TAP A POINT"
                color: "#7CFC00"
                font.pixelSize: 20
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
            }

            Label {
                Layout.fillWidth: true
                text: targetName === "" ? "No target selected" : targetName
                color: "#dddddd"
                font.pixelSize: 17
                horizontalAlignment: Text.AlignHCenter
                elide: Text.ElideMiddle
            }

            Rectangle {
                Layout.fillWidth: true
                height: 150
                radius: 10
                color: "#111111"

                RowLayout {
                    anchors.fill: parent
                    anchors.margins: 8

                    Label {
                        Layout.fillWidth: true
                        text: distanceText()
                        color: "white"
                        font.pixelSize: 38
                        font.bold: true
                        horizontalAlignment: Text.AlignHCenter
                    }

                    Label {
                        Layout.preferredWidth: 100
                        text: "↑"
                        color: "#7CFC00"
                        font.pixelSize: 76
                        font.bold: true
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                        rotation: arrowRotation
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true
                Label {
                    Layout.fillWidth: true
                    text: "GNSS ± " + accuracyText()
                    color: "#cccccc"
                    font.pixelSize: 14
                }
                Label {
                    Layout.fillWidth: true
                    text: "Fix: " + fixText()
                    color: "#cccccc"
                    font.pixelSize: 14
                    horizontalAlignment: Text.AlignRight
                }
            }

            Label {
                Layout.fillWidth: true
                text: active && isFinite(distanceMeters()) && distanceMeters() <= arrivalThreshold
                      ? "✓ ARRIVED — within " + arrivalThreshold.toFixed(1) + " m" : ""
                color: "#7CFC00"
                font.pixelSize: 15
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 8
                Button { Layout.fillWidth: true; text: "Pick Another"; onClicked: beginPick() }
                Button { Layout.fillWidth: true; text: "Clear"; onClicked: clearStakeout() }
                Button { Layout.fillWidth: true; text: "Close"; onClicked: stakeoutPanel.visible = false }
            }
        }
    }
}
