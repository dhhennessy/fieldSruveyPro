import QtQuick
import org.qfield.org

Item {
    id: plugin

    Component.onCompleted: {
        iface.mainWindow().displayToast("Stakeout plugin loaded")
    }
}
