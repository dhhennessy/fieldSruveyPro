import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    property var mainWindow: iface.mainWindow()
    property var pointHandler: null
    property bool picking: false
    property var targetLayer: null
    property var targetFeature: null
    property bool targetActive: false
    property real distanceM: -1
    property real targetBearing: 0
    property real travelBearing: 0
    property real horizontalAccuracy: -1
    property string targetName: ""
    property var targetMapPoint: null

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(stakeButton)
    }

    function deg2rad(v) { return v * Math.PI / 180.0 }
    function rad2deg(v) { return v * 180.0 / Math.PI }
    function normalizeBearing(v) { v = v % 360; if (v < 0) v += 360; return v }

    function haversine(lat1, lon1, lat2, lon2) {
        var R = 6371008.8
        var p1 = deg2rad(lat1), p2 = deg2rad(lat2)
        var dp = deg2rad(lat2-lat1), dl = deg2rad(lon2-lon1)
        var a = Math.sin(dp/2)*Math.sin(dp/2) + Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2)
        return 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(Math.max(0,1-a)))
    }

    function bearingBetween(lat1, lon1, lat2, lon2) {
        var p1 = deg2rad(lat1), p2 = deg2rad(lat2), dl = deg2rad(lon2-lon1)
        var y = Math.sin(dl) * Math.cos(p2)
        var x = Math.cos(p1)*Math.sin(p2) - Math.sin(p1)*Math.cos(p2)*Math.cos(dl)
        return normalizeBearing(rad2deg(Math.atan2(y,x)))
    }

    function currentLatLon() {
        var pos = iface.positioning()
        if (!pos || !pos.valid)
            return null
        var p = pos.sourcePosition
        return { lat: p.y(), lon: p.x() }
    }

    function targetLatLon() {
        if (!targetMapPoint) return null
        try {
            var wgs = QfGeometryUtils.reprojectPoint(
                targetMapPoint,
                qgisProject.crs,
                CoordinateReferenceSystemUtils.wgs84Crs()
            )
            return { lat: Number(wgs.y()), lon: Number(wgs.x()) }
        } catch (e) {
            mainWindow.displayToast("TARGET POSITION ERROR: " + e)
            return null
        }
    }

    function updateNavigation() {
        if (!targetActive) return
        var here = currentLatLon()
        var there = targetLatLon()
        if (!here || !there) return

        distanceM = haversine(here.lat, here.lon, there.lat, there.lon)
        targetBearing = bearingBetween(here.lat, here.lon, there.lat, there.lon)

        var posInfo = iface.positioning().positionInformation
        horizontalAccuracy = Number(posInfo.horizontalAccuracy)
        if (!isFinite(horizontalAccuracy)) horizontalAccuracy = Number(iface.positioning().projectedHorizontalAccuracy)

        // Prefer GNSS course when moving; otherwise use QField device orientation.
        var dir = Number(posInfo.direction)
        if (isFinite(dir) && Number(posInfo.speed) > 0.5) {
            travelBearing = normalizeBearing(dir)
        } else {
            var orient = Number(iface.positioning().orientation)
            if (isFinite(orient) && orient >= 0) travelBearing = normalizeBearing(orient)
        }
        navArrow.rotation = normalizeBearing(targetBearing - travelBearing)
    }

    function selectNearestFeature(mapPoint) {
        var layers = qgisProject.mapLayersByName("FieldSurveyPro_Points")
        if (!layers || layers.length === 0) {
            mainWindow.displayToast("LAYER NOT FOUND")
            return false
        }

        var layer = layers[0]
        targetLayer = layer

        // Use QField's documented rectangle iterator. This avoids accessing
        // QgsGeometry on the returned feature, which is not reliable in the
        // legacy QField 4.3.2 QML bridge.
        var ms = iface.mapCanvas().mapSettings
        var tl = ms.screenToCoordinate(Qt.point(mapPoint.x - 12, mapPoint.y - 12))
        var br = ms.screenToCoordinate(Qt.point(mapPoint.x + 12, mapPoint.y + 12))
        var rectangle = GeometryUtils.createRectangleFromPoints(tl, br)

        var it = LayerUtils.createFeatureIteratorFromRectangle(layer, rectangle)
        if (!it || !it.hasNext()) {
            mainWindow.displayToast("NO POINT AT TAP")
            return false
        }

        var feature = it.next()
        if (!feature) {
            mainWindow.displayToast("NO POINT FEATURE")
            return false
        }

        targetFeature = feature

        // The tap coordinate is the target coordinate. Because the tap is
        // made directly on the rendered point, this avoids the broken
        // geometry bridge entirely and gives a stable stakeout target.
        targetMapPoint = mapPoint
        targetName = ""
        try { targetName = String(feature.attribute("name")) } catch (e2) {}
        if (!targetName || targetName === "undefined" || targetName === "null")
            targetName = "Point " + String(feature.id)

        targetActive = true
        picking = false
        updateNavigation()
        mainWindow.displayToast("TARGET: " + targetName)
        return true
    }

    function startPicking() {
        pointHandler = iface.findItemByObjectName("pointHandler")
        if (!pointHandler) {
            mainWindow.displayToast("STAKEOUT: pointHandler NOT FOUND")
            return
        }
        try { pointHandler.deregisterHandler("FieldSurveyProStakeout294") } catch (e) {}
        picking = true
        targetActive = false
        mainWindow.displayToast("STAKEOUT: TAP A POINT")
        pointHandler.registerHandler("FieldSurveyProStakeout294", function(point, type, interactionType) {
            if (!picking || interactionType !== "clicked") return false
            try {
                var ms = iface.mapCanvas().mapSettings
                var mapPoint = ms.screenToCoordinate(Qt.point(point.x, point.y))
                return selectNearestFeature(mapPoint)
            } catch (e) {
                mainWindow.displayToast("TAP ERROR: " + e)
                return true
            }
        }, 100)
    }

    function clearTarget() {
        targetActive = false
        targetFeature = null
        targetLayer = null
        targetMapPoint = null
        targetName = ""
        distanceM = -1
        mainWindow.displayToast("STAKEOUT: TARGET CLEARED")
    }

    Timer {
        interval: 250
        repeat: true
        running: targetActive
        onTriggered: updateNavigation()
    }

    QfToolButton {
        id: stakeButton
        width: 56
        height: 56
        iconSource: Theme.getThemeVectorIcon("ic_navigation_white_24dp")
        iconColor: Theme.toolButtonColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true
        onClicked: startPicking()
        Text { anchors.centerIn: parent; text: "STAKE"; color: "white"; font.bold: true; font.pixelSize: 10 }
    }

    Rectangle {
        id: panel
        visible: targetActive
        anchors.top: parent.top
        anchors.horizontalCenter: parent.horizontalCenter
        width: 310
        height: 210
        radius: 12
        color: "#DD202020"
        border.color: "white"
        border.width: 1
        z: 1000

        Text { x: 15; y: 10; text: targetName; color: "white"; font.bold: true; font.pixelSize: 18; width: 280; elide: Text.ElideRight }
        Text { x: 15; y: 42; text: distanceM >= 0 ? (distanceM < 1000 ? distanceM.toFixed(2) + " m" : (distanceM/1000).toFixed(3) + " km") : "--"; color: "white"; font.bold: true; font.pixelSize: 30 }

        Item {
            x: 218; y: 35; width: 70; height: 70
            Text { anchors.centerIn: parent; text: "▲"; color: "white"; font.pixelSize: 62; rotation: navArrow.rotation }
            id: navArrow
        }

        Text { x: 15; y: 86; text: "Target bearing: " + (targetBearing || 0).toFixed(1) + "°"; color: "#DDDDDD"; font.pixelSize: 13 }
        Text { x: 15; y: 108; text: "Accuracy: " + (isFinite(horizontalAccuracy) && horizontalAccuracy >= 0 ? horizontalAccuracy.toFixed(2) + " m" : "--"); color: "#DDDDDD"; font.pixelSize: 13 }

        Rectangle {
            x: 15; y: 140; width: 130; height: 45; radius: 8; color: "#444444"
            Text { anchors.centerIn: parent; text: "NEW TARGET"; color: "white"; font.bold: true; font.pixelSize: 12 }
            MouseArea { anchors.fill: parent; onClicked: startPicking() }
        }
        Rectangle {
            x: 165; y: 140; width: 130; height: 45; radius: 8; color: "#444444"
            Text { anchors.centerIn: parent; text: "CLEAR"; color: "white"; font.bold: true; font.pixelSize: 12 }
            MouseArea { anchors.fill: parent; onClicked: clearTarget() }
        }
    }
}
