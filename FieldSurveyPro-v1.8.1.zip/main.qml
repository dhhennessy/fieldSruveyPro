import QtQuick 2.12
import QtQuick.Controls 2.12
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin

    property var selectedLayer: null
    property string selectedLayerName: ""

    QfToolButton {
        id: exportButton
        objectName: "fieldSurveyProExportButton"
        bgcolor: Theme.darkGray
        iconSource: Qt.resolvedUrl("export.svg")
        iconColor: "white"
        round: true
        onClicked: exportDialog.open()
    }

    Dialog {
        id: exportDialog
        parent: iface.mainWindow().contentItem
        modal: true
        title: "Select Vector Layer"
        width: Math.min(iface.mainWindow().width - 40, 560)
        height: Math.min(iface.mainWindow().height - 80, 540)
        x: (iface.mainWindow().width - width) / 2
        y: (iface.mainWindow().height - height) / 2

        function populateLayers() {
            layersModel.clear()
            plugin.selectedLayer = null
            plugin.selectedLayerName = ""

            try {
                // This is the layer-list method that worked in the
                // previous build: use the actual layers rendered by QField.
                var layers = iface.mapCanvas().mapSettings.layers

                for (var i = 0; i < layers.length; ++i) {
                    var layer = layers[i]
                    if (!layer)
                        continue

                    // Do NOT call geometryType() here. That was the reason
                    // the previous legacy build produced an empty list.
                    // QgsMapLayer objects expose their type to QML.
                    var isVector = false
                    try {
                        isVector = (layer.type === 0)
                    } catch (e) {}

                    if (isVector) {
                        layersModel.append({
                            "layerName": layer.name,
                            "layerId": layer.id
                        })
                    }
                }

                if (layersModel.count === 0) {
                    iface.mainWindow().displayToast(
                        "No vector layers found in the map"
                    )
                }
            } catch (e) {
                iface.mainWindow().displayToast(
                    "Could not read map layers: " + e
                )
            }
        }

        onOpened: populateLayers()

        contentItem: Column {
            spacing: 10
            padding: 16

            Label {
                text: "Select the vector layer to export:"
                font.bold: true
            }

            ListView {
                id: layerList
                width: exportDialog.width - 32
                height: 300
                clip: true
                model: ListModel { id: layersModel }

                delegate: ItemDelegate {
                    width: layerList.width
                    text: model.layerName
                    highlighted: plugin.selectedLayerName === model.layerName

                    onClicked: {
                        // Retrieve the real QgsMapLayer object from the
                        // project using the layer ID.
                        try {
                            plugin.selectedLayer =
                                qgisProject.mapLayer(model.layerId)
                        } catch (e) {
                            plugin.selectedLayer = null
                        }

                        plugin.selectedLayerName = model.layerName
                    }
                }
            }

            Label {
                text: plugin.selectedLayer
                    ? "Selected: " + plugin.selectedLayerName
                    : "No layer selected"
                wrapMode: Text.WordWrap
            }

            Row {
                spacing: 10

                Button {
                    text: "Export Shapefile"
                    enabled: plugin.selectedLayer !== null
                    onClicked: {
                        // For this compatibility build, first verify that
                        // layer selection works. The actual export call is
                        // deliberately isolated so a missing old API cannot
                        // prevent the selector from functioning.
                        try {
                            var p = qgisProject.absolutePath() +
                                    "/" +
                                    plugin.selectedLayerName.replace(
                                        /[^A-Za-z0-9_-]/g, "_"
                                    ) +
                                    "_FieldSurveyPro.shp"

                            var result =
                                QfLayerUtils.saveVectorLayerAs(
                                    plugin.selectedLayer,
                                    p,
                                    "ESRI Shapefile"
                                )

                            if (result && result.length > 0) {
                                exportDialog.close()
                                iface.mainWindow().displayToast(
                                    "Shapefile exported"
                                )
                            } else {
                                iface.mainWindow().displayToast(
                                    "Export returned no output"
                                )
                            }
                        } catch (e) {
                            iface.mainWindow().displayToast(
                                "Export API error: " + e
                            )
                        }
                    }
                }

                Button {
                    text: "Refresh"
                    onClicked: exportDialog.populateLayers()
                }

                Button {
                    text: "Cancel"
                    onClicked: exportDialog.close()
                }
            }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(exportButton)
    }
}
