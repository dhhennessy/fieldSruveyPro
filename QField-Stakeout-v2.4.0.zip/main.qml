import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    property var mainWindow: iface.mainWindow()
    property var pointHandler: null
    property bool picking: false

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(stakeButton)
    }

    function startPicking() {
        pointHandler = iface.findItemByObjectName("pointHandler")

        if (!pointHandler) {
            mainWindow.displayToast("STAKEOUT: point handler unavailable")
            return
        }

        try {
            pointHandler.deregisterHandler("FieldSurveyProStakeoutTest")
        } catch (e) {}

        picking = true
        mainWindow.displayToast("STAKEOUT: TAP A POINT")

        pointHandler.registerHandler(
            "FieldSurveyProStakeoutTest",
            function(point, type, interactionType) {
                if (!picking)
                    return false

                if (interactionType !== "clicked")
                    return false

                var canvas = iface.mapCanvas()
                var tl = canvas.mapSettings.screenToCoordinate(
                    Qt.point(point.x - 12, point.y - 12))
                var br = canvas.mapSettings.screenToCoordinate(
                    Qt.point(point.x + 12, point.y + 12))
                var rectangle = GeometryUtils.createRectangleFromPoints(tl, br)

                var layers = canvas.mapSettings.layers

                for (var i = 0; i < layers.length; i++) {
                    var layer = qgisProject.mapLayer(layers[i])
                    if (!layer)
                        continue

                    var it = null

                    try {
                        it = LayerUtils.createFeatureIteratorFromRectangle(
                            layer, rectangle)
                    } catch (e) {
                        continue
                    }

                    if (!it)
                        continue

                    if (it.hasNext()) {
                        var feature = it.next()

                        var name = ""
                        try {
                            name = String(feature.attribute("name"))
                        } catch (e2) {}

                        if (name === "" || name === "undefined" || name === "null") {
                            try {
                                name = "Feature " + feature.id()
                            } catch (e3) {
                                name = "Point found"
                            }
                        }

                        picking = false
                        mainWindow.displayToast("TARGET FOUND: " + name)
                        return true
                    }
                }

                mainWindow.displayToast("NO POINT FOUND")
                return true
            },
            100
        )
    }

    QfToolButton {
        id: stakeButton
        width: 56
        height: 56
        iconSource: Theme.getThemeVectorIcon("ic_navigation_white_24dp")
        iconColor: Theme.toolButtonColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true

        onClicked: startPicking()

        Text {
            anchors.centerIn: parent
            text: "STAKE"
            color: "white"
            font.bold: true
            font.pixelSize: 10
        }
    }
}
