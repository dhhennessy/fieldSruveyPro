import QtQuick
import org.qfield.org
import org.qfield.gui

Item {
    id: plugin
    objectName: "FieldSurveyProStakeout"

    property var mainWindow: iface.mainWindow()
    property var mapCanvas: iface.mapCanvas()
    property var pointHandler: null
    property bool picking: false
    property var targetLayer: null
    property var targetFeature: null
    property string targetName: ""

    Component.onCompleted: {
        // Use exactly the QField-documented plugin pattern.
        iface.addItemToPluginsToolbar(stakeButton)
    }

    function startPicking() {
        pointHandler = iface.findItemByObjectName("pointHandler")
        if (!pointHandler) {
            mainWindow.displayToast("Stakeout: point handler unavailable")
            return
        }

        try {
            pointHandler.deregisterHandler("FieldSurveyProStakeout432")
        } catch (e) {}

        picking = true
        mainWindow.displayToast("STAKEOUT: tap a point")

        // Numeric priority avoids relying on enum exposure across QField builds.
        pointHandler.registerHandler(
            "FieldSurveyProStakeout432",
            function(point, type, interactionType) {
                if (!picking || interactionType !== "clicked")
                    return false

                var canvas = iface.mapCanvas()
                var tl = canvas.mapSettings.screenToCoordinate(
                    Qt.point(point.x - 12, point.y - 12))
                var br = canvas.mapSettings.screenToCoordinate(
                    Qt.point(point.x + 12, point.y + 12))
                var rectangle = GeometryUtils.createRectangleFromPoints(tl, br)

                var layerIds = canvas.mapSettings.layers
                var foundLayer = null
                var foundFeature = null

                for (var i = 0; i < layerIds.length && !foundFeature; i++) {
                    var layer = qgisProject.mapLayer(layerIds[i])
                    if (!layer)
                        continue

                    var iterator = null
                    try {
                        iterator = LayerUtils.createFeatureIteratorFromRectangle(
                            layer, rectangle)
                    } catch (e1) {
                        continue
                    }

                    if (!iterator)
                        continue

                    while (iterator.hasNext()) {
                        var feature = iterator.next()
                        if (!feature || !feature.isValid())
                            continue

                        try {
                            if (feature.geometry().isNull())
                                continue
                            if (!feature.geometry().asPoint())
                                continue
                        } catch (e2) {
                            continue
                        }

                        foundLayer = layer
                        foundFeature = feature
                        break
                    }
                }

                if (!foundFeature) {
                    mainWindow.displayToast("No point found at tap")
                    return true
                }

                targetLayer = foundLayer
                targetFeature = foundFeature
                targetName = featureName(foundFeature)
                picking = false

                try {
                    foundLayer.selectByIds([foundFeature.id()])
                } catch (e3) {}

                showTarget()
                return true
            },
            100
        )

        return true
    }

    function featureName(feature) {
        var fields = ["name", "Name", "label", "Label", "id", "ID"]
        for (var i = 0; i < fields.length; i++) {
            try {
                var value = feature.attribute(fields[i])
                if (value !== null && value !== undefined && String(value) !== "")
                    return String(value)
            } catch (e) {}
        }
        try { return "Point " + feature.id() } catch (e2) {}
        return "Point"
    }

    function showTarget() {
        targetPanel.visible = true
        targetLabel.text = targetName
        mainWindow.displayToast("TARGET SET: " + targetName)
    }

    function clearTarget() {
        targetLayer = null
        targetFeature = null
        targetName = ""
        targetPanel.visible = false
        startPicking()
    }

    QfToolButton {
        id: stakeButton
        width: 56
        height: 56
        iconSource: Theme.getThemeVectorIcon("ic_navigation_white_24dp")
        iconColor: Theme.toolButtonColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true

        onClicked: startPicking()

        Text {
            anchors.centerIn: parent
            text: "STAKE"
            color: "white"
            font.bold: true
            font.pixelSize: 10
        }
    }

    Rectangle {
        id: targetPanel
        visible: false
        parent: mainWindow
        z: 10000
        width: 300
        height: 150
        x: (mainWindow.width - width) / 2
        y: 70
        radius: 12
        color: "#202124"
        border.width: 1
        border.color: "#888888"

        Column {
            anchors.centerIn: parent
            spacing: 10

            Text {
                text: "TARGET SET"
                color: "#7CFC00"
                font.bold: true
                font.pixelSize: 20
                width: 260
                horizontalAlignment: Text.AlignHCenter
            }

            Text {
                id: targetLabel
                text: ""
                color: "white"
                font.pixelSize: 18
                width: 260
                horizontalAlignment: Text.AlignHCenter
                elide: Text.ElideMiddle
            }

            Row {
                spacing: 10
                anchors.horizontalCenter: parent.horizontalCenter

                Rectangle {
                    width: 110
                    height: 34
                    radius: 6
                    color: "#444444"

                    Text {
                        anchors.centerIn: parent
                        text: "Pick Again"
                        color: "white"
                    }

                    MouseArea {
                        anchors.fill: parent
                        onClicked: clearTarget()
                    }
                }

                Rectangle {
                    width: 80
                    height: 34
                    radius: 6
                    color: "#444444"

                    Text {
                        anchors.centerIn: parent
                        text: "Close"
                        color: "white"
                    }

                    MouseArea {
                        anchors.fill: parent
                        onClicked: targetPanel.visible = false
                    }
                }
            }
        }
    }
}
