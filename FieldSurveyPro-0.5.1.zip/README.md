# FieldSurvey Pro 0.5.1

This is a QField app-wide plugin compatibility build.

## Important
QField app-wide plugins are installed through:
Settings -> Plugins -> Install plugin from URL

The URL must point directly to the ZIP archive. A ZIP copied into the QField plugins directory is not the URL-install workflow.

For manual installation, extract the ZIP so that:
QField/plugins/FieldSurveyPro/main.qml
exists directly.

The Android app directory can be verified in:
About QField -> App directories

This build uses the QField modules shown in the official plugin snippets and is intended to confirm plugin loading before enabling more advanced feature-editing APIs.
