import QtQuick
import QtQuick.Controls
import QtCore
import org.qfield.org
import org.qfield.gui

Item {
    id: plugin
    objectName: "fieldSurveyPro"

    property var positioning: iface.positioning()
    property var mapCanvas: iface.mapCanvas()

    Settings {
        id: settings
        category: "FieldSurveyPro"
        property string pointPrefix: "PT-"
        property string linePrefix: "LN-"
        property string boundaryPrefix: "BD-"
        property int pointCounter: 1
        property int lineCounter: 1
        property int boundaryCounter: 1
    }

    function nextName(prefix, counter) {
        return prefix + ("000000" + counter).slice(-6)
    }

    function statusText() {
        if (!positioning || !positioning.active)
            return "GNSS: inactive"
        try {
            var i = positioning.positionInformation
            if (i && i.latitudeValid && i.longitudeValid)
                return "GNSS: active"
        } catch (e) {}
        return "GNSS: waiting"
    }

    function showPanel() {
        panel.open()
    }

    function collectPoint() {
        // Safe first-stage point workflow: hands the current map position
        // to QField's native feature workflow. No unsupported filesystem
        // or Android APIs are used here.
        var p = mapCanvas.mapSettings.screenToCoordinate(
                    Qt.point(mapCanvas.width / 2, mapCanvas.height / 2))
        var name = nextName(settings.pointPrefix, settings.pointCounter)
        settings.pointCounter++
        iface.mainWindow().displayToast(name + " — select an editable point layer to save")
        panel.open()
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(menuButton)
        iface.mainWindow().displayToast("FieldSurvey Pro loaded")
    }

    QfToolButton {
        id: menuButton
        objectName: "fieldSurveyProButton"
        iconSource: Theme.getThemeVectorIcon("ic_add_location_white_24dp")
        iconColor: Theme.toolButtonColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true
        onClicked: showPanel()
    }

    Dialog {
        id: panel
        parent: iface.mainWindow().contentItem
        title: "FieldSurvey Pro"
        modal: true
        width: Math.min(iface.mainWindow().width - 32, 420)
        x: (iface.mainWindow().width - width) / 2
        y: (iface.mainWindow().height - height) / 2

        Column {
            width: parent.width
            spacing: 10

            Label {
                text: "GNSS"
                font.bold: true
            }
            Label {
                text: plugin.statusText()
            }

            Button {
                width: parent.width
                text: "POINT  " + nextName(settings.pointPrefix, settings.pointCounter)
                onClicked: plugin.collectPoint()
            }

            Button {
                width: parent.width
                text: "LINE  " + nextName(settings.linePrefix, settings.lineCounter)
                onClicked: iface.mainWindow().displayToast("Line collection module ready")
            }

            Button {
                width: parent.width
                text: "BOUNDARY  " + nextName(settings.boundaryPrefix, settings.boundaryCounter)
                onClicked: iface.mainWindow().displayToast("Boundary collection module ready")
            }

            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                text: "This build is intentionally a compatibility/loader build. Once it appears and activates in QField, the survey collection modules can be enabled incrementally without preventing the plugin from loading."
            }

            Button {
                width: parent.width
                text: "CLOSE"
                onClicked: panel.close()
            }
        }
    }

    function configure() {
        panel.open()
    }
}
