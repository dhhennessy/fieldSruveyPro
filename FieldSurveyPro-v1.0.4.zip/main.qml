import QtQuick
import QtQuick.Controls
import QtCore
import org.qfield
import org.qgis
import Theme

Item {
  id: plugin
  objectName: "fieldSurveyPro"

  property var mainWindow: iface.mainWindow()
  property var pointLayer: null
  property string pointGpkgPath: ""

  function projectFolder() {
    if (!qgisProject || !qgisProject.fileName)
      return ""

    var p = qgisProject.fileName.toString()
    if (p.indexOf("file://") === 0)
      p = decodeURIComponent(p.substring(7))

    p = p.replace(/\\/g, "/")
    var n = p.lastIndexOf("/")
    return n >= 0 ? p.substring(0, n) : ""
  }

  function setupPointLayer() {
    if (pointLayer)
      return true

    if (!qgisProject || !qgisProject.fileName) {
      mainWindow.displayToast("Save the QField project first")
      return false
    }

    var existing = qgisProject.mapLayersByName("FieldSurveyPro_Points")
    if (existing && existing.length > 0) {
      pointLayer = existing[0]
      try { pointLayer.startEditing() } catch (e) {}
      mainWindow.displayToast("FieldSurveyPro_Points ready")
      return true
    }

    var folder = projectFolder()
    if (!folder) {
      mainWindow.displayToast("Could not determine project folder")
      return false
    }

    var path = folder + "/FieldSurveyPro_Points.gpkg"

    // One seed feature is required so the GeoJSON layer has a known
    // point geometry and the fields are created by the OGR export.
    var geojson = JSON.stringify({
      type: "FeatureCollection",
      features: [{
        type: "Feature",
        properties: {
          name: "",
          feature_id: ""
        },
        geometry: {
          type: "Point",
          coordinates: [0, 0]
        }
      }]
    })

    var memory = null
    try {
      memory = LayerUtils.memoryLayerFromJsonString(
        "FieldSurveyPro_Points",
        geojson,
        qgisProject.crs
      )
    } catch (e) {
      mainWindow.displayToast("Point layer creation failed")
      return false
    }

    if (!memory) {
      mainWindow.displayToast("Point layer creation failed")
      return false
    }

    var saved = ""
    try {
      saved = LayerUtils.saveVectorLayerAs(memory, path, "GPKG")
    } catch (e) {
      mainWindow.displayToast("GeoPackage creation failed")
      return false
    }

    if (!saved) {
      mainWindow.displayToast("GeoPackage was not created")
      return false
    }

    var diskLayer = null
    try {
      diskLayer = LayerUtils.loadVectorLayer(
        saved + "|layername=FieldSurveyPro_Points",
        "FieldSurveyPro_Points",
        "ogr"
      )
    } catch (e) {
      diskLayer = null
    }

    if (!diskLayer) {
      mainWindow.displayToast("Saved point layer could not be loaded")
      return false
    }

    try {
      qgisProject.addMapLayer(diskLayer)
    } catch (e) {
      mainWindow.displayToast("Could not add point layer to project")
      return false
    }

    pointLayer = diskLayer
    pointGpkgPath = saved

    try {
      LayerUtils.setDefaultRenderer(pointLayer, qgisProject)
    } catch (e) {}

    // Remove the seed feature; the layer itself remains on disk.
    try {
      var it = LayerUtils.createFeatureIterator(pointLayer)
      if (it.hasNext()) {
        var f = it.next()
        LayerUtils.deleteFeature(qgisProject, pointLayer, f.id(), true)
      }
    } catch (e) {}

    try {
      pointLayer.startEditing()
    } catch (e) {}

    try {
      pointLayer.triggerRepaint()
      iface.mapCanvas().refresh()
    } catch (e) {}

    mainWindow.displayToast("Editable point layer created")
    return true
  }

  Component.onCompleted: {
    mainWindow.displayToast("FieldSurvey Pro loaded")

    // Create the persistent editable point layer as soon as a saved
    // project is available.
    setupPointLayer()
  }
}
