import QtQuick
import QtQuick.Controls
import org.qfield.org
import org.qfield.gui
import org.qgis
import Theme

Item {
    id: plugin
    objectName: "fieldSurveyPro"

    property var mainWindow: iface.mainWindow()
    property var positioning: iface.positioning()
    property var pointLayer: null
    property string pointGpkgPath: ""

    function projectFolder() {
        if (!qgisProject || !qgisProject.fileName)
            return ""
        let p = qgisProject.fileName.toString()
        if (p.indexOf("file://") === 0)
            p = decodeURIComponent(p.substring(7))
        p = p.replace(/\\/g, "/")
        const n = p.lastIndexOf("/")
        return n >= 0 ? p.substring(0, n) : ""
    }

    function setupPointLayer() {
        if (pointLayer)
            return true

        if (!qgisProject || !qgisProject.fileName) {
            mainWindow.displayToast("Save the QField project first")
            return false
        }

        const existing = qgisProject.mapLayersByName("FieldSurveyPro_Points")
        if (existing && existing.length > 0) {
            pointLayer = existing[0]
            if (pointLayer.startEditing)
                pointLayer.startEditing()
            return true
        }

        const folder = projectFolder()
        if (!folder) {
            mainWindow.displayToast("Could not determine project folder")
            return false
        }

        const path = folder + "/FieldSurveyPro_Points.gpkg"
        const geojson = JSON.stringify({
            type: "FeatureCollection",
            features: [{
                type: "Feature",
                properties: {
                    name: "",
                    feature_id: ""
                },
                geometry: {
                    type: "Point",
                    coordinates: [0, 0]
                }
            }]
        })

        let memory
        try {
            memory = LayerUtils.memoryLayerFromJsonString(
                "FieldSurveyPro_Points", geojson, qgisProject.crs
            )
        } catch (e) {
            mainWindow.displayToast("Could not create point layer")
            return false
        }

        if (!memory) {
            mainWindow.displayToast("Could not create point layer")
            return false
        }

        let saved
        try {
            saved = LayerUtils.saveVectorLayerAs(memory, path, "GPKG")
        } catch (e) {
            mainWindow.displayToast("Could not create GeoPackage")
            return false
        }

        if (!saved) {
            mainWindow.displayToast("Could not save point layer")
            return false
        }

        let diskLayer
        try {
            diskLayer = LayerUtils.loadVectorLayer(
                saved + "|layername=FieldSurveyPro_Points",
                "FieldSurveyPro_Points",
                "ogr"
            )
        } catch (e) {
            diskLayer = null
        }

        if (!diskLayer) {
            mainWindow.displayToast("Could not load saved point layer")
            return false
        }

        qgisProject.addMapLayer(diskLayer)
        pointLayer = diskLayer

        try {
            LayerUtils.setDefaultRenderer(pointLayer, qgisProject)
        } catch (e) {}

        // Remove the temporary seed feature.
        try {
            const it = LayerUtils.createFeatureIterator(pointLayer)
            if (it.hasNext()) {
                const f = it.next()
                LayerUtils.deleteFeature(qgisProject, pointLayer, f.id(), true)
            }
        } catch (e) {}

        try {
            pointLayer.startEditing()
        } catch (e) {}

        pointGpkgPath = saved
        mainWindow.displayToast("Point layer created in project folder")
        return true
    }

    function collectPoint() {
        if (!setupPointLayer())
            return

        if (!positioning || !positioning.projectedPosition) {
            mainWindow.displayToast("No GNSS position available")
            return
        }

        const p = positioning.projectedPosition
        const x = Number(p.x)
        const y = Number(p.y)

        if (!isFinite(x) || !isFinite(y)) {
            mainWindow.displayToast("Invalid GNSS position")
            return
        }

        const name = pointName.text.trim()
        if (!name) {
            mainWindow.displayToast("Enter a point name")
            return
        }

        const geometry = QfGeometryUtils.createGeometryFromWkt(
            "POINT(" + x + " " + y + ")"
        )
        const feature = QfFeatureUtils.createFeature(pointLayer, geometry)

        feature.setAttribute("name", name)
        feature.setAttribute("feature_id", "PT-" + Date.now())

        if (!QfLayerUtils.addFeature(pointLayer, feature)) {
            mainWindow.displayToast("Point could not be saved")
            return
        }

        try {
            pointLayer.triggerRepaint()
            iface.mapCanvas().refresh()
        } catch (e) {}

        pointName.text = ""
        mainWindow.displayToast("Point recorded")
    }

    QfToolButton {
        id: pointButton
        objectName: "fieldSurveyProPointButton"
        bgcolor: Theme.toolButtonBackgroundColor
        iconSource: Theme.getThemeVectorIcon("ic_add_location_white_24dp")
        iconColor: Theme.toolButtonColor
        round: true
        onClicked: pointDialog.open()
    }

    Dialog {
        id: pointDialog
        title: "FieldSurvey Pro — Points"
        modal: true
        parent: mainWindow.contentItem
        width: Math.min(mainWindow.width - 40, 420)
        x: (mainWindow.width - width) / 2
        y: (mainWindow.height - height) / 2

        Column {
            width: parent.width
            spacing: 12

            Label {
                width: parent.width
                text: "Collect a GNSS point"
                font.bold: true
            }

            TextField {
                id: pointName
                width: parent.width
                placeholderText: "Point name"
            }

            Button {
                width: parent.width
                text: "COLLECT POINT"
                onClicked: collectPoint()
            }

            Button {
                width: parent.width
                text: "Close"
                onClicked: pointDialog.close()
            }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(pointButton)
        mainWindow.displayToast("FieldSurvey Pro 1.0.1 loaded")
    }
}
