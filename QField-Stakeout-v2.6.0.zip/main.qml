import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    property var mainWindow: iface.mainWindow()
    property var pointHandler: null
    property bool picking: false
    property var targetLayer: null
    property var targetFeature: null
    property string targetName: ""

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(stakeButton)
        pointHandler = iface.findItemByObjectName("pointHandler")
        if (pointHandler) {
            try {
                pointHandler.deregisterHandler("FieldSurveyProStakeoutNative")
            } catch (e) {}
            pointHandler.registerHandler(
                "FieldSurveyProStakeoutNative",
                function(point, type, interactionType) {
                    if (!picking || interactionType !== "clicked")
                        return false

                    // IMPORTANT: do not consume the tap.
                    // Let QField perform its normal feature selection.
                    checkSelectionTimer.restart()
                    return false
                },
                -100
            )
        }
    }

    Timer {
        id: checkSelectionTimer
        interval: 300
        repeat: false
        onTriggered: findNativeSelection()
    }

    function findNativeSelection() {
        var layers = iface.mapCanvas().mapSettings.layers

        for (var i = 0; i < layers.length; i++) {
            var layer = qgisProject.mapLayer(layers[i])
            if (!layer)
                continue

            var ids = null

            try {
                ids = layer.selectedFeatureIds()
            } catch (e) {
                continue
            }

            if (!ids || ids.length === 0)
                continue

            var id = ids[ids.length - 1]
            var feature = null

            try {
                feature = layer.getFeature(id)
            } catch (e2) {
                continue
            }

            if (!feature || !feature.isValid())
                continue

            try {
                if (feature.geometry().isNull())
                    continue
                if (!feature.geometry().asPoint())
                    continue
            } catch (e3) {
                continue
            }

            targetLayer = layer
            targetFeature = feature
            targetName = featureName(feature)
            picking = false

            mainWindow.displayToast("TARGET FOUND: " + targetName)
            return
        }

        mainWindow.displayToast("NO POINT SELECTED")
    }

    function featureName(feature) {
        var fields = ["name", "Name", "label", "Label", "id", "ID"]

        for (var i = 0; i < fields.length; i++) {
            try {
                var value = feature.attribute(fields[i])
                if (value !== null &&
                    value !== undefined &&
                    String(value) !== "" &&
                    String(value) !== "null" &&
                    String(value) !== "undefined")
                    return String(value)
            } catch (e) {}
        }

        try {
            return "Feature " + feature.id()
        } catch (e2) {
            return "Point"
        }
    }

    function startPicking() {
        targetLayer = null
        targetFeature = null
        targetName = ""
        picking = true
        mainWindow.displayToast("STAKEOUT: tap a point")
    }

    QfToolButton {
        id: stakeButton
        width: 56
        height: 56
        iconSource: Theme.getThemeVectorIcon("ic_navigation_white_24dp")
        iconColor: Theme.toolButtonColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true

        onClicked: startPicking()

        Text {
            anchors.centerIn: parent
            text: "STAKE"
            color: "white"
            font.bold: true
            font.pixelSize: 10
        }
    }
}
