import QtQuick
import QtQuick.Controls
import QtCore
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    objectName: "fieldSurveyPro"

    property var dashBoard: iface.findItemByObjectName("dashBoard")
    property var overlayFeatureFormDrawer: iface.findItemByObjectName("overlayFeatureFormDrawer")
    property var positioning: iface.positioning()
    property var mainWindow: iface.mainWindow()

    Settings {
        id: settings
        category: "FieldSurveyPro"
        property int pointCounter: 1
        property string pointPrefix: "PT-"
        property string lastPointName: ""
        property int lineCounter: 1
        property string linePrefix: "LN-"
        property bool qualityLock: false
        property real maxHorizontalAccuracy: 0.10
        property real maxVerticalAccuracy: 0.20
        property real maxPdop: 3.0
        property int minSatellites: 8
        property bool rtkOnly: false
    }

    function pointId() {
        return settings.pointPrefix + ("000000" + settings.pointCounter).slice(-6)
    }

    function fieldIndex(layer, fieldName) {
        if (!layer || !layer.fields)
            return -1
        return layer.fields.indexOf(fieldName)
    }

    function setIfPresent(feature, layer, fieldName, value) {
        if (fieldIndex(layer, fieldName) >= 0)
            feature.setAttribute(fieldName, value)
    }

    function gnssInfo() {
        if (!positioning || !positioning.active)
            return null
        return positioning.positionInformation
    }

    function satelliteValue(info) {
        if (!info)
            return NaN
        let n = Number(info.satellitesUsed)
        if (isFinite(n))
            return n
        n = Number(info.numberOfUsedSatellites)
        return isFinite(n) ? n : NaN
    }

    function pdopValue(info) {
        if (!info)
            return NaN
        const n = Number(info.pdop)
        return isFinite(n) ? n : NaN
    }

    function hasValidPosition(info) {
        return info &&
               info.longitudeValid &&
               info.latitudeValid
    }

    function qualityPasses(info) {
        if (!qualityLockEnabled)
            return hasValidPosition(info)

        if (!hasValidPosition(info))
            return false

        const h = Number(info.hacc)
        const v = Number(info.vacc)
        const p = pdopValue(info)
        const s = satelliteValue(info)

        if (!info.haccValid || !info.vaccValid || !isFinite(h) || !isFinite(v) || !isFinite(p) || !isFinite(s))
            return false

        if (h > settings.maxHorizontalAccuracy)
            return false
        if (v > settings.maxVerticalAccuracy)
            return false
        if (p > settings.maxPdop)
            return false
        if (s < settings.minSatellites)
            return false

        if (settings.rtkOnly &&
            String(info.qualityDescription).toLowerCase().indexOf("rtk") < 0)
            return false

        return true
    }

    function qualityReason(info) {
        if (!info || !positioning || !positioning.active)
            return "GNSS positioning is inactive"
        if (!hasValidPosition(info))
            return "No valid GNSS position"

        const h = Number(info.hacc)
        const v = Number(info.vacc)
        const p = pdopValue(info)
        const s = satelliteValue(info)

        if (!info.haccValid || !info.vaccValid || !isFinite(h) || !isFinite(v) || !isFinite(p) || !isFinite(s))
            return "Waiting for GNSS quality data"
        if (h > settings.maxHorizontalAccuracy)
            return "Horizontal accuracy is above limit"
        if (v > settings.maxVerticalAccuracy)
            return "Vertical accuracy is above limit"
        if (p > settings.maxPdop)
            return "PDOP is above limit"
        if (s < settings.minSatellites)
            return "Too few satellites"
        if (settings.rtkOnly &&
            String(info.qualityDescription).toLowerCase().indexOf("rtk") < 0)
            return "RTK-only requirement not met"
        return "Quality requirements met"
    }


    property bool lineRecording: false
    property var lineVertices: []
    property real lineDistance: 0.0
    property var lastLinePosition: null
    property string currentLineName: ""
    property var currentLineLayer: null
    property bool qualityLockEnabled: false

    readonly property real lineVertexSpacingMeters: 1.524

    function lineId() {
        return settings.linePrefix + ("000000" + settings.lineCounter).slice(-6)
    }

    function distanceBetween(a, b) {
        if (!a || !b)
            return 0.0
        const dx = Number(a.x) - Number(b.x)
        const dy = Number(a.y) - Number(b.y)
        return Math.sqrt(dx * dx + dy * dy)
    }

    function lineInfoText() {
        if (!lineRecording)
            return "Line: not recording"
        return "Line: " + currentLineName +
               "\nVertices: " + lineVertices.length +
               "\nDistance: " + lineDistance.toFixed(2) + " m" +
               "\nVertex interval: 5 ft (1.524 m)"
    }

    function startLine() {
        dashBoard.ensureEditableLayerSelected()

        let layer = dashBoard.activeLayer

        // If a line layer is not already active, use the first editable
        // line layer in the project. This avoids forcing the user to change
        // the active layer merely to start a survey line.
        if (!layer || layer.geometryType !== 1) {
            layer = null
            const layers = iface.mapCanvas().layers()
            for (let i = 0; i < layers.length; i++) {
                const candidate = layers[i]
                if (candidate && candidate.geometryType === 1 &&
                    candidate.isEditable && candidate.isEditable()) {
                    layer = candidate
                    break
                }
            }
        }

        if (!layer) {
            mainWindow.displayToast("No editable line layer is available")
            return
        }

        const requestedName = lineNameField.text.trim()
        if (requestedName.length === 0) {
            mainWindow.displayToast("Enter a line name")
            return
        }

        const info = gnssInfo()
        if (!hasValidPosition(info)) {
            mainWindow.displayToast("No valid GNSS position")
            return
        }
        if (!qualityPasses(info)) {
            mainWindow.displayToast(qualityReason(info))
            return
        }

        const p = positioning.projectedPosition
        lineVertices = [ { x: Number(p.x), y: Number(p.y) } ]
        lastLinePosition = { x: Number(p.x), y: Number(p.y) }
        lineDistance = 0.0
        currentLineName = requestedName
        currentLineLayer = layer
        lineRecording = true

        mainWindow.displayToast("Line started")
    }

    function sampleLinePosition() {
        if (!lineRecording)
            return

        const info = gnssInfo()
        if (!hasValidPosition(info))
            return
        if (!qualityPasses(info))
            return

        const p = positioning.projectedPosition
        const current = { x: Number(p.x), y: Number(p.y) }
        const d = distanceBetween(lastLinePosition, current)

        // Vertices are distance-driven, not time-driven. The timer only
        // checks for movement; a vertex is committed only after 5 ft.
        if (d < lineVertexSpacingMeters)
            return

        // If a GNSS update jumps more than one interval, place vertices
        // at 5-ft increments along the traveled segment.
        const ux = (current.x - lastLinePosition.x) / d
        const uy = (current.y - lastLinePosition.y) / d
        let remaining = d
        let anchor = { x: lastLinePosition.x, y: lastLinePosition.y }

        while (remaining >= lineVertexSpacingMeters) {
            anchor = {
                x: anchor.x + ux * lineVertexSpacingMeters,
                y: anchor.y + uy * lineVertexSpacingMeters
            }
            lineVertices.push({ x: anchor.x, y: anchor.y })
            lineDistance += lineVertexSpacingMeters
            remaining -= lineVertexSpacingMeters
        }

        lastLinePosition = current
    }

    function safeLayerName(name, id) {
        let s = String(name).trim()
        if (s.length === 0)
            s = id
        s = s.replace(/[^A-Za-z0-9_-]+/g, "_")
        if (s.length > 50)
            s = s.substring(0, 50)
        return s + "_" + id
    }

    function finishLine() {
        if (!lineRecording)
            return

        if (lineVertices.length < 2) {
            lineRecording = false
            currentLineLayer = null
            mainWindow.displayToast("Move at least 5 ft before finishing")
            return
        }

        const id = lineId()
        const layerName = safeLayerName(currentLineName, id)

        const coords = []
        for (let i = 0; i < lineVertices.length; i++)
            coords.push([lineVertices[i].x, lineVertices[i].y])

        // Create a brand-new editable line layer for this line. GeoJSON
        // memory-layer creation gives the layer its attribute schema without
        // requiring a pre-existing project layer.
        const properties = {
            name: currentLineName,
            id: id,
            feature_id: id,
            vertex_count: lineVertices.length,
            length_m: Number(lineDistance.toFixed(3))
        }

        const info = gnssInfo()
        if (info) {
            properties.gnss_status = info.qualityDescription
            properties.h_accuracy = info.hacc
            properties.v_accuracy = info.vacc
            properties.pdop = info.pdop
            properties.satellites = info.satellitesUsed
            properties.gnss_source = info.sourceName
        }

        const geojson = JSON.stringify({
            type: "FeatureCollection",
            features: [{
                type: "Feature",
                properties: properties,
                geometry: {
                    type: "LineString",
                    coordinates: coords
                }
            }]
        })

        let newLayer = null
        try {
            newLayer = LayerUtils.memoryLayerFromJsonString(
                layerName,
                geojson,
                qgisProject.crs
            )
        } catch (e) {
            mainWindow.displayToast("Could not create line layer")
            lineRecording = false
            lineVertices = []
            lastLinePosition = null
            currentLineLayer = null
            return
        }

        if (!newLayer) {
            mainWindow.displayToast("Could not create line layer")
            lineRecording = false
            lineVertices = []
            lastLinePosition = null
            currentLineLayer = null
            return
        }

        // Add the new layer to the current QField project.
        qgisProject.addMapLayer(newLayer)

        // Ensure the newly created memory layer is editable.
        if (newLayer.startEditing)
            newLayer.startEditing()

        settings.lineCounter = settings.lineCounter + 1

        lineRecording = false
        lineVertices = []
        lastLinePosition = null
        lineDistance = 0.0
        currentLineName = ""
        currentLineLayer = newLayer

        mainWindow.displayToast("Created line layer: " + layerName)
    }

    Timer {
        id: gnssRefresh
        interval: 500
        repeat: true
        running: panel.visible
        onTriggered: {
            gnssStatusVersion = gnssStatusVersion + 1
        }
    }

    property int gnssStatusVersion: 0

    Timer {
        id: lineSampler
        interval: 250
        repeat: true
        running: lineRecording
        onTriggered: sampleLinePosition()
    }

    function collectPoint() {
        const requestedName = pointNameField.text.trim()
        if (requestedName.length === 0) {
            mainWindow.displayToast("Enter a point name")
            return
        }

        dashBoard.ensureEditableLayerSelected()

        if (!dashBoard.activeLayer) {
            mainWindow.displayToast("Select an editable point layer first")
            return
        }

        const layer = dashBoard.activeLayer
        const info = gnssInfo()
        const projectedPosition = positioning.projectedPosition

        // Quality lock OFF: do not require hacc/vacc/PDOP/satellites.
        // The only requirement is that QField can provide a finite projected
        // coordinate for the current position.
        const x = Number(projectedPosition.x)
        const y = Number(projectedPosition.y)

        if (!isFinite(x) || !isFinite(y)) {
            mainWindow.displayToast("No valid projected GNSS position")
            return
        }

        if (qualityLockEnabled && !qualityPasses(info)) {
            mainWindow.displayToast(qualityReason(info))
            return
        }

        const wkt = "POINT(" + x + " " + y + ")"
        const geometry = GeometryUtils.createGeometryFromWkt(wkt)
        const feature = FeatureUtils.createFeature(layer, geometry)
        const id = pointId()

        setIfPresent(feature, layer, "name", requestedName)
        setIfPresent(feature, layer, "id", id)
        setIfPresent(feature, layer, "feature_id", id)

        if (info) {
            setIfPresent(feature, layer, "gnss_status", info.qualityDescription)
            setIfPresent(feature, layer, "h_accuracy", info.hacc)
            setIfPresent(feature, layer, "v_accuracy", info.vacc)
            setIfPresent(feature, layer, "pdop", info.pdop)
            setIfPresent(feature, layer, "satellites", info.satellitesUsed)
            setIfPresent(feature, layer, "gnss_source", info.sourceName)
            setIfPresent(feature, layer, "gnss_timestamp", info.utcDateTime)
            setIfPresent(feature, layer, "averaged_count", info.averagedCount)

            setIfPresent(feature, layer, "horizontal_accuracy", info.hacc)
            setIfPresent(feature, layer, "vertical_accuracy", info.vacc)
            setIfPresent(feature, layer, "gnss_pdop", info.pdop)
            setIfPresent(feature, layer, "gnss_satellites", info.satellitesUsed)
            setIfPresent(feature, layer, "gnss_quality", info.qualityDescription)
        }

        settings.pointCounter = settings.pointCounter + 1
        settings.lastPointName = requestedName

        overlayFeatureFormDrawer.featureModel.feature = feature
        overlayFeatureFormDrawer.state = "Add"
        overlayFeatureFormDrawer.open()
    }

    function statusText() {
        const info = gnssInfo()
        if (!info)
            return "GNSS: inactive"

        if (!hasValidPosition(info))
            return "GNSS: no valid fix"

        const h = Number(info.hacc)
        const v = Number(info.vacc)
        const p = pdopValue(info)
        let s = Number(info.satellitesUsed)
        if (isFinite(s) && s === 0 && info.satellitesInView &&
            info.satellitesInView.length > 0)
            s = info.satellitesInView.length

        const fixText = info.fixStatusDescription
                      ? info.fixStatusDescription
                      : info.qualityDescription

        return "GNSS: " + fixText +
               "\nH: " + (isFinite(h) ? h.toFixed(3) + " m" : "waiting") +
               "   V: " + (isFinite(v) ? v.toFixed(3) + " m" : "waiting") +
               "\nPDOP: " + (isFinite(p) ? p.toFixed(2) : "waiting") +
               "   Satellites: " + (isFinite(s) ? s : "waiting") +
               "\nQuality: " + qualityReason(info)
    }

    QfToolButton {
        id: surveyButton
        objectName: "fieldSurveyProButton"
        bgcolor: Theme.darkGray
        iconSource: "icon.svg"
        iconColor: Theme.mainColor
        round: true
        onClicked: panel.open()
    }

    Dialog {
        id: panel
        title: "FieldSurvey Pro"
        modal: true
        parent: mainWindow.contentItem
        width: Math.min(mainWindow.width - 40, 440)
        x: (mainWindow.width - width) / 2
        y: (mainWindow.height - height) / 2

        Column {
            width: parent.width
            spacing: 10

            Label {
                width: parent.width
                text: "GNSS Point Collection"
                font.bold: true
                font.pixelSize: 20
            }

            Label {
                width: parent.width
                text: "Next point ID: " + pointId()
            }

            Label {
                width: parent.width
                text: "Point name"
                font.bold: true
            }

            TextField {
                id: pointNameField
                width: parent.width
                text: settings.lastPointName.length > 0 ? "" : pointId()
                placeholderText: "Enter any name"
                selectByMouse: true
            }

            Label {
                width: parent.width
                text: statusText()
                wrapMode: Text.WordWrap
            }

            Button {
                width: parent.width
                text: "COLLECT POINT"
                enabled: true
                onClicked: {
                    panel.close()
                    collectPoint()
                }
            }

            CheckBox {
                id: qualityLockBox
                text: qualityLockEnabled
                      ? "Require GNSS quality limits: ON"
                      : "Require GNSS quality limits: OFF"
                checked: qualityLockEnabled
                onClicked: {
                    qualityLockEnabled = checked
                    settings.qualityLock = checked
                }
            }

            CheckBox {
                id: rtkBox
                text: "Require RTK"
                checked: settings.rtkOnly
                onClicked: settings.rtkOnly = checked
                enabled: qualityLockEnabled
            }

            Label {
                width: parent.width
                text: "Limits: H ≤ " + settings.maxHorizontalAccuracy.toFixed(2) +
                      " m, V ≤ " + settings.maxVerticalAccuracy.toFixed(2) +
                      " m, PDOP ≤ " + settings.maxPdop.toFixed(1) +
                      ", satellites ≥ " + settings.minSatellites
                wrapMode: Text.WordWrap
                enabled: qualityLockEnabled
            }

            Label {
                width: parent.width
                text: qualityLockEnabled
                      ? "QUALITY LOCK: ON — point collection is blocked until all limits pass."
                      : "QUALITY LOCK: OFF — point collection does not require accuracy, PDOP, or satellite limits."
                wrapMode: Text.WordWrap
                font.bold: true
            }

            Label {
                width: parent.width
                text: "Line Collection"
                font.bold: true
                font.pixelSize: 18
            }

            TextField {
                id: lineNameField
                width: parent.width
                placeholderText: "Line name"
                text: ""
                enabled: !lineRecording
            }

            Label {
                width: parent.width
                text: lineInfoText()
                wrapMode: Text.WordWrap
            }

            Button {
                width: parent.width
                text: lineRecording ? "FINISH LINE" : "START LINE"
                onClicked: {
                    if (lineRecording)
                        finishLine()
                    else
                        startLine()
                }
            }

            Label {
                width: parent.width
                text: "Vertices are collected every 5 ft (1.524 m) of movement. The timer only checks the GNSS position; it does not determine vertex spacing."
                wrapMode: Text.WordWrap
            }

            Button {
                width: parent.width
                text: "Close"
                enabled: !lineRecording
                onClicked: panel.close()
            }
        }
    }

    function configure() {
        panel.open()
    }

    Component.onCompleted: {
        qualityLockEnabled = settings.qualityLock
        iface.addItemToPluginsToolbar(surveyButton)
        mainWindow.displayToast("FieldSurvey Pro 0.11.1 loaded")
    }
}
