import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    property var mainWindow: iface.mainWindow()
    property var pointHandler: null
    property bool picking: false
    property var targetLayer: null
    property var targetFeature: null
    property string targetName: ""

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(stakeButton)
    }

    function startPicking() {
        pointHandler = iface.findItemByObjectName("pointHandler")
        if (!pointHandler) {
            mainWindow.displayToast("STAKEOUT: point handler unavailable")
            return
        }

        try { pointHandler.deregisterHandler("FieldSurveyProStakeoutFieldPoints") } catch (e) {}

        picking = true
        mainWindow.displayToast("STAKEOUT: TAP A POINT")

        pointHandler.registerHandler(
            "FieldSurveyProStakeoutFieldPoints",
            function(point, type, interactionType) {
                if (!picking || interactionType !== "clicked")
                    return false

                var mapCanvas = iface.mapCanvas()
                var tl = mapCanvas.mapSettings.screenToCoordinate(
                    Qt.point(point.x - 4, point.y - 4))
                var br = mapCanvas.mapSettings.screenToCoordinate(
                    Qt.point(point.x + 4, point.y + 4))
                var rectangle = GeometryUtils.createRectangleFromPoints(tl, br)

                var layers = qgisProject.mapLayersByName("FieldSurveyPro_Points")
                if (!layers || layers.length === 0) {
                    mainWindow.displayToast("FieldSurveyPro_Points layer not found")
                    return true
                }

                var layer = layers[0]
                var it = null
                try {
                    it = LayerUtils.createFeatureIteratorFromRectangle(layer, rectangle)
                } catch (e1) {
                    mainWindow.displayToast("Point search error")
                    return true
                }

                if (!it) {
                    mainWindow.displayToast("Point iterator unavailable")
                    return true
                }

                if (!it.hasNext()) {
                    mainWindow.displayToast("NO POINT FOUND")
                    return true
                }

                var feature = it.next()
                if (!feature || !feature.isValid()) {
                    mainWindow.displayToast("INVALID POINT")
                    return true
                }

                targetLayer = layer
                targetFeature = feature

                try {
                    targetName = String(feature.attribute("name"))
                } catch (e2) {
                    targetName = ""
                }

                if (targetName === "" || targetName === "undefined" || targetName === "null") {
                    try { targetName = "Feature " + feature.id() } catch (e3) { targetName = "Point" }
                }

                picking = false

                try {
                    LayerUtils.selectFeaturesInLayer(layer, [feature.id()])
                } catch (e4) {}

                mainWindow.displayToast("TARGET FOUND: " + targetName)
                return true
            },
            100
        )
    }

    QfToolButton {
        id: stakeButton
        width: 56
        height: 56
        iconSource: Theme.getThemeVectorIcon("ic_navigation_white_24dp")
        iconColor: Theme.toolButtonColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true
        onClicked: startPicking()

        Text {
            anchors.centerIn: parent
            text: "STAKE"
            color: "white"
            font.bold: true
            font.pixelSize: 10
        }
    }
}
