import QtQuick
import org.qfield

Item {
    id: plugin
    objectName: "fieldSurveyPro"

    Component.onCompleted: {
        iface.mainWindow().displayToast("FieldSurvey Pro test loaded")
    }
}
