import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    property var mainWindow: iface.mainWindow()
    property var pointHandler: null
    property bool picking: false

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(stakeButton)
    }

    function startPicking() {
        pointHandler = iface.findItemByObjectName("pointHandler")
        if (!pointHandler) {
            mainWindow.displayToast("STAKEOUT: pointHandler NOT FOUND")
            return
        }

        try { pointHandler.deregisterHandler("FieldSurveyProStakeoutLayerDiag") } catch (e) {}

        picking = true
        mainWindow.displayToast("STAKEOUT: TAP A POINT")

        pointHandler.registerHandler(
            "FieldSurveyProStakeoutLayerDiag",
            function(point, type, interactionType) {
                if (!picking || interactionType !== "clicked")
                    return false

                var layers = qgisProject.mapLayersByName("FieldSurveyPro_Points")
                if (!layers || layers.length === 0) {
                    mainWindow.displayToast("LAYER NOT FOUND")
                    return true
                }

                var layer = layers[0]

                // First inspect the layer itself rather than its iterator.
                var count = -1
                try {
                    count = Number(layer.featureCount())
                } catch (e1) {
                    try { count = Number(layer.featureCount) } catch (e2) {}
                }

                var geomType = "?"
                try { geomType = String(layer.geometryType()) } catch (e3) {}

                var editable = "?"
                try { editable = String(layer.isEditable()) } catch (e4) {}

                mainWindow.displayToast(
                    "LAYER: count=" + count +
                    " geom=" + geomType +
                    " edit=" + editable)

                return true
            },
            100
        )
    }

    QfToolButton {
        id: stakeButton
        width: 56
        height: 56
        iconSource: Theme.getThemeVectorIcon("ic_navigation_white_24dp")
        iconColor: Theme.toolButtonColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true
        onClicked: startPicking()

        Text {
            anchors.centerIn: parent
            text: "STAKE"
            color: "white"
            font.bold: true
            font.pixelSize: 10
        }
    }
}
