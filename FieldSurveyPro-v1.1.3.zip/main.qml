import QtQuick
import QtQuick.Controls
import QtQuick.Dialogs
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin
    objectName: "fieldSurveyPro"

    property var pointLayer: null
    property var lineLayer: null
    property var polygonLayer: null
    property var featureFormDrawer: null
    property string selectedPhoto: ""

    function findLayer(name) {
        if (!qgisProject) return null
        var layers = qgisProject.mapLayersByName(name)
        return layers && layers.length > 0 ? layers[0] : null
    }

    function prepareLayer(layer, label) {
        if (!layer) {
            iface.mainWindow().displayToast(label + " layer not found")
            return false
        }
        try {
            if (!layer.isEditable()) layer.startEditing()
        } catch (e) {
            iface.mainWindow().displayToast("Could not make " + label + " editable")
            return false
        }
        return true
    }

    function setup() {
        pointLayer = findLayer("FieldSurveyPro_Points")
        lineLayer = findLayer("FieldSurveyPro_Lines")
        polygonLayer = findLayer("FieldSurveyPro_Polygons")

        var ok = true
        ok = prepareLayer(pointLayer, "Point") && ok
        ok = prepareLayer(lineLayer, "Line") && ok
        ok = prepareLayer(polygonLayer, "Polygon") && ok

        featureFormDrawer = iface.findItemByObjectName("overlayFeatureFormDrawer")
        return ok
    }

    function collectPoint(pointName) {
        if (!pointLayer) {
            iface.mainWindow().displayToast("FieldSurveyPro_Points not found")
            return
        }

        var positioning = iface.positioning()
        if (!positioning || !positioning.valid) {
            iface.mainWindow().displayToast("GNSS position is not valid")
            return
        }

        var sourcePoint = positioning.sourcePosition
        if (!sourcePoint || !isFinite(sourcePoint.x) || !isFinite(sourcePoint.y)) {
            iface.mainWindow().displayToast("No valid GNSS coordinate")
            return
        }

        var projectedPoint = QfGeometryUtils.reprojectPoint(
            sourcePoint,
            CoordinateReferenceSystemUtils.wgs84Crs(),
            pointLayer.crs
        )

        var geometry = QfGeometryUtils.createGeometryFromWkt(
            "POINT (" + projectedPoint.x + " " + projectedPoint.y + ")"
        )

        var info = positioning.positionInformation
        var feature = FeatureUtils.createFeature(pointLayer, geometry, info)

        // No automatic point numbering.
        try { feature.setAttribute("name", pointName) } catch (e) {}

        try { feature.setAttribute("accuracy_h", info.hacc) } catch (e) {}
        try { feature.setAttribute("accuracy_v", info.vacc) } catch (e) {}
        try { feature.setAttribute("pdop", info.pdop) } catch (e) {}
        try { feature.setAttribute("satellites", info.satellitesUsed) } catch (e) {}
        try { feature.setAttribute("timestamp", info.utcDateTime) } catch (e) {}

        // Photo is optional. If the user selected one, store its path in
        // the notes field until a dedicated attachment field is configured.
        if (selectedPhoto.length > 0) {
            try {
                feature.setAttribute("notes", "Photo: " + selectedPhoto)
            } catch (e) {}
        }

        if (!featureFormDrawer) {
            iface.mainWindow().displayToast("QField feature form is unavailable")
            return
        }

        try {
            featureFormDrawer.featureModel.feature = feature
            featureFormDrawer.state = "Add"

            // Let QField's feature form handle the final feature commit.
            var created = featureFormDrawer.featureModel.create(true)

            if (created) {
                try { pointLayer.triggerRepaint() } catch (e) {}
                try { iface.mapCanvas().refresh() } catch (e) {}
                iface.mainWindow().displayToast("Point saved")
                pointDialog.close()
                return
            }

            iface.mainWindow().displayToast("Point could not be saved")
        } catch (e) {
            iface.mainWindow().displayToast("Point save error")
        }
    }

    QfToolButton {
        id: collectPointButton
        objectName: "fieldSurveyProCollectPoint"
        bgcolor: Theme.darkGray
        iconSource: Theme.getThemeVectorIcon("ic_add_location_white_24dp")
        iconColor: Theme.toolButtonColor
        round: true

        onClicked: {
            pointNameInput.text = ""
            selectedPhoto = ""
            photoLabel.text = "No photo selected"
            pointDialog.open()
            pointNameInput.forceActiveFocus()
        }
    }

    Dialog {
        id: pointDialog
        parent: iface.mainWindow().contentItem
        title: "FieldSurvey Pro — Collect Point"
        modal: true
        anchors.centerIn: parent
        width: Math.min(parent.width - 40, 540)

        Column {
            width: parent.width
            spacing: 12

            Label { text: "Point name (optional)" }

            TextField {
                id: pointNameInput
                width: parent.width
                placeholderText: "Enter point name"
            }

            Row {
                spacing: 10

                Button {
                    text: "Add Photo"
                    onClicked: photoPicker.open()
                }

                Label {
                    id: photoLabel
                    text: "No photo selected"
                    elide: Text.ElideMiddle
                    width: 230
                    verticalAlignment: Text.AlignVCenter
                }
            }

            Row {
                spacing: 10

                Button {
                    text: "Cancel"
                    onClicked: pointDialog.close()
                }

                Button {
                    text: "Collect Point"
                    onClicked: collectPoint(pointNameInput.text.trim())
                }
            }
        }
    }

    FileDialog {
        id: photoPicker
        title: "Select Point Photo"
        nameFilters: ["Images (*.jpg *.jpeg *.png *.heic *.webp)", "All files (*)"]
        onAccepted: {
            selectedPhoto = selectedFile.toString()
            photoLabel.text = selectedPhoto
        }
    }

    Component.onCompleted: {
        if (setup()) {
            iface.addItemToPluginsToolbar(collectPointButton)
            iface.mainWindow().displayToast("Point collector ready")
        } else {
            iface.addItemToPluginsToolbar(collectPointButton)
        }
    }
}
